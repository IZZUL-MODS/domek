"use client";

import { useState } from "react";

export interface OrderResult {
  success: boolean;
  email: string;
  password: string;
  domain: string;
  transactionId: string;
  orderId: string | null;
  promoCode: string;
  promoApplied: boolean;
  finalPrice: string;
  memberArea: string;
  inboxUrl: string;
  instructions?: string[];
  checkoutUrl?: string;
  memberAreaUrl?: string;
  qrisUrl?: string | null;
  invoicePaid?: boolean;
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API blocked in sandboxed environment
    }
  };
  return (
    <button
      onClick={copy}
      className="ml-2 shrink-0 rounded px-2 py-0.5 text-xs font-medium transition-colors bg-zinc-700 hover:bg-zinc-600 text-zinc-300 hover:text-white"
    >
      {copied ? "Disalin!" : "Salin"}
    </button>
  );
}

function DataRow({ label, value, mono = true }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-zinc-700/50 py-3 last:border-0">
      <span className="shrink-0 text-xs font-medium text-zinc-400 pt-0.5">{label}</span>
      <div className="flex min-w-0 items-center">
        <span className={`break-all text-sm text-zinc-100 ${mono ? "font-mono" : "font-medium"}`}>
          {value}
        </span>
        <CopyButton value={value} />
      </div>
    </div>
  );
}

export function ResultCard({ result, onNewRequest }: { result: OrderResult; onNewRequest?: () => void }) {
  const needsPayment = !result.invoicePaid && !!result.qrisUrl;
  const isPaid = result.invoicePaid || result.promoApplied;

  return (
    <div className={`rounded-2xl border bg-zinc-900 shadow-[0_0_40px_rgba(34,197,94,0.08)] ${needsPayment ? "border-amber-500/40" : "border-green-500/30"}`}>
      {/* Header */}
      <div className={`flex items-center gap-3 border-b border-zinc-700/50 px-5 py-4 ${needsPayment ? "bg-amber-500/5" : ""}`}>
        <span className={`flex size-8 items-center justify-center rounded-full ${needsPayment ? "bg-amber-500/15" : "bg-green-500/15"}`}>
          {needsPayment ? (
            <svg className="size-4 text-amber-400" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
          ) : (
            <svg className="size-4 text-green-400" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          )}
        </span>
        <div>
          {needsPayment ? (
            <>
              <p className="text-sm font-bold text-amber-400">Domain di Cart — Scan QRIS untuk Aktivasi</p>
              <p className="text-xs text-zinc-500">Bayar Rp 45.000 via QRIS ShopeePay untuk mengaktifkan domain</p>
            </>
          ) : (
            <>
              <p className="text-sm font-bold text-green-400">Berhasil! Domain Ter-Register</p>
              <p className="text-xs text-zinc-500">Semua proses selesai secara otomatis</p>
            </>
          )}
        </div>
      </div>

      {/* Domain badge */}
      <div className="border-b border-zinc-700/50 px-5 py-4">
        <p className="mb-2 text-xs font-medium uppercase tracking-widest text-zinc-500">Domain</p>
        <div className="flex items-center gap-2 mb-3">
          <span className={`rounded-lg px-3 py-1.5 font-mono text-base font-bold border ${needsPayment ? "bg-amber-500/10 text-amber-400 border-amber-500/20" : "bg-green-500/10 text-green-400 border-green-500/20"}`}>
            {result.domain}
          </span>
          <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${isPaid ? "bg-green-500/15 text-green-400" : "bg-amber-500/15 text-amber-400"}`}>
            {isPaid ? "GRATIS" : "BELUM BAYAR"}
          </span>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-xs text-zinc-400">Harga:</span>
          <span className={`font-mono font-bold text-lg ${isPaid ? "text-green-400" : "text-amber-400"}`}>{result.finalPrice}</span>
        </div>
      </div>

      {/* QRIS Payment Section */}
      {needsPayment && result.qrisUrl && (
        <div className="border-b border-zinc-700/50 px-5 py-5 bg-amber-500/5">
          <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-400">
            Scan QRIS ShopeePay
          </p>
          <div className="flex flex-col items-center gap-4">
            {/* QR Code */}
            <div className="rounded-2xl border-2 border-amber-500/30 bg-white p-3 shadow-lg">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(result.qrisUrl)}&bgcolor=ffffff&color=000000&margin=8`}
                alt="QRIS ShopeePay"
                width={200}
                height={200}
                className="block"
              />
            </div>
            {/* Instructions */}
            <div className="w-full rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
              <p className="text-xs font-semibold text-amber-400 mb-2">Cara bayar:</p>
              <ol className="flex flex-col gap-1.5">
                {[
                  "Buka aplikasi ShopeePay / dompet digital lain",
                  "Pilih Scan QR / Bayar via QRIS",
                  "Arahkan kamera ke QR code di atas",
                  "Konfirmasi pembayaran Rp 45.000",
                  "Domain akan aktif otomatis setelah pembayaran",
                ].map((step, i) => (
                  <li key={i} className="flex gap-2 text-[11px] text-zinc-300">
                    <span className="flex size-4 shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-[9px] font-bold text-amber-400">
                      {i + 1}
                    </span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>
            {/* Direct link */}
            <a
              href={result.qrisUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 py-2.5 text-sm font-bold text-white transition-colors hover:bg-amber-400"
            >
              <svg className="size-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              Buka Halaman Pembayaran
            </a>
          </div>
        </div>
      )}

      {/* Credentials */}
      <div className="px-5 py-2">
        <p className="mb-1 pt-2 text-xs font-medium uppercase tracking-widest text-zinc-500">
          Kredensial Akun TTMHost
        </p>
        <DataRow label="Email" value={result.email} />
        <DataRow label="Password" value={result.password} />
        <DataRow label="ID Transaksi" value={result.transactionId} />
        <DataRow label="Kode Promo" value={result.promoCode} mono={false} />
      </div>

      {/* Action links */}
      <div className="flex flex-col gap-2 border-t border-zinc-700/50 px-5 py-4 sm:flex-row">
        <a
          href={result.memberArea}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-zinc-800 py-2.5 text-sm font-semibold text-zinc-200 transition-colors hover:bg-zinc-700"
        >
          <svg className="size-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
          Area Member
        </a>
        <a
          href={result.inboxUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-green-600 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-green-500"
        >
          <svg className="size-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          Cek Inbox Email
        </a>
      </div>
    </div>
  );
}
