#!/bin/bash

# QRIS Payment System - Quick Start Script
# This script helps you get started with the QRIS payment integration

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║  QRIS Payment System - Quick Start                            ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# Function to print sections
print_section() {
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  $1"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo ""
}

# Check if in correct directory
if [ ! -f "domek-project/package.json" ]; then
  echo "❌ Error: Run this script from /vercel/share/v0-project/"
  echo "   (Must be in directory containing domek-project/)"
  exit 1
fi

print_section "Step 1: Navigate to project"
echo "cd domek-project"
cd domek-project

print_section "Step 2: Install dependencies"
echo "pnpm install"
pnpm install

print_section "Step 3: Setup environment"
echo ""
echo "📝 Creating .env.local from template..."
if [ ! -f ".env.local" ]; then
  cp .env.example .env.local
  echo "✅ Created .env.local"
  echo ""
  echo "⚠️  Important: Edit .env.local with your credentials:"
  echo "   - DUITKU_MERCHANT_CODE"
  echo "   - DUITKU_API_KEY"
  echo "   - DUITKU_CALLBACK_URL"
  echo "   - KV_URL, KV_REST_API_URL, KV_REST_API_TOKEN"
  echo "   - VALID_COUPONS"
  echo ""
  echo "🔗 Read: SETUP_QRIS.md for detailed setup instructions"
else
  echo "✅ .env.local already exists"
fi

print_section "Step 4: Setup database"
echo ""
echo "Running database setup script..."
echo "node scripts/setup-db.mjs"
echo ""
echo "Note: This requires KV_* environment variables to be set"

print_section "Step 5: Start development server"
echo ""
echo "Starting Next.js development server..."
echo "pnpm dev"
echo ""
echo "Open http://localhost:3000 in your browser"

print_section "Quick Links"
echo ""
echo "📚 Documentation:"
echo "   - SETUP_QRIS.md - Complete setup guide"
echo "   - PAYMENT_INTEGRATION.md - API reference"
echo "   - QRIS_IMPLEMENTATION_SUMMARY.md - Features overview"
echo ""
echo "🔗 External Links:"
echo "   - Duitku Dashboard: https://app.duitku.com"
echo "   - Vercel Dashboard: https://vercel.com/dashboard"
echo "   - Duitku Documentation: https://docs.duitku.com"
echo ""

print_section "Troubleshooting"
echo ""
echo "Issue: 'Cannot find module' errors"
echo "  → Run: pnpm install"
echo ""
echo "Issue: Environment variables missing"
echo "  → Edit .env.local with credentials"
echo "  → See SETUP_QRIS.md for details"
echo ""
echo "Issue: Build errors"
echo "  → Run: pnpm run build"
echo "  → Check error messages carefully"
echo ""

print_section "Next Steps"
echo ""
echo "1. Read SETUP_QRIS.md (15 min read)"
echo "2. Register Duitku account (https://app.duitku.com)"
echo "3. Create Vercel KV database"
echo "4. Update .env.local with credentials"
echo "5. Run: pnpm dev"
echo "6. Test payment flow at http://localhost:3000"
echo ""
echo "✨ For production deployment, see FINAL_CHECKLIST.md"
echo ""
