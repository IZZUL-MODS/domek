"use client";

import { DomainForm } from "@/components/domain-form";

const STEPS = [
  { n: "01", title: "Generate Email", desc: "Email temp mail diambil dari Zulzzmail secara acak" },
  { n: "02", title: "Ambil CSRF & Captcha", desc: "Token keamanan & gambar captcha diunduh dari TTMHost" },
  { n: "03", title: "Input CAPTCHA Manual", desc: "User membaca dan menginput kode CAPTCHA di modal popup" },
  { n: "04", title: "Daftar Akun WHMCS", desc: "Akun baru dibuat di member.ttmhost.co.id" },
  { n: "05", title: "Login & Keranjang", desc: "Login ke akun, domain ditambahkan ke cart" },
  { n: "06", title: "Promo DOMAINGRATIS", desc: "Kode promo diterapkan, harga menjadi Rp 0" },
  { n: "07", title: "Checkout & Bayar QRIS", desc: "Order dibuat, jika perlu bayar via QRIS ShopeePay otomatis" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans">
      {/* ── Top nav ── */}
      <header className="sticky top-0 z-50 border-b border-zinc-800/60 bg-zinc-950/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="flex size-7 items-center justify-center rounded-lg bg-green-600 text-xs font-black text-white">
              D
            </span>
            <span className="text-sm font-bold tracking-tight text-zinc-100">
              DomainGratis.id
            </span>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-green-500/30 bg-green-500/10 px-3 py-1">
            <span className="size-1.5 animate-pulse rounded-full bg-green-400" />
            <span className="font-mono text-xs font-semibold text-green-400">DOMAINGRATIS aktif</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10">
        {/* ── Hero ── */}
        <section className="mb-10 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-zinc-700/60 bg-zinc-900 px-3 py-1.5">
            <span className="font-mono text-xs font-bold text-green-400">DOMAINGRATIS</span>
            <span className="text-xs text-zinc-500">+ Zulzzmail + QRIS ShopeePay</span>
          </div>
          <h1 className="mb-3 text-balance text-3xl font-black tracking-tight text-zinc-50 sm:text-4xl">
            Daftar Domain Indonesia<br className="hidden sm:block" />
            <span className="text-green-400"> Gratis Otomatis</span>
          </h1>
          <p className="mx-auto max-w-lg text-pretty text-sm leading-relaxed text-zinc-400">
            Sistem mendaftarkan domain{" "}
            <span className="font-mono text-zinc-200">.my.id</span>,{" "}
            <span className="font-mono text-zinc-200">.biz.id</span>, atau{" "}
            <span className="font-mono text-zinc-200">.web.id</span> secara otomatis.
            Akun baru gratis dengan promo, akun lama bayar Rp 45.000 via{" "}
            <span className="text-zinc-200">QRIS ShopeePay</span>.
          </p>
        </section>

        {/* ── Two-column layout ── */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
          {/* Left: form + live log (3 col) */}
          <div className="lg:col-span-3">
            <DomainForm />
          </div>

          {/* Right: how it works (2 col) */}
          <aside className="lg:col-span-2">
            <div className="rounded-2xl border border-zinc-700/60 bg-zinc-900 p-5">
              <p className="mb-4 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">
                Alur Proses Otomatis
              </p>
              <ol className="flex flex-col gap-0">
                {STEPS.map((s, i) => (
                  <li key={s.n} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <span className="flex size-6 shrink-0 items-center justify-center rounded-full border border-zinc-700 bg-zinc-800 font-mono text-[10px] font-bold text-zinc-400">
                        {s.n}
                      </span>
                      {i < STEPS.length - 1 && (
                        <div className="mt-1 w-px flex-1 bg-zinc-800" style={{ minHeight: 16 }} />
                      )}
                    </div>
                    <div className="pb-4 pt-0.5">
                      <p className="text-xs font-semibold text-zinc-200">{s.title}</p>
                      <p className="mt-0.5 text-[11px] leading-relaxed text-zinc-500">{s.desc}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            {/* Pricing info */}
            <div className="mt-4 rounded-2xl border border-zinc-700/60 bg-zinc-900 p-4">
              <p className="mb-3 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">Harga</p>
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-400">Akun baru + promo</span>
                  <span className="font-mono text-sm font-bold text-green-400">Rp 0</span>
                </div>
                <div className="h-px bg-zinc-800" />
                <div className="flex items-center justify-between">
                  <span className="text-xs text-zinc-400">Akun lama (sudah pakai)</span>
                  <span className="font-mono text-sm font-bold text-amber-400">Rp 45.000</span>
                </div>
                <div className="mt-1 flex items-center gap-2 rounded-lg bg-amber-500/5 border border-amber-500/20 px-3 py-2">
                  <svg className="size-3.5 shrink-0 text-amber-400" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-[11px] text-amber-400/80">Bayar otomatis via QRIS ShopeePay</span>
                </div>
              </div>
            </div>

            {/* Tech stack badges */}
            <div className="mt-4 grid grid-cols-3 gap-2">
              {[
                { label: "TTMHost", sub: "WHMCS" },
                { label: "Zulzzmail", sub: "Temp Mail" },
                { label: "ShopeePay", sub: "QRIS" },
              ].map((b) => (
                <div
                  key={b.label}
                  className="flex flex-col items-center rounded-xl border border-zinc-700/60 bg-zinc-900 py-3"
                >
                  <span className="text-xs font-bold text-zinc-200">{b.label}</span>
                  <span className="text-[10px] text-zinc-500">{b.sub}</span>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </main>

      {/* ── Footer ── */}
      <footer className="mt-16 border-t border-zinc-800/60 py-6 text-center">
        <p className="text-xs text-zinc-600">
          Promo <span className="font-mono text-zinc-500">DOMAINGRATIS</span> berlaku di{" "}
          <a href="https://member.ttmhost.co.id" target="_blank" rel="noopener noreferrer" className="text-zinc-500 hover:text-zinc-400 underline underline-offset-2">
            TTMHost
          </a>{" "}
          &middot; Email temp dari{" "}
          <a href="https://zulzzmail.biz.id" target="_blank" rel="noopener noreferrer" className="text-zinc-500 hover:text-zinc-400 underline underline-offset-2">
            Zulzzmail
          </a>{" "}
          &middot; Bayar via QRIS ShopeePay
        </p>
      </footer>
    </div>
  );
}
