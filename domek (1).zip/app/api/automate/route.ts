import { NextRequest } from "next/server";

// ─────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────
const WHMCS = "https://member.ttmhost.co.id";
const ZULZZMAIL = "https://www.zulzzmail.biz.id";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────
function randomStr(len: number, chars: string): string {
  return Array.from(
    { length: len },
    () => chars[Math.floor(Math.random() * chars.length)]
  ).join("");
}

/** Extract CSRF token dari HTML — TTMHost menyimpannya di berbagai lokasi */
function extractCsrf(html: string): string {
  const m =
    html.match(/var\s+csrfToken\s*=\s*['"]([a-f0-9]+)['"]/i) ||
    html.match(/name="token"\s+value="([^"]+)"/i) ||
    html.match(/value="([^"]+)"\s+name="token"/i) ||
    html.match(/"token"\s*:\s*"([^"]+)"/i) ||
    html.match(/input[^>]+name=["']token["'][^>]+value=["']([^"']+)["']/i) ||
    html.match(/input[^>]+value=["']([^"']+)["'][^>]+name=["']token["']/i) ||
    html.match(/data-token=["']([^"']+)["']/i) ||
    html.match(/csrfToken['"]\s*:\s*['"]([a-f0-9]+)['"]/i);
  return m ? m[1] : "";
}

/** Merge Set-Cookie headers ke cookie string yang ada */
function mergeSessionCookies(existing: string, headers: Headers): string {
  const setCookies = headers.getSetCookie?.() ?? [];
  if (!setCookies.length) return existing;

  const map = new Map<string, string>();
  for (const pair of existing.split(";").map((s) => s.trim())) {
    const eq = pair.indexOf("=");
    if (eq > 0) map.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
  }
  for (const raw of setCookies) {
    const first = raw.split(";")[0].trim();
    const eq = first.indexOf("=");
    if (eq > 0) map.set(first.slice(0, eq).trim(), first.slice(eq + 1).trim());
  }
  return [...map.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
}

/** Resolve URL relatif dari TTMHost ke absolute URL */
function resolveUrl(location: string): string {
  if (location.startsWith("http")) return location;
  if (location.startsWith("/")) return `${WHMCS}${location}`;
  return `${WHMCS}/${location}`;
}

/** SSE helper */
function sse(
  ctrl: ReadableStreamDefaultController,
  event: string,
  data: Record<string, unknown>
) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  ctrl.enqueue(new TextEncoder().encode(payload));
}

/**
 * Fetch dengan manual redirect dan cookie tracking antar redirect.
 */
async function fetchFollow(
  url: string,
  options: RequestInit & { headers: Record<string, string> },
  maxHops = 8
): Promise<{ finalUrl: string; html: string; cookie: string; status: number }> {
  let currentUrl = url;
  let cookie = options.headers["Cookie"] ?? "";
  let currentOptions = { ...options };

  for (let i = 0; i < maxHops; i++) {
    const res = await fetch(currentUrl, {
      ...currentOptions,
      headers: { ...currentOptions.headers, Cookie: cookie },
      redirect: "manual",
      cache: "no-store",
    });

    cookie = mergeSessionCookies(cookie, res.headers);

    const location = res.headers.get("location");
    if (
      (res.status === 301 || res.status === 302 || res.status === 303) &&
      location
    ) {
      currentUrl = resolveUrl(location);
      // POST-redirect-GET
      currentOptions = { ...currentOptions, method: "GET", body: undefined };
      continue;
    }

    const html = await res.text();
    return { finalUrl: currentUrl, html, cookie, status: res.status };
  }

  return { finalUrl: currentUrl, html: "", cookie, status: 0 };
}

// ─────────────────────────────────────────────
// POST /api/automate
// ─────────────────────────────────────────────
interface CaptchaResumeData {
  email: string;
  username: string;
  pickedDomain: string;
  regToken: string;
  sessionCookie: string;
  accountPassword: string;
  firstName: string;
  lastName: string;
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const {
    domainName,
    tld,
    captchaCode,
    resumeData: resumeDataEncoded,
  } = body as {
    domainName: string;
    tld: string;
    captchaCode?: string;
    resumeData?: string;
  };

  if (!domainName || !tld) {
    return new Response(
      JSON.stringify({ error: "domainName dan tld wajib diisi" }),
      { status: 400 }
    );
  }

  let resumeState: CaptchaResumeData | undefined;
  if (resumeDataEncoded && captchaCode) {
    try {
      resumeState = JSON.parse(
        Buffer.from(resumeDataEncoded, "base64").toString("utf-8")
      ) as CaptchaResumeData;
    } catch {
      // fallback: jalankan dari awal
    }
  }

  const stream = new ReadableStream({
    async start(ctrl) {
      try {
        await runFlow(ctrl, domainName, tld, captchaCode, resumeState);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Error tidak diketahui";
        if (msg !== "__CAPTCHA_REQUIRED__") {
          sse(ctrl, "error", { message: msg });
        }
      } finally {
        ctrl.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

// ─────────────────────────────────────────────
// Main automation flow
// ─────────────────────────────────────────────
async function runFlow(
  ctrl: ReadableStreamDefaultController,
  domainName: string,
  tld: string,
  captchaCode?: string,
  resumeState?: CaptchaResumeData
) {
  const tldClean = tld.startsWith(".") ? tld : `.${tld}`;
  const fullDomain = `${domainName}${tldClean}`;
  // TLD tanpa titik, e.g. "my.id"
  const tldNoDot = tldClean.slice(1);

  let tempEmail: string;
  let regToken: string;
  let sessionCookie: string;
  let accountPassword: string;
  let firstName: string;
  let lastName: string;

  if (resumeState && captchaCode) {
    // ══════════════════════════════════════════════
    // RESUME: Lanjut setelah user input CAPTCHA
    // ══════════════════════════════════════════════
    tempEmail = resumeState.email;
    regToken = resumeState.regToken;
    sessionCookie = resumeState.sessionCookie;
    accountPassword = resumeState.accountPassword;
    firstName = resumeState.firstName;
    lastName = resumeState.lastName;

    sse(ctrl, "step", {
      id: 1,
      status: "done",
      message: `Email siap: ${tempEmail}`,
    });
    sse(ctrl, "step", {
      id: 2,
      status: "done",
      message: "Halaman registrasi siap (resume)",
    });
  } else {
    // ══════════════════════════════════════════════
    // STEP 1: Ambil email dari Zulzzmail
    // ══════════════════════════════════════════════
    sse(ctrl, "step", {
      id: 1,
      status: "running",
      message: "Mengambil daftar domain email...",
    });

    let domainList: string[] = [];
    try {
      const domainsRes = await fetch(`${ZULZZMAIL}/api/domains`, {
        headers: { "User-Agent": UA },
        cache: "no-store",
        signal: AbortSignal.timeout(10000),
      });
      if (domainsRes.ok) {
        const domainsJson = (await domainsRes.json()) as
          | { domains: string[] }
          | string[];
        domainList = Array.isArray(domainsJson)
          ? domainsJson
          : (domainsJson as { domains: string[] }).domains ?? [];
      }
    } catch {
      // Gunakan fallback jika API tidak tersedia
    }

    // Fallback domain list jika API gagal
    if (!domainList.length) {
      domainList = [
        "kawneha.site",
        "edshol.net",
        "mtnewtoy.us",
        "rilzz.store",
        "tokmail.fun",
        "cttnoot.us",
        "senvas.me",
      ];
    }

    const pickedDomain =
      domainList[Math.floor(Math.random() * domainList.length)];
    const username =
      randomStr(8, "abcdefghijklmnopqrstuvwxyz") +
      randomStr(3, "0123456789");
    tempEmail = `${username}@${pickedDomain}`;

    sse(ctrl, "step", {
      id: 1,
      status: "done",
      message: `Email siap: ${tempEmail}`,
    });

    // ══════════════════════════════════════════════
    // STEP 2: Buka halaman register TTMHost + ambil CAPTCHA
    // ══════════════════════════════════════════════
    sse(ctrl, "step", {
      id: 2,
      status: "running",
      message: "Membuka halaman registrasi...",
    });

    const regPageRes = await fetch(`${WHMCS}/register.php`, {
      headers: { "User-Agent": UA },
      cache: "no-store",
      redirect: "manual",
    });
    if (!regPageRes.ok && regPageRes.status !== 200) {
      throw new Error(`Gagal buka halaman register (${regPageRes.status})`);
    }

    sessionCookie = mergeSessionCookies("", regPageRes.headers);
    const regPageHtml = await regPageRes.text();
    regToken = extractCsrf(regPageHtml);

    firstName = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
    lastName = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
    accountPassword =
      randomStr(6, "abcdefghijklmnopqrstuvwxyz") +
      randomStr(2, "ABCDEFGHIJKLMNOPQRSTUVWXYZ") +
      randomStr(2, "0123456789");

    const hasCaptchaField =
      regPageHtml.includes('name="code"') ||
      regPageHtml.includes("inputCaptchaImage");
    const capImgMatch =
      regPageHtml.match(
        /<img[^>]+(?:id="inputCaptchaImage"|src="[^"]*verifyimage)[^>]*src="([^"]+)"/i
      ) ||
      regPageHtml.match(
        /<img[^>]+src="([^"]*(?:verifyimage|securimage|captcha)[^"]*)"/i
      );
    const capImgPath = capImgMatch
      ? capImgMatch[1]
      : hasCaptchaField
        ? "/includes/verifyimage.php"
        : null;

    if (hasCaptchaField) {
      const capUrl = capImgPath
        ? capImgPath.startsWith("http")
          ? capImgPath
          : `${WHMCS}${capImgPath}`
        : `${WHMCS}/includes/verifyimage.php`;

      const capRes = await fetch(capUrl, {
        headers: {
          "User-Agent": UA,
          Cookie: sessionCookie,
          Referer: `${WHMCS}/register.php`,
        },
        cache: "no-store",
      });
      sessionCookie = mergeSessionCookies(sessionCookie, capRes.headers);
      const capBuf = await capRes.arrayBuffer();
      const capB64 = Buffer.from(capBuf).toString("base64");
      const contentType = capRes.headers.get("content-type") || "image/png";

      const statePayload: CaptchaResumeData = {
        email: tempEmail,
        username,
        pickedDomain,
        regToken,
        sessionCookie,
        accountPassword,
        firstName,
        lastName,
      };
      const encoded = Buffer.from(JSON.stringify(statePayload)).toString(
        "base64"
      );

      sse(ctrl, "captcha", {
        image: `data:${contentType};base64,${capB64}`,
        message:
          "Masukkan kode CAPTCHA dari gambar untuk mendaftar di TTMHost",
        resumeData: encoded,
      });

      throw new Error("__CAPTCHA_REQUIRED__");
    }

    sse(ctrl, "step", {
      id: 2,
      status: "done",
      message: "Halaman registrasi siap",
    });
  }

  // ══════════════════════════════════════════════
  // STEP 3: Daftar akun TTMHost
  // ══════════════════════════════════════════════
  sse(ctrl, "step", {
    id: 3,
    status: "running",
    message: "Mendaftar akun TTMHost...",
  });

  const regForm = new URLSearchParams({
    token: regToken,
    register: "true",
    firstname: firstName,
    lastname: lastName,
    email: tempEmail,
    password: accountPassword,
    password2: accountPassword,
    address1: "Jl. Test No. 1",
    city: "Jakarta",
    state: "DKI Jakarta",
    postcode: "12345",
    country: "ID",
    phonenumber: "+62.81234567890",
    code: captchaCode ?? "",
    marketingoptin: "0",
  });

  const regRes = await fetch(`${WHMCS}/register.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/register.php`,
      Origin: WHMCS,
    },
    body: regForm.toString(),
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, regRes.headers);

  const regLocation = regRes.headers.get("location") ?? "";
  console.log("[STEP3] register status:", regRes.status, "location:", regLocation);

  // Sukses = redirect 302 ke halaman manapun (termasuk /clientarea.php?action=register)
  // BUKAN cek isi location — TTMHost kadang redirect ke URL yang mengandung kata "register"
  const regOk = regRes.status === 302;

  if (!regOk) {
    const regHtml = await regRes.text();
    console.log("[STEP3] register failed html snippet:", regHtml.slice(0, 500));
    // Cari pesan error spesifik dari TTMHost
    const errMatch =
      regHtml.match(/class="alert[^"]*danger[^"]*"[^>]*>([\s\S]{0,400})/i);
    if (errMatch) {
      const errText = errMatch[1].replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 200);
      if (
        errText.toLowerCase().includes("karakter") ||
        errText.toLowerCase().includes("captcha") ||
        errText.toLowerCase().includes("cocok")
      ) {
        throw new Error("Kode CAPTCHA salah — silakan coba lagi");
      }
      if (errText.length > 5) throw new Error(`Registrasi gagal: ${errText}`);
    }
    throw new Error("Registrasi gagal — TTMHost menolak form. Silakan coba lagi.");
  }

  // Ikuti semua redirect setelah register menggunakan fetchFollow
  if (regLocation) {
    const afterRegUrl = resolveUrl(regLocation);
    try {
      const { cookie: newCookie } = await fetchFollow(
        afterRegUrl,
        { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
      );
      sessionCookie = newCookie;
    } catch {
      // Redirect gagal bukan masalah fatal — lanjut dengan session yang ada
      console.log("[STEP3] post-register redirect failed, continuing with existing session");
    }
  }

  console.log("[STEP3] register OK, password:", accountPassword);
  sse(ctrl, "step", {
    id: 3,
    status: "done",
    message: "Akun berhasil dibuat",
  });

  // ══════════════════���������������═══════════════════════════
  // STEP 4: Login ke TTMHost
  // ════════════════════════════���═���═══���═���═���═══════
  sse(ctrl, "step", {
    id: 4,
    status: "running",
    message: "Login ke TTMHost...",
  });

  const loginPageRes = await fetch(`${WHMCS}/index.php?rp=/login`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    cache: "no-store",
    redirect: "manual",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, loginPageRes.headers);
  const loginHtml = await loginPageRes.text();
  const loginToken = extractCsrf(loginHtml);
  console.log("[STEP4] login token:", loginToken.slice(0, 20));

  const loginForm = new URLSearchParams({
    token: loginToken,
    username: tempEmail,
    password: accountPassword,
    "2facode": "",
    rememberme: "on",
  });

  const loginRes = await fetch(`${WHMCS}/dologin.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/index.php?rp=/login`,
      Origin: WHMCS,
    },
    body: loginForm.toString(),
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, loginRes.headers);
  const loginLocation = loginRes.headers.get("location") ?? "";
  console.log("[STEP4] login status:", loginRes.status, "location:", loginLocation);

  // Ikuti semua redirect login sampai dapat halaman clientarea
  if (loginRes.status === 302 && loginLocation) {
    const { cookie: updatedCookie } = await fetchFollow(
      resolveUrl(loginLocation),
      { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
    );
    sessionCookie = updatedCookie;
  }

  // Verifikasi session valid dengan cek clientarea
  const verifyRes = await fetch(`${WHMCS}/clientarea.php`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, verifyRes.headers);
  const verifyLocation = verifyRes.headers.get("location") ?? "";
  const loginOk =
    verifyRes.status === 200 && !verifyLocation.includes("login");

  if (!loginOk) {
    throw new Error(
      "Login gagal — session tidak valid. Silakan coba lagi."
    );
  }

  sse(ctrl, "step", {
    id: 4,
    status: "done",
    message: "Login berhasil",
  });

  // ══════════════════════════════════════════════
  // STEP 5: Add domain ke cart via WHMCS AJAX
  //
  // TTMHost menggunakan AJAX endpoint di cart.php:
  //   POST /cart.php
  //   Headers: X-Requested-With: XMLHttpRequest
  //   Body: a=addToCart&domain=namadomain&tld=.my.id&domainperiod=1&token=...
  //
  // Response sukses: {"result":"added","period":1,"cartCount":1}
  // ══════════════════════════════════════════════
  sse(ctrl, "step", {
    id: 5,
    status: "running",
    message: `Menambahkan ${fullDomain} ke keranjang...`,
  });

  // Ambil halaman cart untuk mendapatkan CSRF token yang valid untuk session ini
  // Gunakan fetchFollow agar redirect (termasuk redirect ke login) terlacak
  const cartPageResult = await fetchFollow(
    `${WHMCS}/cart.php?a=add&domain=register`,
    {
      method: "GET",
      headers: {
        "User-Agent": UA,
        Cookie: sessionCookie,
        Referer: `${WHMCS}/clientarea.php`,
      },
    }
  );
  sessionCookie = cartPageResult.cookie;
  const cartPageHtml = cartPageResult.html;
  const cartToken = extractCsrf(cartPageHtml);
  console.log("[STEP5] cart page finalUrl:", cartPageResult.finalUrl, "token:", cartToken.slice(0, 20));

  // AJAX addToCart — verified exact body from browser network intercept:
  // POST /cart.php
  // body: a=addToCart&domain=FQDN.my.id&token=...&whois=0&sideorder=0&idnlanguage=
  // NOTE: domain MUST be full FQDN, NOT separate domain+tld fields
  const addToCartForm = new URLSearchParams({
    a: "addToCart",
    domain: fullDomain,   // FULL domain e.g. "mysite.my.id" — bukan terpisah
    token: cartToken,
    whois: "0",
    sideorder: "0",
    idnlanguage: "",
  });

  const addToCartRes = await fetch(`${WHMCS}/cart.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/cart.php?a=add&domain=register`,
      Origin: WHMCS,
      "X-Requested-With": "XMLHttpRequest",
    },
    body: addToCartForm.toString(),
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, addToCartRes.headers);
  const addToCartBody = await addToCartRes.text();
  console.log("[STEP5] addToCart status:", addToCartRes.status, "body:", addToCartBody.slice(0, 120));

  // Parse response JSON dari WHMCS AJAX
  let cartAdded = false;
  let cartCount = 0;
  try {
    const cartJson = JSON.parse(addToCartBody) as {
      result?: string;
      cartCount?: number;
      error?: string;
    };
    cartAdded = cartJson.result === "added" || (cartJson.cartCount ?? 0) > 0;
    cartCount = cartJson.cartCount ?? 0;

    if (!cartAdded && cartJson.error) {
      // Domain tidak tersedia atau sudah terdaftar
      throw new Error(
        `Domain ${fullDomain} tidak tersedia: ${cartJson.error}`
      );
    }
  } catch (jsonErr) {
    if (jsonErr instanceof SyntaxError) {
      // Bukan JSON — verifikasi lewat cart view
      const cartVerifyRes = await fetchFollow(
        `${WHMCS}/cart.php?a=view`,
        { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
      );
      sessionCookie = cartVerifyRes.cookie;
      cartAdded =
        cartVerifyRes.html.includes(fullDomain) ||
        cartVerifyRes.html.includes(domainName);
      cartCount = cartAdded ? 1 : 0;
      console.log("[STEP5] JSON parse failed, cart verify fallback:", cartAdded);
    } else {
      throw jsonErr;
    }
  }

  if (!cartAdded) {
    throw new Error(
      `Gagal menambahkan ${fullDomain} ke keranjang. Domain mungkin tidak tersedia.`
    );
  }

  console.log("[STEP5] domain added to cart. cartCount:", cartCount);
  sse(ctrl, "step", {
    id: 5,
    status: "done",
    message: `${fullDomain} berhasil ditambahkan ke keranjang (${cartCount} item)`,
  });

  // ══════════════════════════════════════════════
  // STEP 6: Apply promo code DOMAINGRATIS
  //
  // WHMCS promo dikirim saat checkout — bukan endpoint terpisah.
  // TTMHost juga menerima promo via AJAX di cart page.
  // ══════════════════════════════════════════════
  sse(ctrl, "step", {
    id: 6,
    status: "running",
    message: "Menerapkan kode promo DOMAINGRATIS...",
  });

  // VERIFIED from browser: GET /cart.php?a=view&promocode=DOMAINGRATIS&token=...
  // This is the only method confirmed to actually apply the promo to the session.
  const promoCartRes = await fetch(`${WHMCS}/cart.php?a=view`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, promoCartRes.headers);
  const promoCartHtml = await promoCartRes.text();
  const promoToken = extractCsrf(promoCartHtml) || cartToken;

  // Apply promo via GET with promocode in query string — confirmed working from browser intercept
  const promoRes = await fetchFollow(
    `${WHMCS}/cart.php?a=view&promocode=DOMAINGRATIS&token=${promoToken}`,
    { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie, Referer: `${WHMCS}/cart.php?a=view` } }
  );
  sessionCookie = promoRes.cookie;
  const finalCartHtml = promoRes.html;

  // Deteksi apakah promo berhasil — total Rp 0 atau ada text diskon
  const promoOk =
    finalCartHtml.includes("DOMAINGRATIS") ||
    finalCartHtml.includes("Rp0") ||
    finalCartHtml.match(/Totals?[^<]{0,60}0[,.]00/i) !== null ||
    finalCartHtml.toLowerCase().includes("100% sekali diskon");

  // Jika promo tidak apply (akun lama / sudah pakai kupon), domain tetap Rp 45k
  // Dalam kasus itu kita lanjut dengan payment duitku_shopee (QRIS)
  const totalMatch = finalCartHtml.match(/Total Due Today[^<]*<\/[^>]+>\s*<[^>]+>\s*(Rp[\d,.\s]+|IDR[\d,.\s]+)/i) ||
                     finalCartHtml.match(/(Rp[\d,.]+)\s*IDR/);
  const finalPrice = totalMatch ? totalMatch[1].trim() : promoOk ? "Rp 0 (GRATIS)" : "Rp 45.000";
  const isZeroTotal = promoOk || finalPrice.includes("0,00") || finalPrice.match(/Rp\s*0\b/) !== null;

  console.log("[STEP6] promoOk:", promoOk, "price:", finalPrice, "zero:", isZeroTotal);
  sse(ctrl, "step", {
    id: 6,
    status: "done",
    message: promoOk
      ? `Promo DOMAINGRATIS diterapkan — Total: ${finalPrice}`
      : `Kupon tidak berlaku untuk akun ini — Total: ${finalPrice} (akan dibayar via QRIS Shopee)`,
  });

  // ══════════════════════════════════════════════
  // STEP 7: Checkout & Place Order
  //
  // WHMCS checkout:
  //   GET  /cart.php?a=checkout  → halaman payment
  //   POST /cart.php?a=checkout  → place order
  //   Body: paymentmethod=..., promocode=..., accepttos=on, token=...
  // ══════════��═══════════════════════════════════
  sse(ctrl, "step", {
    id: 7,
    status: "running",
    message: "Melakukan checkout dan membuat order...",
  });

  // GET halaman checkout untuk token fresh + account_id
  const checkoutPageResult = await fetchFollow(
    `${WHMCS}/cart.php?a=checkout`,
    { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie, Referer: `${WHMCS}/cart.php?a=view` } }
  );
  sessionCookie = checkoutPageResult.cookie;

  if (checkoutPageResult.finalUrl.includes("login")) {
    throw new Error("Session expired saat checkout. Silakan coba lagi dari awal.");
  }

  const checkoutPageHtml = checkoutPageResult.html;
  const checkoutToken = extractCsrf(checkoutPageHtml);
  // account_id wajib disertakan untuk custtype=existing agar WHMCS tahu akun mana
  const accountId = checkoutPageHtml.match(/name="account_id"[^>]*value="(\d+)"/i)?.[1] ?? "";
  console.log("[STEP7] checkout token:", checkoutToken.slice(0, 15), "account_id:", accountId);

  // Selalu gunakan duitku_shopee (QRIS by ShopeePay) sebagai payment method default.
  // Jika total Rp 0 → invoice akan dilunasi otomatis via applycredit setelah order dibuat.
  // Jangan pakai banktransfer — TTMHost tidak auto-confirm bank transfer.
  const paymentMethod = "duitku_shopee";

  const phone = `8${randomStr(9, "0123456789")}`;
  const checkoutForm = new URLSearchParams({
    token: checkoutToken,
    submit: "true",
    custtype: "existing",
    account_id: accountId,
    loginemail: tempEmail,
    loginpassword: accountPassword,
    firstname: firstName,
    lastname: lastName,
    email: tempEmail,
    "country-calling-code-phonenumber": "62",
    phonenumber: phone,
    companyname: "",
    address1: "Jl Merdeka No 1",
    address2: "",
    city: "Jakarta",
    state: "DKI Jakarta",
    postcode: "10110",
    country: "ID",
    contact: "",
    domaincontactfirstname: firstName,
    domaincontactlastname: lastName,
    domaincontactemail: tempEmail,
    "country-calling-code-domaincontactphonenumber": "62",
    domaincontactphonenumber: phone,
    domaincontactcompanyname: "",
    domaincontactaddress1: "Jl Merdeka No 1",
    domaincontactaddress2: "",
    domaincontactcity: "Jakarta",
    domaincontactstate: "DKI Jakarta",
    domaincontactpostcode: "10110",
    domaincontactcountry: "ID",
    domaincontacttax_id: "",
    password: "",
    password2: "",
    applycredit: "1",
    accepttos: "on",
    paymentmethod: paymentMethod,
    notes: "",
    marketingoptin: "0",
    promocode: "DOMAINGRATIS",
  });

  // POST checkout — form method=post confirmed dari browser intercept
  const checkoutResult = await fetchFollow(
    `${WHMCS}/cart.php?a=checkout`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": UA,
        Cookie: sessionCookie,
        Referer: `${WHMCS}/cart.php?a=checkout`,
        Origin: WHMCS,
      },
      body: checkoutForm.toString(),
    },
    15
  );
  sessionCookie = checkoutResult.cookie;
  const checkoutFinalUrl = checkoutResult.finalUrl;
  const checkoutHtml = checkoutResult.html;
  // Ekstrak invoice ID dari URL atau HTML checkout complete
  let orderId: string | null =
    checkoutFinalUrl.match(/[?&]id=(\d+)/)?.[1] ??
    checkoutHtml.match(/viewinvoice\.php\?id=(\d+)/)?.[1] ??
    checkoutHtml.match(/Invoice\s*#?\s*(\d+)/i)?.[1] ??
    checkoutHtml.match(/Order\s*(?:ID|#)[^\d]*(\d+)/i)?.[1] ??
    checkoutHtml.match(/orderpending\.php\?.*?id=(\d+)/i)?.[1] ??
    null;

  let orderSuccess =
    checkoutFinalUrl.includes("complete") ||
    checkoutFinalUrl.includes("orderpending") ||
    checkoutFinalUrl.includes("invoice") ||
    checkoutFinalUrl.includes("thankyou") ||
    checkoutHtml.toLowerCase().includes("thank you") ||
    checkoutHtml.includes("Order Confirmed") ||
    orderId !== null;

  // Fallback: cek invoice list jika belum dapat order ID
  if (!orderSuccess || !orderId) {
    const invListResult = await fetchFollow(
      `${WHMCS}/clientarea.php?action=invoices`,
      { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
    );
    sessionCookie = invListResult.cookie;
    const idFromList =
      invListResult.html.match(/viewinvoice\.php\?id=(\d+)/)?.[1] ??
      invListResult.html.match(/Invoice\s*#?\s*(\d+)/i)?.[1] ?? null;
    if (idFromList) { orderId = idFromList; orderSuccess = true; }

  }

  // ── Auto-pay: aktifkan domain otomatis ──────────────────────────────────────
  let qrisUrl: string | null = null;
  let invoicePaid = false;

  if (orderId) {
    try {
      // 1. Buka halaman invoice
      const invResult = await fetchFollow(
        `${WHMCS}/viewinvoice.php?id=${orderId}`,
        { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
      );
      sessionCookie = invResult.cookie;
      const invHtml = invResult.html;
      const invToken = extractCsrf(invHtml);

      // Deteksi apakah invoice sudah paid
      const alreadyPaid = /\bPaid\b|\bLunas\b/i.test(invHtml);

      // Deteksi Rp 0 dari berbagai format TTMHost
      const isZero =
        alreadyPaid ||
        /\bIDR\s*0\.00\b/i.test(invHtml) ||
        /\bRp\s*0[^,\d]/i.test(invHtml) ||
        /\b0\.00\s*IDR\b/i.test(invHtml) ||
        /Amount Due[^<]{0,80}0\.00/i.test(invHtml) ||
        /Total Due[^<]{0,80}0[.,]00/i.test(invHtml) ||
        isZeroTotal;

      if (alreadyPaid) {
        invoicePaid = true;

        // CONFIRMED dari log: sub=domainregister via POST ke domaindetails&id=<ID>
        // adalah satu-satunya cara yang berhasil mengaktifkan domain dari client area.
        // Ambil domain ID dari halaman domains list terlebih dahulu.
        const domainsRes = await fetchFollow(
          `${WHMCS}/clientarea.php?action=domains`,
          { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
        );
        sessionCookie = domainsRes.cookie;

        // Cari domain ID dari link domaindetails di halaman list
        const escapedDomain = fullDomain.replace(/\./g, "\\.");
        const domIdRegex = new RegExp(
          `clientarea\\.php\\?action=domaindetails&(?:amp;)?id=(\\d+)[^>]*>[^<]*${escapedDomain}`, "i"
        );
        const domainId =
          domainsRes.html.match(domIdRegex)?.[1] ??
          domainsRes.html.match(/clientarea\.php\?action=domaindetails&(?:amp;)?id=(\d+)/i)?.[1] ??
          null;

        if (domainId) {
          // Ambil CSRF token dari halaman domain detail
          const domDetailRes = await fetchFollow(
            `${WHMCS}/clientarea.php?action=domaindetails&id=${domainId}`,
            { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
          );
          sessionCookie = domDetailRes.cookie;
          const domCsrf = extractCsrf(domDetailRes.html);

          if (domCsrf) {
            // POST sub=domainregister — terbukti mengaktifkan domain dari Tunda ke Active
            const registerRes = await fetchFollow(
              `${WHMCS}/clientarea.php?action=domaindetails&id=${domainId}`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded",
                  "User-Agent": UA,
                  Cookie: sessionCookie,
                  Referer: `${WHMCS}/clientarea.php?action=domaindetails&id=${domainId}`,
                  Origin: WHMCS,
                },
                body: new URLSearchParams({
                  token: domCsrf,
                  sub: "domainregister",
                }).toString(),
              }
            );
            sessionCookie = registerRes.cookie;
          }
        }

      } else if (isZero && invToken) {
        // 2a. Invoice Rp 0 — ubah payment method ke duitku_shopee lalu applycredit
        //     Step 1: set paymentmethod di invoice
        const setPayRes = await fetchFollow(
          `${WHMCS}/viewinvoice.php?id=${orderId}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "User-Agent": UA,
              Cookie: sessionCookie,
              Referer: `${WHMCS}/viewinvoice.php?id=${orderId}`,
              Origin: WHMCS,
            },
            body: new URLSearchParams({
              token: invToken,
              id: orderId,
              paymentmethod: "duitku_shopee",
              changePaymentMethod: "true",
            }).toString(),
          }
        );
        sessionCookie = setPayRes.cookie;
        // Token baru setelah set payment method
        const invToken2 = extractCsrf(setPayRes.html) || invToken;

        //     Step 2: applycredit untuk lunasi Rp 0
        const applyRes = await fetchFollow(
          `${WHMCS}/viewinvoice.php?id=${orderId}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "User-Agent": UA,
              Cookie: sessionCookie,
              Referer: `${WHMCS}/viewinvoice.php?id=${orderId}`,
              Origin: WHMCS,
            },
            body: new URLSearchParams({
              token: invToken2,
              id: orderId,
              applycredit: "true",
            }).toString(),
          }
        );
        sessionCookie = applyRes.cookie;
        invoicePaid =
          /\bPaid\b|\bLunas\b/i.test(applyRes.html) ||
          applyRes.finalUrl.includes("complete") ||
          applyRes.finalUrl.includes("thankyou");
        console.log("[STEP7] applycredit result paid:", invoicePaid, "url:", applyRes.finalUrl);

        // 3. Jika masih belum paid, coba via clientarea API endpoint
        if (!invoicePaid) {
          const apiPayRes = await fetchFollow(
            `${WHMCS}/clientarea.php?action=invoices`,
            { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
          );
          sessionCookie = apiPayRes.cookie;
          // Re-fetch invoice untuk cek status terbaru
          const recheckRes = await fetchFollow(
            `${WHMCS}/viewinvoice.php?id=${orderId}`,
            { method: "GET", headers: { "User-Agent": UA, Cookie: sessionCookie } }
          );
          sessionCookie = recheckRes.cookie;
          invoicePaid = /\bPaid\b|\bLunas\b/i.test(recheckRes.html);
          console.log("[STEP7] recheck invoice paid:", invoicePaid);
        }
      } else if (!alreadyPaid && !isZero && invToken) {
        // 2b. Invoice ada harganya (akun lama, Rp 45k) — generate QRIS Duitku
        const payInvResult = await fetchFollow(
          `${WHMCS}/viewinvoice.php?id=${orderId}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
              "User-Agent": UA,
              Cookie: sessionCookie,
              Referer: `${WHMCS}/viewinvoice.php?id=${orderId}`,
              Origin: WHMCS,
            },
            body: new URLSearchParams({
              token: invToken,
              id: orderId,
              paymentmethod: "duitku_shopee",
            }).toString(),
          },
          15
        );
        sessionCookie = payInvResult.cookie;
        console.log("[STEP7] duitku redirect url:", payInvResult.finalUrl);

        const duitkuHtml = payInvResult.html;
        qrisUrl =
          payInvResult.finalUrl.includes("duitku") ? payInvResult.finalUrl :
          duitkuHtml.match(/https:\/\/[^"']*(?:qr|qris)[^"']*\.(?:png|jpg|svg)[^"']*/i)?.[0] ??
          duitkuHtml.match(/qrString["']?\s*:\s*["']([^"']+)/i)?.[1] ??
          duitkuHtml.match(/qrCode["']?\s*:\s*["']([^"']+)/i)?.[1] ??
          duitkuHtml.match(/src=["']([^"']*qr[^"']*\.png[^"']*)/i)?.[1] ?? null;
        console.log("[STEP7] qrisUrl:", qrisUrl?.slice(0, 80));
      }
    } catch (e) {
      console.log("[STEP7] invoice pay error (non-fatal):", (e as Error).message);
    }
  }

  sse(ctrl, "step", {
    id: 7,
    status: "done",
    message: invoicePaid
      ? `Invoice dilunasi otomatis (Rp 0) — domain segera aktif!`
      : qrisUrl
      ? `Order berhasil! Scan QRIS ShopeePay untuk aktivasi domain.`
      : orderSuccess
      ? `Order berhasil dibuat${orderId ? ` (Invoice #${orderId})` : ""}`
      : "Order diproses — cek email untuk konfirmasi",
    qrisUrl,
    invoicePaid,
    orderId,
  });

  // ══════════════════════════════════════════════
  // STEP 8: Selesai
  // ══════════════════════════════════════════��═══
  sse(ctrl, "step", {
    id: 8,
    status: "done",
    message: "Proses selesai! Domain gratis berhasil didaftarkan.",
  });

  sse(ctrl, "result", {
    success: true,
    email: tempEmail,
    password: accountPassword,
    domain: fullDomain,
    transactionId: orderId ?? `ORD-${Date.now()}`,
    orderId,
    promoCode: "DOMAINGRATIS",
    promoApplied: promoOk,
    finalPrice,
    memberArea: `${WHMCS}/clientarea.php`,
    inboxUrl: `${ZULZZMAIL}`,
    qrisUrl: qrisUrl ?? null,
    invoicePaid,
  });
}
