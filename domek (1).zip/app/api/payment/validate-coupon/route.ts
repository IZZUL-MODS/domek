import { NextRequest, NextResponse } from "next/server";
import { validateCoupon, hasRegisteredBefore } from "@/lib/db";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    const { email, couponCode } = await request.json();

    if (!email || !couponCode) {
      return NextResponse.json(
        { error: "Email dan coupon code diperlukan" },
        { status: 400 }
      );
    }

    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { error: "Email format tidak valid" },
        { status: 400 }
      );
    }

    // Check apakah email sudah pernah registrasi
    const hasRegistered = await hasRegisteredBefore(email);

    if (hasRegistered) {
      return NextResponse.json({
        valid: false,
        message: "Akun email ini sudah pernah menggunakan kupon. Harga menjadi Rp 45.000",
        price: 45000,
        isRepeatAccount: true,
      });
    }

    // Validate kupon
    const result = await validateCoupon(email, couponCode);

    return NextResponse.json(result);
  } catch (error) {
    console.error("[API] Validate coupon error:", error);
    return NextResponse.json(
      { error: "Server error" },
      { status: 500 }
    );
  }
}
