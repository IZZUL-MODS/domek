import { NextRequest, NextResponse } from "next/server";
import { updateOrderStatus, getOrder, recordCouponUsage } from "@/lib/db";
import { verifyCallbackSignature } from "@/lib/duitku";

export const runtime = "nodejs";

/**
 * Duitku akan callback ke endpoint ini setelah pembayaran berhasil/gagal
 * Callback berisi: merchantCode, amount, merchantOrderId, reference, signature, paymentMethod, resultCode
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    console.log("[Callback] Received Duitku callback:", body);

    // Parse query params (Duitku mengirim via query string atau form data)
    const url = new URL(request.url);
    const merchantCode = url.searchParams.get("merchantCode") || "";
    const amount = Number(url.searchParams.get("amount") || "0");
    const merchantOrderId = url.searchParams.get("merchantOrderId") || "";
    const reference = url.searchParams.get("reference") || "";
    const signature = url.searchParams.get("signature") || "";
    const resultCode = url.searchParams.get("resultCode") || "";
    const paymentMethod = url.searchParams.get("paymentMethod") || "";

    // Verify signature
    if (!verifyCallbackSignature(merchantCode, merchantOrderId, amount, signature)) {
      console.error("[Callback] Signature verification failed");
      return NextResponse.json(
        { error: "Signature verification failed" },
        { status: 401 }
      );
    }

    // Get order
    const order = await getOrder(merchantOrderId);
    if (!order) {
      console.error("[Callback] Order not found:", merchantOrderId);
      return NextResponse.json(
        { error: "Order not found" },
        { status: 404 }
      );
    }

    console.log("[Callback] Processing order:", {
      orderId: merchantOrderId,
      resultCode,
      reference,
    });

    // resultCode: 00 = sukses, selain itu = gagal
    if (resultCode === "00") {
      // Update order status to paid
      await updateOrderStatus(merchantOrderId, "paid", {
        transactionId: reference,
        referenceId: reference,
      });

      // Record coupon usage jika ada
      if (order.metadata?.couponUsed) {
        await recordCouponUsage(
          order.email,
          "", // We don't have coupon code in callback
          merchantOrderId
        );
      }

      console.log("[Callback] Payment successful:", merchantOrderId);

      // Return 200 agar Duitku tidak retry
      return NextResponse.json({
        success: true,
        message: "Payment recorded",
      });
    } else {
      // Update order status to failed
      await updateOrderStatus(merchantOrderId, "failed");

      console.log("[Callback] Payment failed:", {
        orderId: merchantOrderId,
        resultCode,
      });

      return NextResponse.json({
        success: false,
        message: "Payment failed",
      });
    }
  } catch (error) {
    console.error("[API] Callback error:", error);
    // Always return 200 untuk mencegah Duitku retry terus menerus
    return NextResponse.json(
      { error: "Processing error" },
      { status: 200 }
    );
  }
}
