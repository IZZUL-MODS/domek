import { NextRequest, NextResponse } from "next/server";
import { createOrder, hasRegisteredBefore } from "@/lib/db";
import { createQRISPayment } from "@/lib/duitku";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  try {
    const {
      email,
      domain,
      couponCode,
      amount,
    } = await request.json();

    if (!email || !domain || amount === undefined) {
      return NextResponse.json(
        { error: "Email, domain, dan amount diperlukan" },
        { status: 400 }
      );
    }

    // Validate amount
    if (amount !== 0 && amount !== 45000) {
      return NextResponse.json(
        { error: "Amount tidak valid" },
        { status: 400 }
      );
    }

    // Create order di database
    const couponUsed = amount === 0 && !!couponCode;
    const order = await createOrder(email, domain, amount, couponUsed);

    console.log("[Payment] Order created:", {
      orderId: order.id,
      email,
      domain,
      amount,
      couponUsed,
    });

    // Jika gratis (coupon), langsung return dengan status paid
    if (amount === 0) {
      return NextResponse.json({
        success: true,
        orderId: order.id,
        message: "Pembayaran tidak diperlukan (kupon gratis)",
        status: "paid",
        amount: 0,
      });
    }

    // Create QRIS payment
    const qrisResult = await createQRISPayment(
      order.id,
      amount,
      email,
      domain
    );

    if (!qrisResult.success) {
      return NextResponse.json(
        {
          success: false,
          error: qrisResult.error || "Gagal membuat QRIS payment",
        },
        { status: 500 }
      );
    }

    console.log("[Payment] QRIS created successfully:", {
      orderId: order.id,
      reference: qrisResult.data?.reference,
    });

    return NextResponse.json({
      success: true,
      orderId: order.id,
      reference: qrisResult.data?.reference,
      duitkuId: qrisResult.data?.duitkuId,
      qrString: qrisResult.qrString,
      qrUrl: qrisResult.qrUrl,
      paymentExpiry: qrisResult.data?.paymentExpiry,
      amount,
    });
  } catch (error) {
    console.error("[API] Create QRIS error:", error);
    return NextResponse.json(
      { error: "Server error" },
      { status: 500 }
    );
  }
}
