import { NextRequest, NextResponse } from "next/server";
import { getOrder } from "@/lib/db";
import { checkPaymentStatus as duikuCheckStatus } from "@/lib/duitku";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  try {
    const orderId = request.nextUrl.searchParams.get("orderId");

    if (!orderId) {
      return NextResponse.json(
        { error: "Order ID diperlukan" },
        { status: 400 }
      );
    }

    // Get order dari database
    const order = await getOrder(orderId);
    if (!order) {
      return NextResponse.json(
        { error: "Order tidak ditemukan" },
        { status: 404 }
      );
    }

    // Check payment status
    let status = order.status;

    // Jika masih pending, check ke Duitku
    if (status === "pending") {
      const duikuStatus = await duikuCheckStatus(orderId);
      if (duikuStatus.success && duikuStatus.status) {
        status = duikuStatus.status;
      }
    }

    return NextResponse.json({
      orderId,
      status,
      email: order.email,
      domain: order.domain,
      amount: order.amount,
      createdAt: order.createdAt,
      paidAt: order.paidAt,
    });
  } catch (error) {
    console.error("[API] Check status error:", error);
    return NextResponse.json(
      { error: "Server error" },
      { status: 500 }
    );
  }
}
