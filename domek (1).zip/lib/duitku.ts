import crypto from "crypto";

// ─────────────────────────────────────────────
// Duitku QRIS Configuration
// ─────────────────────────────────────────────

const DUITKU_API_URL = "https://sandbox.duitku.com/api/v1"; // Development
// const DUITKU_API_URL = "https://app.duitku.com/api/v1"; // Production

const DUITKU_MERCHANT_CODE = process.env.DUITKU_MERCHANT_CODE || "D12345678";
const DUITKU_API_KEY = process.env.DUITKU_API_KEY || "your-api-key-here";
const DUITKU_CALLBACK_URL = process.env.DUITKU_CALLBACK_URL || "http://localhost:3000/api/payment/callback";

// QRIS by Shopee reference: e62, value: duitku_shopee
const PAYMENT_METHOD = "duitku_shopee";

// ─────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────

export interface DuikuCreatePaymentRequest {
  merchantCode: string;
  paymentAmount: number;
  paymentMethod: string;
  merchantOrderId: string;
  productDetails: string;
  email: string;
  phoneNumber?: string;
  additionalParam?: string;
  customerVaName?: string;
  callbackUrl?: string;
  returnUrl?: string;
  expiryPeriod?: number;
  signature: string;
}

export interface DuikuCreatePaymentResponse {
  statusCode: string;
  statusMessage: string;
  merchantCode: string;
  merchantOrderId: string;
  reference: string;
  duitkuId: string;
  paymentMethod: string;
  paymentAmount: number;
  paymentCurrency: string;
  paymentTime: string;
  paymentExpiry: string;
  vaNumber?: string;
  qrString?: string;
  qrUrl?: string;
  isRedirect: number;
  redirectUrl: string;
  sessionId: string;
}

export interface DuikuCallbackData {
  merchantCode: string;
  amount: number;
  merchantOrderId: string;
  reference: string;
  signature: string;
  paymentMethod: string;
  resultCode: string;
  merchantUserId: string;
  customParam?: string;
  duitkuTransactionTimestamp: string;
  paymentStatusDesc?: string;
}

// ─────────────────────────────────────────────
// Signature Generation
// ─────────────────────────────────────────────

/**
 * Generate MD5 signature untuk Duitku request
 */
function generateSignature(
  merchantCode: string,
  merchantOrderId: string,
  paymentAmount: number,
  apiKey: string
): string {
  const signature = `${merchantCode}${merchantOrderId}${paymentAmount}${apiKey}`;
  return crypto.createHash("md5").update(signature).digest("hex");
}

/**
 * Verify MD5 signature dari Duitku callback
 */
export function verifyCallbackSignature(
  merchantCode: string,
  merchantOrderId: string,
  amount: number,
  signature: string
): boolean {
  const expectedSignature = generateSignature(merchantCode, merchantOrderId, amount, DUITKU_API_KEY);
  return signature === expectedSignature;
}

// ─────────────────────────────────────────────
// API Methods
// ─────────────────────────────────────────────

/**
 * Create payment QRIS request ke Duitku
 */
export async function createQRISPayment(
  merchantOrderId: string,
  amount: number,
  email: string,
  domain: string
): Promise<{
  success: boolean;
  data?: DuikuCreatePaymentResponse;
  error?: string;
  qrString?: string;
  qrUrl?: string;
}> {
  try {
    const signature = generateSignature(DUITKU_MERCHANT_CODE, merchantOrderId, amount, DUITKU_API_KEY);

    const payload: DuikuCreatePaymentRequest = {
      merchantCode: DUITKU_MERCHANT_CODE,
      paymentAmount: amount,
      paymentMethod: PAYMENT_METHOD, // duitku_shopee
      merchantOrderId,
      productDetails: `Registrasi Domain: ${domain}`,
      email,
      callbackUrl: DUITKU_CALLBACK_URL,
      returnUrl: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/payment-status/${merchantOrderId}`,
      expiryPeriod: 60, // 60 menit
      signature,
    };

    console.log("[Duitku] Creating QRIS payment:", { merchantOrderId, amount, paymentMethod: PAYMENT_METHOD });

    const response = await fetch(`${DUITKU_API_URL}/creditTransactionQR`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const data: DuikuCreatePaymentResponse = await response.json();

    if (!response.ok || data.statusCode !== "00") {
      console.error("[Duitku] Payment creation failed:", data);
      return {
        success: false,
        error: data.statusMessage || "Failed to create QRIS payment",
      };
    }

    console.log("[Duitku] Payment created successfully:", {
      reference: data.reference,
      duitkuId: data.duitkuId,
    });

    return {
      success: true,
      data,
      qrString: data.qrString,
      qrUrl: data.qrUrl,
    };
  } catch (error) {
    console.error("[Duitku] API Error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Check payment status ke Duitku
 */
export async function checkPaymentStatus(merchantOrderId: string): Promise<{
  success: boolean;
  status?: string;
  error?: string;
}> {
  try {
    const signature = generateSignature(
      DUITKU_MERCHANT_CODE,
      merchantOrderId,
      0, // amount=0 untuk check status
      DUITKU_API_KEY
    );

    const response = await fetch(`${DUITKU_API_URL}/transactionStatus`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        merchantCode: DUITKU_MERCHANT_CODE,
        merchantOrderId,
        signature,
      }),
    });

    const data = await response.json();

    if (!response.ok || data.statusCode !== "00") {
      return {
        success: false,
        error: data.statusMessage || "Failed to check payment status",
      };
    }

    return {
      success: true,
      status: data.paymentStatus,
    };
  } catch (error) {
    console.error("[Duitku] Check status error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}
