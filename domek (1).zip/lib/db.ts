import { kv } from "@vercel/kv";

// ─────────────────────────────────────────────
// Database Schema Types
// ─────────────────────────────────────────────

export interface CouponUsage {
  id: string;
  email: string;
  couponCode: string;
  usedAt: number;
  orderId: string;
}

export interface PaidOrder {
  id: string;
  email: string;
  domain: string;
  paymentMethod: "qris" | "other";
  amount: number;
  status: "pending" | "paid" | "completed" | "failed";
  duikuTransactionId?: string;
  duikuReferenceId?: string;
  qrString?: string;
  createdAt: number;
  paidAt?: number;
  completedAt?: number;
  metadata?: Record<string, any>;
}

// ─────────────────────────────────────────────
// Coupon Validation
// ─────────────────────────────────────────────

/**
 * Validasi kupon - check apakah email sudah pernah pakai kupon ini
 */
export async function validateCoupon(email: string, couponCode: string) {
  try {
    // Check apakah email sudah pernah pakai kupon
    const key = `coupon:${email}`;
    const existingUsage = await kv.get<CouponUsage>(key);

    if (existingUsage) {
      return {
        valid: false,
        message: "Akun email ini sudah pernah menggunakan kupon. Harga menjadi Rp 45.000",
        price: 45000,
        isRepeatAccount: true,
      };
    }

    // Validasi kupon kode (bisa dari database atau config)
    const validCoupons = (process.env.VALID_COUPONS || "").split(",").filter(Boolean);

    if (!validCoupons.includes(couponCode)) {
      return {
        valid: false,
        message: "Kode kupon tidak valid",
        price: 45000,
        isRepeatAccount: false,
      };
    }

    return {
      valid: true,
      message: "Kupon valid! Registrasi gratis",
      price: 0,
      isRepeatAccount: false,
    };
  } catch (error) {
    console.error("[DB] Coupon validation error:", error);
    return {
      valid: false,
      message: "Error saat validasi kupon",
      price: 45000,
      isRepeatAccount: false,
    };
  }
}

/**
 * Record penggunaan kupon
 */
export async function recordCouponUsage(
  email: string,
  couponCode: string,
  orderId: string
) {
  try {
    const usage: CouponUsage = {
      id: `${email}:${Date.now()}`,
      email,
      couponCode,
      usedAt: Date.now(),
      orderId,
    };

    // Store di Redis/KV dengan unique key per email
    const key = `coupon:${email}`;
    await kv.set(key, usage, { ex: 365 * 24 * 60 * 60 }); // 1 tahun

    return { success: true };
  } catch (error) {
    console.error("[DB] Record coupon usage error:", error);
    return { success: false };
  }
}

// ─────────────────────────────────────────────
// Payment Orders
// ─────────────────────────────────────────────

/**
 * Create order pembayaran
 */
export async function createOrder(
  email: string,
  domain: string,
  amount: number,
  couponUsed: boolean
): Promise<PaidOrder> {
  const order: PaidOrder = {
    id: `order_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    email,
    domain,
    paymentMethod: "qris",
    amount,
    status: "pending",
    createdAt: Date.now(),
    metadata: {
      couponUsed,
    },
  };

  try {
    const key = `order:${order.id}`;
    await kv.set(key, order, { ex: 24 * 60 * 60 }); // 24 jam
  } catch (error) {
    console.error("[DB] Create order error:", error);
  }

  return order;
}

/**
 * Get order by ID
 */
export async function getOrder(orderId: string): Promise<PaidOrder | null> {
  try {
    const key = `order:${orderId}`;
    return await kv.get<PaidOrder>(key);
  } catch (error) {
    console.error("[DB] Get order error:", error);
    return null;
  }
}

/**
 * Update order status
 */
export async function updateOrderStatus(
  orderId: string,
  status: PaidOrder["status"],
  duikuData?: {
    transactionId: string;
    referenceId: string;
    qrString?: string;
  }
) {
  try {
    const order = await getOrder(orderId);
    if (!order) return false;

    const updated: PaidOrder = {
      ...order,
      status,
      duikuTransactionId: duikuData?.transactionId,
      duikuReferenceId: duikuData?.referenceId,
      qrString: duikuData?.qrString,
      paidAt: status === "paid" ? Date.now() : order.paidAt,
      completedAt: status === "completed" ? Date.now() : order.completedAt,
    };

    const key = `order:${orderId}`;
    await kv.set(key, updated, { ex: 24 * 60 * 60 });
    return true;
  } catch (error) {
    console.error("[DB] Update order error:", error);
    return false;
  }
}

/**
 * Check apakah email sudah pernah registrasi domain (untuk price)
 */
export async function hasRegisteredBefore(email: string): Promise<boolean> {
  try {
    const key = `coupon:${email}`;
    const usage = await kv.get<CouponUsage>(key);
    return !!usage;
  } catch (error) {
    console.error("[DB] Check registered error:", error);
    return false;
  }
}
