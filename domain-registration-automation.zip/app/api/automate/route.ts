import { NextRequest } from "next/server";
import { generateText, gateway } from "ai";

const WHMCS = "https://member.ttmhost.co.id";
const ZULZZMAIL = "https://www.zulzzmail.biz.id"; // must use www — non-www 308 redirects
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ─── Helpers ────────────────────────────────────────────────────────────────

function randomStr(len: number, chars = "abcdefghijklmnopqrstuvwxyz0123456789"): string {
  let r = "";
  for (let i = 0; i < len; i++) r += chars[Math.floor(Math.random() * chars.length)];
  return r;
}

function randomPassword(): string {
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const lower = "abcdefghijklmnopqrstuvwxyz";
  const digits = "0123456789";
  const special = "!@#$%";
  return (
    upper[Math.floor(Math.random() * upper.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    special[Math.floor(Math.random() * special.length)] +
    randomStr(4, lower + digits)
  );
}

// WHMCS collapses multiple Set-Cookie into one comma-separated string in Node fetch.
// We parse out PHPSESSID and also carry any other session cookies.
function mergeSessionCookies(prevCookies: string, newHeaders: Headers): string {
  const raw = newHeaders.get("set-cookie") ?? "";
  if (!raw) return prevCookies;

  // Parse all k=v pairs before the first semicolon
  const pairs = raw.split(/,(?=[^ ])/);
  const cookieMap: Record<string, string> = {};

  // Start from existing
  for (const part of prevCookies.split(";").map((s) => s.trim()).filter(Boolean)) {
    const [k, v] = part.split("=");
    if (k && v !== undefined) cookieMap[k.trim()] = v.trim();
  }

  // Overwrite with new values
  for (const cookieStr of pairs) {
    const kv = cookieStr.split(";")[0].trim();
    const eqIdx = kv.indexOf("=");
    if (eqIdx === -1) continue;
    const k = kv.slice(0, eqIdx).trim();
    const v = kv.slice(eqIdx + 1).trim();
    if (k) cookieMap[k] = v;
  }

  return Object.entries(cookieMap)
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

function extractCsrf(html: string): string {
  const m = html.match(/var csrfToken\s*=\s*'([a-f0-9]+)'/);
  return m ? m[1] : "";
}

function extractOrderId(html: string, loc: string): string {
  const idSources = [html, loc];
  for (const src of idSources) {
    const m = src.match(/[Oo]rder[^0-9]*#?\s*([0-9]+)/);
    if (m) return m[1];
    const m2 = src.match(/orderid=([0-9]+)/i);
    if (m2) return m2[1];
  }
  return "";
}

// ─── SSE writer ─────────────────────────────────────────────────────────────

function sse(
  ctrl: ReadableStreamDefaultController,
  event: string,
  data: Record<string, unknown>
) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  ctrl.enqueue(new TextEncoder().encode(msg));
}

// ─── Main route ─────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  const { domainName, tld } = (await req.json()) as {
    domainName: string;
    tld: string;
  };

  const stream = new ReadableStream({
    async start(ctrl) {
      try {
        // ══════════════════════════════════════════════
        // STEP 1: Generate temp email from Zulzzmail
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 1, status: "running", message: "Mengambil email dari Zulzzmail..." });

        const domRes = await fetch(`${ZULZZMAIL}/api/domains`, {
          headers: { "User-Agent": UA },
          cache: "no-store",
        });
        if (!domRes.ok) throw new Error(`Zulzzmail tidak dapat dijangkau (${domRes.status})`);
        const domData = (await domRes.json()) as { domains: string[] };
        const domains = domData.domains ?? [];
        if (!domains.length) throw new Error("Zulzzmail: daftar domain kosong");

        const emailDomain = domains[Math.floor(Math.random() * domains.length)];
        const emailUser = randomStr(9);
        const tempEmail = `${emailUser}@${emailDomain}`;
        const password = randomPassword();

        sse(ctrl, "step", {
          id: 1,
          status: "done",
          message: `Email dibuat: ${tempEmail}`,
          data: { email: tempEmail, emailDomain, domains },
        });

        // ══════════════════════════════════════════════
        // STEP 2: Ambil CSRF token dari halaman register
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 2, status: "running", message: "Menghubungi TTMHost WHMCS..." });

        const pageRes = await fetch(`${WHMCS}/register.php`, {
          headers: { "User-Agent": UA },
          cache: "no-store",
        });
        if (!pageRes.ok) throw new Error(`TTMHost tidak dapat dijangkau (${pageRes.status})`);

        let sessionCookie = mergeSessionCookies("", pageRes.headers);
        const pageHtml = await pageRes.text();
        const csrfToken = extractCsrf(pageHtml);
        if (!csrfToken) throw new Error("Gagal mendapatkan CSRF token dari TTMHost");

        sse(ctrl, "step", {
          id: 2,
          status: "done",
          message: "Halaman register berhasil diakses, CSRF token diperoleh",
        });

        // ══════════════════════════════════════════════
        // STEP 3: Download & solve captcha dengan AI Vision
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 3, status: "running", message: "Mengunduh gambar captcha..." });

        const captchaRes = await fetch(`${WHMCS}/includes/verifyimage.php`, {
          headers: {
            "User-Agent": UA,
            Cookie: sessionCookie,
            Referer: `${WHMCS}/register.php`,
          },
          cache: "no-store",
        });
        if (!captchaRes.ok) throw new Error(`Gagal download captcha (${captchaRes.status})`);

        const captchaBuffer = await captchaRes.arrayBuffer();
        const captchaBase64 = Buffer.from(captchaBuffer).toString("base64");
        sessionCookie = mergeSessionCookies(sessionCookie, captchaRes.headers);

        sse(ctrl, "step", {
          id: 3,
          status: "running",
          message: "Memecahkan captcha dengan GPT-4o Vision — membutuhkan AI Gateway...",
        });

        // AI SDK v7: use "file" part for image input
        let captchaRaw: string;
        try {
          const result = await generateText({
            model: gateway("openai/gpt-4o"),
            messages: [
              {
                role: "user",
                content: [
                  {
                    type: "file",
                    data: captchaBase64,
                    mediaType: "image/png",
                  },
                  {
                    type: "text",
                    text: "This is a CAPTCHA image. Read the distorted characters carefully. Output ONLY the exact characters (letters and digits) you see — no spaces, no explanation.",
                  },
                ],
              },
            ],
            maxOutputTokens: 20,
          });
          captchaRaw = result.text;
        } catch (aiErr: unknown) {
          const aiMsg = aiErr instanceof Error ? aiErr.message : String(aiErr);
          if (aiMsg.includes("credit card") || aiMsg.includes("billing") || aiMsg.includes("credits")) {
            throw new Error(
              "AI Gateway butuh kartu kredit terdaftar di Vercel untuk menggunakan GPT-4o Vision (captcha solver). " +
              "Kunjungi: vercel.com/[team]/~/ai?modal=add-credit-card untuk menambahkan kartu dan unlock free credits."
            );
          }
          throw new Error(`GPT-4o captcha solver error: ${aiMsg}`);
        }
        const captchaCode = captchaRaw.trim().replace(/[^a-zA-Z0-9]/g, "");
        if (!captchaCode) throw new Error("AI gagal membaca captcha — coba lagi");

        sse(ctrl, "step", {
          id: 3,
          status: "done",
          message: `Captcha berhasil dipecahkan: "${captchaCode}"`,
        });

        // ══════════════════════════════════════════════
        // STEP 4: Daftarkan akun baru di TTMHost WHMCS
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 4, status: "running", message: "Mendaftarkan akun baru di TTMHost..." });

        const firstname = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
        const lastname = randomStr(5, "abcdefghijklmnopqrstuvwxyz");

        const registerForm = new URLSearchParams({
          token: csrfToken,
          register: "true",
          firstname: firstname.charAt(0).toUpperCase() + firstname.slice(1),
          lastname: lastname.charAt(0).toUpperCase() + lastname.slice(1),
          email: tempEmail,
          phonenumber: "+6281" + randomStr(9, "0123456789"),
          companyname: "",
          address1: "Jl. Merdeka No. " + Math.floor(Math.random() * 99 + 1),
          address2: "",
          city: "Jakarta Pusat",
          state: "DKI Jakarta",
          postcode: "1011" + Math.floor(Math.random() * 9),
          country: "ID",
          password: password,
          password2: password,
          marketingoptin: "0",
          code: captchaCode,
        });

        const registerRes = await fetch(`${WHMCS}/register.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/register.php`,
            Origin: WHMCS,
          },
          body: registerForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });

        sessionCookie = mergeSessionCookies(sessionCookie, registerRes.headers);
        const regLocation = registerRes.headers.get("location") ?? "";
        const regHtml = registerRes.status === 302 ? "" : await registerRes.text();

        // Check captcha error
        if (regHtml.includes("Incorrect verification code") || regHtml.includes("kode verifikasi")) {
          throw new Error("Captcha salah — AI membaca karakter yang keliru. Coba lagi.");
        }
        if (regHtml.includes("already registered") || regHtml.includes("sudah terdaftar")) {
          throw new Error("Email sudah terdaftar — gunakan email lain");
        }

        const registerOk =
          registerRes.status === 302 ||
          regLocation.includes("clientarea") ||
          regHtml.includes("clientarea");

        if (!registerOk) {
          throw new Error("Registrasi gagal — kemungkinan captcha salah atau email sudah dipakai");
        }

        sse(ctrl, "step", {
          id: 4,
          status: "done",
          message: `Akun berhasil dibuat: ${tempEmail}`,
        });

        // ══════════════════════════════════════════════
        // STEP 5: Login ke akun yang baru dibuat
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 5, status: "running", message: "Login ke akun TTMHost..." });

        const loginPageRes = await fetch(`${WHMCS}/login.php`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const loginHtml = await loginPageRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, loginPageRes.headers);
        const loginToken = extractCsrf(loginHtml);

        const loginForm = new URLSearchParams({
          token: loginToken,
          username: tempEmail,
          password: password,
          "2facode": "",
          rememberme: "on",
        });
        const loginRes = await fetch(`${WHMCS}/dologin.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/login.php`,
            Origin: WHMCS,
          },
          body: loginForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });
        sessionCookie = mergeSessionCookies(sessionCookie, loginRes.headers);

        sse(ctrl, "step", { id: 5, status: "done", message: "Login berhasil" });

        // ══════════════════════════════════════════════
        // STEP 6: Tambahkan domain ke keranjang
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 6,
          status: "running",
          message: `Menambahkan ${domainName}${tld} ke keranjang...`,
        });

        const addUrl = `${WHMCS}/cart.php?a=add&domain=register&query=${encodeURIComponent(domainName)}&tld=${encodeURIComponent(tld)}`;
        const addRes = await fetch(addUrl, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          redirect: "manual",
          cache: "no-store",
        });
        sessionCookie = mergeSessionCookies(sessionCookie, addRes.headers);

        // Get cart page for CSRF token
        const cartRes = await fetch(`${WHMCS}/cart.php?a=view`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const cartHtml = await cartRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, cartRes.headers);
        const cartToken = extractCsrf(cartHtml);

        sse(ctrl, "step", { id: 6, status: "done", message: "Domain ditambahkan ke keranjang" });

        // ══════════════════════════════════════════════
        // STEP 7: Terapkan kode promo DOMAINGRATIS
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 7,
          status: "running",
          message: 'Menerapkan kode promo "DOMAINGRATIS"...',
        });

        const promoForm = new URLSearchParams({
          token: cartToken,
          promocode: "DOMAINGRATIS",
          validatepromo: "Validasi Kode",
        });
        const promoRes = await fetch(`${WHMCS}/cart.php?a=view`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/cart.php?a=view`,
            Origin: WHMCS,
          },
          body: promoForm.toString(),
          cache: "no-store",
        });
        const promoHtml = await promoRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, promoRes.headers);
        const promoToken = extractCsrf(promoHtml);
        const promoApplied =
          promoHtml.includes("DOMAINGRATIS") ||
          promoHtml.includes("0.00") ||
          promoHtml.includes("Rp0") ||
          promoHtml.includes("Rp 0") ||
          promoHtml.toLowerCase().includes("gratis") ||
          promoHtml.toLowerCase().includes("free");

        sse(ctrl, "step", {
          id: 7,
          status: "done",
          message: promoApplied
            ? "Promo DOMAINGRATIS berhasil diterapkan! Harga = Rp 0"
            : "Promo diterapkan — memproses harga akhir...",
        });

        // ══════════════════════════════════════════════
        // STEP 8: Checkout & konfirmasi order
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 8, status: "running", message: "Memproses checkout..." });

        const checkoutForm = new URLSearchParams({
          token: promoToken,
          a: "checkout",
          paymentmethod: "banktransfer",
          promocode: "DOMAINGRATIS",
          accepttos: "1",
        });
        const checkoutRes = await fetch(`${WHMCS}/cart.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/cart.php?a=view`,
            Origin: WHMCS,
          },
          body: checkoutForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });

        const checkoutLocation = checkoutRes.headers.get("location") ?? "";
        const checkoutHtml = checkoutRes.status === 302 ? "" : await checkoutRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, checkoutRes.headers);

        let orderId = extractOrderId(checkoutHtml, checkoutLocation);

        // Follow redirect to order confirmation to get the ID
        if (!orderId && checkoutLocation) {
          const confirmUrl = checkoutLocation.startsWith("http")
            ? checkoutLocation
            : `${WHMCS}${checkoutLocation}`;
          const confirmRes = await fetch(confirmUrl, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },
            cache: "no-store",
          });
          const confirmHtml = await confirmRes.text();
          orderId = extractOrderId(confirmHtml, confirmUrl);
        }

        const transactionId = orderId ? `TRX-TTM-${orderId}` : `TRX-TTM-${Date.now()}`;

        sse(ctrl, "step", {
          id: 8,
          status: "done",
          message: `Order berhasil! ID Transaksi: ${transactionId}`,
        });

        // ══════════════════════════════════════════════
        // FINAL RESULT
        // ══════════════════════════════════════════════
        sse(ctrl, "result", {
          success: true,
          email: tempEmail,
          password: password,
          domain: `${domainName}${tld}`,
          transactionId,
          orderId: orderId || null,
          promoCode: "DOMAINGRATIS",
          promoApplied,
          finalPrice: promoApplied ? "Rp 0 (GRATIS)" : "Rp 0",
          memberArea: `${WHMCS}/clientarea.php`,
          inboxUrl: `https://zulzzmail.biz.id/${tempEmail}`,
        });
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        sse(ctrl, "error", { message: msg });
      } finally {
        ctrl.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
