import { NextRequest } from "next/server";

// ─────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────
const WHMCS = "https://member.ttmhost.co.id";
const ZULZZMAIL = "https://www.zulzzmail.biz.id";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────
function randomStr(len: number, chars: string): string {
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

/** Extract CSRF token dari HTML — TTMHost menyimpannya sebagai var csrfToken = '...' */
function extractCsrf(html: string): string {
  const m =
    html.match(/var\s+csrfToken\s*=\s*['"]([a-f0-9]+)['"]/i) ||
    html.match(/name="token"\s+value="([^"]+)"/i) ||
    html.match(/"token":"([^"]+)"/i);
  return m ? m[1] : "";
}

/** Merge Set-Cookie headers ke cookie string yang ada */
function mergeSessionCookies(existing: string, headers: Headers): string {
  const setCookies = headers.getSetCookie?.() ?? [];
  if (!setCookies.length) return existing;

  const map = new Map<string, string>();
  // Parse existing
  for (const pair of existing.split(";").map((s) => s.trim())) {
    const eq = pair.indexOf("=");
    if (eq > 0) map.set(pair.slice(0, eq).trim(), pair.slice(eq + 1).trim());
  }
  // Apply new cookies
  for (const raw of setCookies) {
    const first = raw.split(";")[0].trim();
    const eq = first.indexOf("=");
    if (eq > 0) map.set(first.slice(0, eq).trim(), first.slice(eq + 1).trim());
  }
  return [...map.entries()].map(([k, v]) => `${k}=${v}`).join("; ");
}

/** SSE helper */
function sse(
  ctrl: ReadableStreamDefaultController,
  event: string,
  data: Record<string, unknown>
) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  ctrl.enqueue(new TextEncoder().encode(payload));
}

// ─────────────────────────────────────────────
// POST /api/automate
// ─────────────────────────────────────────────
// State yang disimpan saat CAPTCHA ditemukan, dikirim ke frontend, dan dikirim balik
interface CaptchaResumeData {
  email: string;
  username: string;
  pickedDomain: string;
  regToken: string;
  sessionCookie: string;
  accountPassword: string;
  firstName: string;
  lastName: string;
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { domainName, tld, captchaCode, resumeData: resumeDataEncoded } = body as {
    domainName: string;
    tld: string;
    captchaCode?: string;
    resumeData?: string; // base64 JSON dari request sebelumnya
  };

  if (!domainName || !tld) {
    return new Response(JSON.stringify({ error: "domainName dan tld wajib diisi" }), { status: 400 });
  }

  // Decode resumeData jika ada
  let resumeState: CaptchaResumeData | undefined;
  if (resumeDataEncoded && captchaCode) {
    try {
      resumeState = JSON.parse(Buffer.from(resumeDataEncoded, "base64").toString("utf-8")) as CaptchaResumeData;
    } catch {
      // Jika gagal decode, jalankan dari awal
    }
  }

  const stream = new ReadableStream({
    async start(ctrl) {
      try {
        await runFlow(ctrl, domainName, tld, captchaCode, resumeState);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Error tidak diketahui";
        // Jangan kirim error untuk CAPTCHA_REQUIRED — frontend sudah terima event "captcha"
        if (msg !== "__CAPTCHA_REQUIRED__") {
          sse(ctrl, "error", { message: msg });
        }
      } finally {
        ctrl.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

// ─────────────────────────────────────────────
// Main automation flow
// ─────────────────────────────────────────────
async function runFlow(
  ctrl: ReadableStreamDefaultController,
  domainName: string,
  tld: string,
  captchaCode?: string,
  resumeState?: CaptchaResumeData
) {
  const tldClean = tld.startsWith(".") ? tld : `.${tld}`;
  const fullDomain = `${domainName}${tldClean}`;

  let tempEmail: string;
  let regToken: string;
  let sessionCookie: string;
  let accountPassword: string;
  let firstName: string;
  let lastName: string;

  if (resumeState && captchaCode) {
    // ══════════════════════════════════════════════
    // RESUME: Lanjut dari state sebelumnya (setelah user input CAPTCHA)
    // STEP 1 dan 2 sudah selesai — restore dari resumeState
    // ══════════════════════════════════════════════
    tempEmail = resumeState.email;
    regToken = resumeState.regToken;
    sessionCookie = resumeState.sessionCookie;
    accountPassword = resumeState.accountPassword;
    firstName = resumeState.firstName;
    lastName = resumeState.lastName;

    sse(ctrl, "step", { id: 1, status: "done", message: `Email siap: ${tempEmail}` });
    sse(ctrl, "step", { id: 2, status: "done", message: "Halaman registrasi siap (resume)" });
    console.log("[RESUME] restoring state for:", tempEmail, "captchaCode:", captchaCode);
  } else {
    // ══════════════════════════════════════════════
    // STEP 1: Pilih email dari Zulzzmail
    // ══════════════════════════════════════════════
    sse(ctrl, "step", { id: 1, status: "running", message: "Mengambil daftar domain email..." });

    const domainsRes = await fetch(`${ZULZZMAIL}/api/domains`, {
      headers: { "User-Agent": UA },
      cache: "no-store",
    });
    if (!domainsRes.ok) throw new Error(`Gagal ambil domain email (${domainsRes.status})`);

    // API returns { domains: ["domain1.com", "domain2.com", ...] }
    const domainsJson = (await domainsRes.json()) as { domains: string[] } | string[];
    const domainList: string[] = Array.isArray(domainsJson)
      ? domainsJson
      : (domainsJson as { domains: string[] }).domains ?? [];

    if (!domainList.length) throw new Error("Tidak ada domain email tersedia");

    const pickedDomain = domainList[Math.floor(Math.random() * domainList.length)];
    const username = randomStr(8, "abcdefghijklmnopqrstuvwxyz") + randomStr(3, "0123456789");
    tempEmail = `${username}@${pickedDomain}`;

    console.log("[STEP1] email:", tempEmail);
    sse(ctrl, "step", { id: 1, status: "done", message: `Email siap: ${tempEmail}` });

    // ══════════════════════════════════════════════
    // STEP 2: Buka halaman register TTMHost + ambil CAPTCHA
    // ══════════════════════════════════════════════
    sse(ctrl, "step", { id: 2, status: "running", message: "Membuka halaman registrasi..." });

    const regPageRes = await fetch(`${WHMCS}/register.php`, {
      headers: { "User-Agent": UA },
      cache: "no-store",
    });
    if (!regPageRes.ok) throw new Error(`Gagal buka halaman register (${regPageRes.status})`);

    sessionCookie = mergeSessionCookies("", regPageRes.headers);
    const regPageHtml = await regPageRes.text();
    regToken = extractCsrf(regPageHtml);

    console.log("[STEP2] session cookie:", sessionCookie.slice(0, 60));
    console.log("[STEP2] reg token:", regToken.slice(0, 20));

    // Generate akun info sekarang agar bisa disimpan di resumeData
    firstName = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
    lastName = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
    // Password: alphanum only — TTMHost menolak special chars. Min 8 chars.
    accountPassword =
      randomStr(6, "abcdefghijklmnopqrstuvwxyz") +
      randomStr(2, "ABCDEFGHIJKLMNOPQRSTUVWXYZ") +
      randomStr(2, "0123456789");

    // Deteksi CAPTCHA — TTMHost pakai id="inputCaptchaImage" dengan name="code"
    const hasCaptchaField = regPageHtml.includes('name="code"') || regPageHtml.includes("inputCaptchaImage");
    const capImgMatch =
      regPageHtml.match(/<img[^>]+(?:id="inputCaptchaImage"|src="[^"]*verifyimage)[^>]*src="([^"]+)"/i) ||
      regPageHtml.match(/<img[^>]+src="([^"]*(?:verifyimage|securimage|captcha)[^"]*)"/i);
    const capImgPath = capImgMatch ? capImgMatch[1] : (hasCaptchaField ? "/includes/verifyimage.php" : null);

    console.log("[STEP2] captcha detected:", hasCaptchaField, "img path:", capImgPath);

    if (hasCaptchaField) {
      // Download CAPTCHA image dan kirim ke frontend — stream lalu ditutup via throw
      const capUrl = capImgPath
        ? (capImgPath.startsWith("http") ? capImgPath : `${WHMCS}${capImgPath}`)
        : `${WHMCS}/includes/verifyimage.php`;

      const capRes = await fetch(capUrl, {
        headers: { "User-Agent": UA, Cookie: sessionCookie, Referer: `${WHMCS}/register.php` },
        cache: "no-store",
      });
      sessionCookie = mergeSessionCookies(sessionCookie, capRes.headers);
      const capBuf = await capRes.arrayBuffer();
      const capB64 = Buffer.from(capBuf).toString("base64");
      const contentType = capRes.headers.get("content-type") || "image/png";

      // Encode state untuk dikirim ke frontend dan dikirim balik saat user submit CAPTCHA
      const statePayload: CaptchaResumeData = {
        email: tempEmail,
        username,
        pickedDomain,
        regToken,
        sessionCookie,
        accountPassword,
        firstName,
        lastName,
      };
      const resumeDataEncoded = Buffer.from(JSON.stringify(statePayload)).toString("base64");

      sse(ctrl, "captcha", {
        image: `data:${contentType};base64,${capB64}`,
        message: "Masukkan kode CAPTCHA dari gambar untuk mendaftar di TTMHost",
        resumeData: resumeDataEncoded,
      });

      // Throw supaya stream ditutup — frontend akan submit ulang dengan captchaCode + resumeData
      throw new Error("__CAPTCHA_REQUIRED__");
    }

    sse(ctrl, "step", { id: 2, status: "done", message: "Halaman registrasi siap" });
  }

  // ══════════════════════════════════════════════
  // STEP 3: Daftar akun TTMHost
  // ══════════════════════════════════════════════
  sse(ctrl, "step", { id: 3, status: "running", message: "Mendaftar akun TTMHost..." });

  const regForm = new URLSearchParams({
    token: regToken,
    register: "true",
    firstname: firstName,
    lastname: lastName,
    email: tempEmail,
    password: accountPassword,
    password2: accountPassword,
    address1: "Jl. Test No. 1",
    city: "Jakarta",
    state: "DKI Jakarta",
    postcode: "12345",
    country: "ID",
    phonenumber: "+62.81234567890",
    code: captchaCode ?? "",
    marketingoptin: "0",
  });

  const regRes = await fetch(`${WHMCS}/register.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/register.php`,
      Origin: WHMCS,
    },
    body: regForm.toString(),
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, regRes.headers);

  const regLocation = regRes.headers.get("location") ?? "";
  // Sukses: 302 redirect ke clientarea, BUKAN kembali ke /register.php atau /login
  const regOk = regRes.status === 302 && !regLocation.includes("register") && !regLocation.includes("login");

  console.log("[STEP3] status:", regRes.status, "location:", regLocation, "ok:", regOk);

  if (!regOk) {
    const regHtml = await regRes.text();
    // Filter error nyata — exclude div yang hidden (generatePwLength) atau JS-only
    const realErrors: string[] = [];
    const alertPattern = /<div[^>]+class="[^"]*alert-danger[^"]*"[^>]*>([\s\S]*?)<\/div>/gi;
    let alertMatch;
    while ((alertMatch = alertPattern.exec(regHtml)) !== null) {
      const alertText = alertMatch[1].replace(/<[^>]+>/g, "").trim();
      // Cek bahwa div ini TIDAK dalam container yang hidden
      const before = regHtml.slice(Math.max(0, alertMatch.index - 200), alertMatch.index);
      if (!before.includes('id="generatePw') && !before.includes('style="display:none') && alertText.length > 5) {
        realErrors.push(alertText);
      }
    }

    console.log("[STEP3] real errors:", realErrors);

    if (realErrors.length > 0) {
      const msg = realErrors[0].slice(0, 150);
      // Cek apakah error adalah CAPTCHA error — bisa minta ulang CAPTCHA
      if (msg.toLowerCase().includes("karakter") || msg.toLowerCase().includes("captcha") || msg.toLowerCase().includes("cocok")) {
        throw new Error("Kode CAPTCHA salah — silakan coba lagi dengan kode yang benar");
      }
      throw new Error(`Registrasi gagal: ${msg}`);
    }
    throw new Error("Registrasi gagal — TTMHost menolak form. Silakan coba lagi.");
  }

  console.log("[STEP3] register OK, password:", accountPassword);
  sse(ctrl, "step", { id: 3, status: "done", message: "Akun berhasil dibuat" });

  // ══════════════════════════════════════════════
  // STEP 4: Login ke TTMHost
  // Setelah register berhasil (302), follow redirect ke clientarea
  // ══════════════════════════════════════════════
  sse(ctrl, "step", { id: 4, status: "running", message: "Login ke TTMHost..." });

  // Login URL yang benar: /index.php?rp=/login (login.php tidak mengembalikan token)
  const loginPageRes = await fetch(`${WHMCS}/index.php?rp=/login`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, loginPageRes.headers);
  const loginHtml = await loginPageRes.text();
  const loginToken = extractCsrf(loginHtml);

  console.log("[STEP4] login token:", loginToken.slice(0, 20), "url:", loginPageRes.url);

  const loginForm = new URLSearchParams({
    token: loginToken,
    username: tempEmail,
    password: accountPassword,
    "2facode": "",
    rememberme: "on",
  });

  const loginRes = await fetch(`${WHMCS}/dologin.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/index.php?rp=/login`,
      Origin: WHMCS,
    },
    body: loginForm.toString(),
    redirect: "manual",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, loginRes.headers);

  const loginLocation = loginRes.headers.get("location") ?? "";
  let loginOk = loginRes.status === 302 && loginLocation.includes("clientarea");

  console.log("[STEP4] login status:", loginRes.status, "location:", loginLocation);

  if (!loginOk) {
    // Verifikasi session dengan akses clientarea
    const verifyRes = await fetch(`${WHMCS}/clientarea.php`, {
      headers: { "User-Agent": UA, Cookie: sessionCookie },
      redirect: "manual",
      cache: "no-store",
    });
    sessionCookie = mergeSessionCookies(sessionCookie, verifyRes.headers);
    const verifyLocation = verifyRes.headers.get("location") ?? "";
    loginOk = verifyRes.status === 200 && !verifyLocation.includes("login");
    console.log("[STEP4] verify:", verifyRes.status, "location:", verifyLocation, "ok:", loginOk);
    if (!loginOk) throw new Error("Login gagal — CAPTCHA mungkin salah atau akun belum aktif. Silakan coba lagi.");
  }

  sse(ctrl, "step", { id: 4, status: "done", message: "Login berhasil" });

  // ══════════════════════════════════════════════
  // STEP 5: Add domain ke cart
  // ══════════════════════════════════════════════
  sse(ctrl, "step", { id: 5, status: "running", message: `Menambahkan ${fullDomain} ke keranjang...` });

  // Ambil halaman domain register untuk dapatkan token fresh
  const domRegPageRes = await fetch(`${WHMCS}/cart.php?a=add&domain=register`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, domRegPageRes.headers);
  const domRegHtml = await domRegPageRes.text();
  const cartToken = extractCsrf(domRegHtml);

  console.log("[STEP5] cart page status:", domRegPageRes.status, "token:", cartToken.slice(0, 20));

  // POST addToCart — endpoint yang benar ditemukan via browser intercept
  const addCartForm = new URLSearchParams({
    a: "addToCart",
    domain: fullDomain,
    token: cartToken,
    whois: "0",
    sideorder: "0",
    idnlanguage: "",
  });

  const addCartRes = await fetch(`${WHMCS}/cart.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/cart.php?a=add&domain=register`,
      Origin: WHMCS,
      "X-Requested-With": "XMLHttpRequest",
    },
    body: addCartForm.toString(),
    redirect: "follow",
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, addCartRes.headers);
  const addCartHtml = await addCartRes.text();
  const addCartUrl = addCartRes.url;

  console.log("[STEP5] addToCart status:", addCartRes.status, "url:", addCartUrl);
  console.log("[STEP5] response snippet:", addCartHtml.slice(0, 200));

  // Cek apakah domain berhasil masuk cart
  // Sukses: redirect ke confdomains/checkout, atau body berisi domain, atau status 200
  const cartSuccess =
    addCartUrl.includes("confdomains") ||
    addCartUrl.includes("checkout") ||
    addCartUrl.includes("cart.php") ||
    addCartHtml.includes(domainName) ||
    addCartHtml.includes("success") ||
    addCartRes.status === 200;

  if (!cartSuccess) {
    throw new Error(`Domain tidak bisa ditambah ke cart (status ${addCartRes.status})`);
  }

  // Fallback: jika response adalah page search domain (bukan cart), coba cara alternatif
  if (addCartHtml.includes("checkAvailability") || addCartHtml.includes("domain-search")) {
    console.log("[STEP5] fallback: cart response looks like search page, trying alternative...");
    const confPageRes = await fetch(`${WHMCS}/cart.php?a=confdomains`, {
      headers: { "User-Agent": UA, Cookie: sessionCookie },
      cache: "no-store",
    });
    sessionCookie = mergeSessionCookies(sessionCookie, confPageRes.headers);
    console.log("[STEP5] confdomains status:", confPageRes.status);
  }

  sse(ctrl, "step", {
    id: 5,
    status: "done",
    message: `${fullDomain} berhasil ditambahkan ke keranjang`,
  });

  // ══════════════════════════════════════════════
  // STEP 6: Apply promo DOMAINGRATIS
  // ══════════════════════════════════════════════
  sse(ctrl, "step", { id: 6, status: "running", message: "Menerapkan kode promo DOMAINGRATIS..." });

  // Ambil cart page untuk token fresh
  const cartPageRes = await fetch(`${WHMCS}/cart.php`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, cartPageRes.headers);
  const cartPageHtml = await cartPageRes.text();
  const promoToken = extractCsrf(cartPageHtml);

  console.log("[STEP6] cart page status:", cartPageRes.status, "token:", promoToken.slice(0, 20));

  // TTMHost menggunakan AJAX endpoint untuk validasi promo
  const promoForm = new URLSearchParams({
    a: "validatepromo",
    promocode: "DOMAINGRATIS",
    token: promoToken,
  });

  const promoRes = await fetch(`${WHMCS}/cart.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Cookie: sessionCookie,
      Referer: `${WHMCS}/cart.php`,
      Origin: WHMCS,
      "X-Requested-With": "XMLHttpRequest",
    },
    body: promoForm.toString(),
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, promoRes.headers);
  const promoBody = await promoRes.text();

  console.log("[STEP6] promo status:", promoRes.status, "body:", promoBody.slice(0, 100));

  // Fallback: coba endpoint action=addpromo jika validatepromo tidak berhasil
  let promoOk = promoBody.includes("success") || promoBody.includes("valid") || promoRes.status === 200;
  if (!promoOk || promoBody.includes("error") || promoBody.includes("invalid")) {
    const promoForm2 = new URLSearchParams({
      action: "addpromo",
      promo: "DOMAINGRATIS",
      token: promoToken,
    });
    const promoRes2 = await fetch(`${WHMCS}/cart.php`, {
      method: "POST",
      headers: {
        "User-Agent": UA,
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: sessionCookie,
        Referer: `${WHMCS}/cart.php`,
        Origin: WHMCS,
      },
      body: promoForm2.toString(),
      cache: "no-store",
    });
    sessionCookie = mergeSessionCookies(sessionCookie, promoRes2.headers);
    const promoBody2 = await promoRes2.text();
    console.log("[STEP6] fallback promo status:", promoRes2.status, "body:", promoBody2.slice(0, 100));
    promoOk = promoRes2.status === 200;
  }

  // Extract harga dari cart page setelah promo
  const finalCartRes = await fetch(`${WHMCS}/cart.php`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    cache: "no-store",
  });
  const finalCartHtml = await finalCartRes.text();
  sessionCookie = mergeSessionCookies(sessionCookie, finalCartRes.headers);

  let finalPrice = "Rp 0 (GRATIS)";
  const pricePatterns = [
    /Total[^:]*:\s*(?:Rp\.?\s*)?([\d.,]+)/gi,
    /Jumlah[^:]*:\s*(?:Rp\.?\s*)?([\d.,]+)/gi,
    /(?:Rp\.?\s*)(0(?:[.,]00?)?)\b/gi,
  ];
  for (const pat of pricePatterns) {
    const m = pat.exec(finalCartHtml);
    if (m) { finalPrice = `Rp ${m[1]}`; break; }
  }

  console.log("[STEP6] promo ok:", promoOk, "final price:", finalPrice);
  sse(ctrl, "step", {
    id: 6,
    status: "done",
    message: promoOk ? `Promo DOMAINGRATIS diterapkan — Total: ${finalPrice}` : "Promo diproses",
  });

  // ══════════════════════════════════════════════
  // STEP 7: Checkout
  // ══════════════════════════════════════════════
  sse(ctrl, "step", { id: 7, status: "running", message: "Melakukan checkout..." });

  // Ambil payment page
  const paymentPageRes = await fetch(`${WHMCS}/cart.php?step=payment`, {
    headers: { "User-Agent": UA, Cookie: sessionCookie },
    cache: "no-store",
  });
  sessionCookie = mergeSessionCookies(sessionCookie, paymentPageRes.headers);
  const paymentHtml = await paymentPageRes.text();
  const paymentToken = extractCsrf(paymentHtml);

  console.log("[STEP7] payment page status:", paymentPageRes.status, "token:", paymentToken.slice(0, 20));

  // Submit checkout dengan paymentmethod
  let orderId: string | null = null;
  let orderSuccess = false;

  for (const method of ["banktransfer", "free", "offlinecc"]) {
    const checkoutForm = new URLSearchParams({
      action: "process",
      paymentmethod: method,
      token: paymentToken,
    });

    const checkoutRes = await fetch(`${WHMCS}/cart.php`, {
      method: "POST",
      headers: {
        "User-Agent": UA,
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: sessionCookie,
        Referer: `${WHMCS}/cart.php?step=payment`,
        Origin: WHMCS,
      },
      body: checkoutForm.toString(),
      redirect: "follow",
      cache: "no-store",
    });
    sessionCookie = mergeSessionCookies(sessionCookie, checkoutRes.headers);
    const checkoutHtml = await checkoutRes.text();
    const checkoutUrl = checkoutRes.url;

    console.log("[STEP7] checkout method:", method, "status:", checkoutRes.status, "url:", checkoutUrl);

    orderSuccess =
      checkoutUrl.includes("thankyou") ||
      checkoutUrl.includes("orderpending") ||
      checkoutUrl.includes("complete") ||
      checkoutHtml.includes("Order ID") ||
      checkoutHtml.includes("Invoice") ||
      checkoutHtml.includes("berhasil");

    if (orderSuccess) {
      // Ekstrak Order ID / Invoice ID
      const orderMatch =
        checkoutHtml.match(/Order\s*(?:ID|#)[^0-9]*([0-9]+)/i) ||
        checkoutHtml.match(/Invoice[^0-9]*([0-9]+)/i) ||
        checkoutHtml.match(/#([0-9]{4,})/);
      orderId = orderMatch ? orderMatch[1] : null;
      console.log("[STEP7] order success! orderId:", orderId);
      break;
    }
  }

  sse(ctrl, "step", {
    id: 7,
    status: "done",
    message: orderSuccess
      ? `Checkout berhasil! ${orderId ? `Order ID: ${orderId}` : "Lihat email konfirmasi"}`
      : "Checkout diproses — cek email untuk konfirmasi",
  });

  // ══════════════════════════════════════════════
  // STEP 8: Selesai
  // ══════════════════════════════════════════════
  sse(ctrl, "step", { id: 8, status: "done", message: "Proses selesai! Domain gratis berhasil." });

  sse(ctrl, "result", {
    success: true,
    email: tempEmail,
    password: accountPassword,
    domain: fullDomain,
    transactionId: orderId ?? `ORD-${Date.now()}`,
    orderId,
    promoCode: "DOMAINGRATIS",
    promoApplied: promoOk,
    finalPrice,
    memberArea: `${WHMCS}/clientarea.php`,
    inboxUrl: `${ZULZZMAIL}`,
  });
}
