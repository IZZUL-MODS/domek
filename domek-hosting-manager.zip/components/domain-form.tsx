"use client";

import { useState, useRef } from "react";
import { StepTracker, type Step } from "./step-tracker";
import { ResultCard, type OrderResult } from "./result-card";
import { CaptchaModal } from "./captcha-modal";

const TLDS = [
  { value: ".my.id", label: ".my.id", desc: "Personal" },
  { value: ".biz.id", label: ".biz.id", desc: "Bisnis" },
  { value: ".web.id", label: ".web.id", desc: "Website" },
];

interface CaptchaData {
  image: string;
  message: string;
  resumeData?: string; // base64 JSON dari backend untuk resume setelah CAPTCHA
}

export function DomainForm() {
  const [domainName, setDomainName] = useState("");
  const [tld, setTld] = useState(".my.id");
  const [steps, setSteps] = useState<Step[]>([]);
  const [result, setResult] = useState<OrderResult | null>(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [captchaData, setCaptchaData] = useState<CaptchaData | null>(null);
  const pendingDomainRef = useRef<{ domainName: string; tld: string } | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const updateStep = (update: Partial<Step> & { id: number }) => {
    setSteps((prev) => {
      const exists = prev.find((s) => s.id === update.id);
      if (exists) return prev.map((s) => (s.id === update.id ? { ...s, ...update } : s));
      return [...prev, { label: "", message: "", status: "idle" as const, ...update }];
    });
  };

  // Saat user submit kode CAPTCHA: kirim ulang POST dengan captchaCode + resumeData (state dari request pertama)
  const handleCaptchaSubmit = async (code: string) => {
    const pending = pendingDomainRef.current;
    if (!pending) return;

    const currentCaptcha = captchaData; // simpan sebelum clear
    setCaptchaData(null);
    setErrorMsg("");
    setLoading(true);
    // Jangan reset steps — tampilkan yang sudah ada

    abortRef.current = new AbortController();
    try {
      const body: Record<string, string> = {
        domainName: pending.domainName,
        tld: pending.tld,
        captchaCode: code,
      };
      // Kirim resumeData agar backend bisa pakai session + token yang sama
      if (currentCaptcha?.resumeData) {
        body.resumeData = currentCaptcha.resumeData;
      }
      const res = await fetch("/api/automate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: abortRef.current.signal,
      });
      await processStream(res);
    } catch (err: unknown) {
      if (err instanceof Error && err.name !== "AbortError") setErrorMsg(err.message);
    } finally {
      setLoading(false);
    }
  };

  const processStream = async (res: Response) => {
    if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split("\n\n");
      buffer = parts.pop() ?? "";

      for (const part of parts) {
        let event = "";
        let data = "";
        for (const line of part.split("\n")) {
          if (line.startsWith("event: ")) event = line.slice(7).trim();
          if (line.startsWith("data: ")) data = line.slice(6).trim();
        }
        if (!event || !data) continue;
        try {
          const parsed = JSON.parse(data);
          if (event === "step") {
            updateStep({ id: parsed.id, status: parsed.status, message: parsed.message, label: parsed.label ?? "" });
          } else if (event === "captcha") {
            // Backend mendeteksi CAPTCHA dan stream ditutup — tampilkan modal dengan resumeData
            setCaptchaData({
              image: parsed.image,
              message: parsed.message,
              resumeData: parsed.resumeData, // base64 state untuk resume
            });
          } else if (event === "result") {
            setResult(parsed as OrderResult);
          } else if (event === "error") {
            if (parsed.message !== "__CAPTCHA_REQUIRED__") {
              // Jika error CAPTCHA salah, minta CAPTCHA baru otomatis
              const isCaptchaWrong =
                typeof parsed.message === "string" &&
                (parsed.message.includes("CAPTCHA salah") || parsed.message.includes("captcha"));
              if (isCaptchaWrong) {
                // Restart dari awal untuk ambil CAPTCHA baru
                setErrorMsg("Kode CAPTCHA salah — memuat CAPTCHA baru...");
                const pending = pendingDomainRef.current;
                if (pending) {
                  setTimeout(async () => {
                    setErrorMsg("");
                    setSteps([]);
                    setLoading(true);
                    try {
                      const res = await fetch("/api/automate", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ domainName: pending.domainName, tld: pending.tld }),
                      });
                      await processStream(res);
                    } catch { /* ignore */ } finally {
                      setLoading(false);
                    }
                  }, 1500);
                }
              } else {
                setErrorMsg(parsed.message ?? "Terjadi kesalahan");
              }
            }
          }
        } catch { /* ignore */ }
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = domainName.trim().toLowerCase().replace(/[^a-z0-9-]/g, "");
    if (!name) return;

    // Simpan untuk dipakai ulang jika CAPTCHA diperlukan
    pendingDomainRef.current = { domainName: name, tld };

    setLoading(true);
    setSteps([]);
    setResult(null);
    setErrorMsg("");
    setCaptchaData(null);
    abortRef.current = new AbortController();

    try {
      const res = await fetch("/api/automate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ domainName: name, tld }),
        signal: abortRef.current.signal,
      });

      await processStream(res);
    } catch (err: unknown) {
      if (err instanceof Error && err.name !== "AbortError") setErrorMsg(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    abortRef.current?.abort();
    setSteps([]);
    setResult(null);
    setErrorMsg("");
    setLoading(false);
  };

  const cleanName = domainName.replace(/[^a-z0-9-]/g, "");
  const isRunning = loading && !result && !errorMsg;

  return (
    <div className="flex flex-col gap-5">
      {/* ── Input Card ── */}
      <div className="rounded-2xl border border-zinc-700/60 bg-zinc-900 p-5">
        <p className="mb-4 text-[11px] font-semibold uppercase tracking-widest text-zinc-500">
          Nama Domain yang Diinginkan
        </p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* domain name + TLD row */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex flex-1 items-center rounded-xl border border-zinc-700 bg-zinc-800 px-3 transition-colors focus-within:border-green-500/60">
              <input
                type="text"
                value={domainName}
                onChange={(e) => setDomainName(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))}
                placeholder="namadomain"
                className="w-full bg-transparent py-3 font-mono text-sm text-zinc-100 placeholder:text-zinc-600 outline-none"
                disabled={loading}
                required
                maxLength={63}
                aria-label="Nama domain"
              />
            </div>

            <div className="flex gap-1.5">
              {TLDS.map((t) => (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => setTld(t.value)}
                  disabled={loading}
                  aria-pressed={tld === t.value}
                  className={`flex flex-1 flex-col items-center rounded-xl border px-3 py-2 transition-all sm:flex-none ${
                    tld === t.value
                      ? "border-green-500/60 bg-green-500/10 text-green-400"
                      : "border-zinc-700 bg-zinc-800 text-zinc-400 hover:border-zinc-600"
                  }`}
                >
                  <span className="font-mono text-sm font-bold">{t.label}</span>
                  <span className="text-[10px] opacity-60">{t.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* preview */}
          {cleanName && (
            <div className="flex items-center gap-2 rounded-lg bg-zinc-800/60 px-3 py-2">
              <span className="text-xs text-zinc-500">Domain:</span>
              <span className="font-mono text-sm font-bold text-green-400">{cleanName}{tld}</span>
            </div>
          )}

          {/* promo badge */}
          <div className="flex items-center gap-2 rounded-lg border border-green-500/20 bg-green-500/5 px-3 py-2">
            <svg className="size-3.5 shrink-0 text-green-400" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24" aria-hidden>
              <path strokeLinecap="round" strokeLinejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-5 5a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 10V5a2 2 0 012-2z" />
            </svg>
            <span className="font-mono text-xs font-bold text-green-400">DOMAINGRATIS</span>
            <span className="text-xs text-zinc-500">— diterapkan otomatis, harga Rp&nbsp;0</span>
          </div>

          {/* actions */}
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={isRunning || !cleanName}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-bold text-white transition-colors hover:bg-green-500 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isRunning ? (
                <>
                  <svg className="size-4 animate-spin" fill="none" viewBox="0 0 24 24" aria-hidden>
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Proses Otomatis Berjalan...
                </>
              ) : (
                <>
                  <svg className="size-4" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24" aria-hidden>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Daftarkan Domain Gratis
                </>
              )}
            </button>

            {(loading || steps.length > 0 || result || errorMsg) && (
              <button
                type="button"
                onClick={handleReset}
                className="rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-sm font-medium text-zinc-400 transition-colors hover:border-zinc-600 hover:text-zinc-300"
              >
                Reset
              </button>
            )}
          </div>
        </form>
      </div>

      {/* ── Live Log ── */}
      {steps.length > 0 && (
        <div className="rounded-2xl border border-zinc-700/60 bg-zinc-900 p-5">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-[11px] font-semibold uppercase tracking-widest text-zinc-500">
              Log Proses Otomatis
            </p>
            {isRunning && (
              <span className="flex items-center gap-1.5 rounded-full bg-yellow-500/10 px-2.5 py-1 text-[11px] font-semibold text-yellow-400">
                <span className="size-1.5 animate-pulse rounded-full bg-yellow-400" />
                Berjalan
              </span>
            )}
            {result && (
              <span className="flex items-center gap-1.5 rounded-full bg-green-500/10 px-2.5 py-1 text-[11px] font-semibold text-green-400">
                <span className="size-1.5 rounded-full bg-green-400" />
                Selesai
              </span>
            )}
          </div>
          <StepTracker steps={steps} />
        </div>
      )}

      {/* ── Error ── */}
      {errorMsg && (
        <div className="flex items-start gap-3 rounded-2xl border border-red-500/30 bg-red-500/5 p-4">
          <svg className="mt-0.5 size-4 shrink-0 text-red-400" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24" aria-hidden>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-red-400">Proses Gagal</p>
            <p className="mt-0.5 font-mono text-xs text-red-300/80 break-all">{errorMsg}</p>
            <button onClick={handleReset} className="mt-2 text-xs font-semibold text-red-400 underline hover:text-red-300">
              Coba lagi
            </button>
          </div>
        </div>
      )}

      {/* ── CAPTCHA Modal ── */}
      {captchaData && (
        <CaptchaModal
          captchaData={captchaData}
          onSubmit={(code) => handleCaptchaSubmit(code)}
        />
      )}

      {/* ── Result ── */}
      {result && <ResultCard result={result} />}
    </div>
  );
}
