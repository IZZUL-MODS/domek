/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Allow longer execution for WHMCS + AI Vision captcha solving
  experimental: {
    serverActions: {
      bodySizeLimit: "2mb",
    },
    turbopack: false,
  },
  serverExternalPackages: ["node-html-parser"],
  swcMinify: true,
}

export default nextConfig
