"use client";

import { useState } from "react";

interface CaptchaModalProps {
  captchaData: {
    image: string;
    message: string;
    sessionId?: string;
  };
  onSubmit: (code: string, sessionId?: string) => void;
}

export function CaptchaModal({ captchaData, onSubmit }: CaptchaModalProps) {
  const [input, setInput] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const code = input.trim();
    if (!code) {
      setError("Silakan masukkan kode CAPTCHA");
      return;
    }
    if (code.length > 20) {
      setError("Kode CAPTCHA terlalu panjang");
      return;
    }
    onSubmit(code, captchaData.sessionId);
    setInput("");
    setError("");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl border border-zinc-700/60 bg-zinc-900 p-6 shadow-2xl">
        {/* Header */}
        <div className="mb-6 text-center">
          <h2 className="text-lg font-bold text-zinc-100">Verifikasi CAPTCHA Manual</h2>
          <p className="mt-1 text-sm text-zinc-400">{captchaData.message}</p>
        </div>

        {/* CAPTCHA Image */}
        <div className="mb-6 flex justify-center">
          <div className="rounded-xl border border-zinc-700 bg-zinc-800 p-2">
            <img
              src={captchaData.image}
              alt="CAPTCHA"
              className="h-32 w-auto rounded-lg"
              crossOrigin="anonymous"
            />
          </div>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Input Field */}
          <div>
            <label htmlFor="captcha-input" className="mb-2 block text-xs font-semibold uppercase text-zinc-500">
              Masukkan Kode CAPTCHA
            </label>
            <input
              id="captcha-input"
              type="text"
              value={input}
              onChange={(e) => {
                setInput(e.target.value.toUpperCase());
                setError("");
              }}
              placeholder="Contoh: ABC123"
              maxLength={20}
              className="w-full rounded-lg border border-zinc-700 bg-zinc-800 px-3 py-2.5 font-mono text-sm text-zinc-100 placeholder:text-zinc-600 outline-none transition-colors focus:border-green-500/60"
              autoFocus
            />
            {error && <p className="mt-1.5 text-xs text-red-400">{error}</p>}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full rounded-lg bg-green-600 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-green-500"
          >
            Kirim CAPTCHA
          </button>
        </form>

        {/* Info */}
        <p className="mt-4 text-center text-[11px] text-zinc-600">
          Baca karakter yang terlihat di gambar dengan cermat, tanpa spasi atau simbol khusus.
        </p>
      </div>
    </div>
  );
}
