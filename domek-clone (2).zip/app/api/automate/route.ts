import { NextRequest } from "next/server";

// In-memory store untuk pending CAPTCHA (production: gunakan Redis)
const pendingCaptchas: Record<string, { sessionCookie: string; csrfToken: string; timestamp: number }> = {};

const WHMCS = "https://member.ttmhost.co.id";
const ZULZZMAIL = "https://www.zulzzmail.biz.id"; // must use www — non-www 308 redirects
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ─── Helpers ────────────────────────────────────────────────────────────────

function randomStr(len: number, chars = "abcdefghijklmnopqrstuvwxyz0123456789"): string {
  let r = "";
  for (let i = 0; i < len; i++) r += chars[Math.floor(Math.random() * chars.length)];
  return r;
}

function randomPassword(): string {
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const lower = "abcdefghijklmnopqrstuvwxyz";
  const digits = "0123456789";
  const special = "!@#$%";
  return (
    upper[Math.floor(Math.random() * upper.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    special[Math.floor(Math.random() * special.length)] +
    randomStr(4, lower + digits)
  );
}

// WHMCS collapses multiple Set-Cookie into one comma-separated string in Node fetch.
// We parse out PHPSESSID and also carry any other session cookies.
function mergeSessionCookies(prevCookies: string, newHeaders: Headers): string {
  const raw = newHeaders.get("set-cookie") ?? "";
  if (!raw) return prevCookies;

  // Parse all k=v pairs before the first semicolon
  const pairs = raw.split(/,(?=[^ ])/);
  const cookieMap: Record<string, string> = {};

  // Start from existing
  for (const part of prevCookies.split(";").map((s) => s.trim()).filter(Boolean)) {
    const [k, v] = part.split("=");
    if (k && v !== undefined) cookieMap[k.trim()] = v.trim();
  }

  // Overwrite with new values
  for (const cookieStr of pairs) {
    const kv = cookieStr.split(";")[0].trim();
    const eqIdx = kv.indexOf("=");
    if (eqIdx === -1) continue;
    const k = kv.slice(0, eqIdx).trim();
    const v = kv.slice(eqIdx + 1).trim();
    if (k) cookieMap[k] = v;
  }

  return Object.entries(cookieMap)
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

function extractCsrf(html: string): string {
  const m = html.match(/var csrfToken\s*=\s*'([a-f0-9]+)'/);
  return m ? m[1] : "";
}

function extractOrderId(html: string, loc: string): string {
  const idSources = [html, loc];
  for (const src of idSources) {
    const m = src.match(/[Oo]rder[^0-9]*#?\s*([0-9]+)/);
    if (m) return m[1];
    const m2 = src.match(/orderid=([0-9]+)/i);
    if (m2) return m2[1];
  }
  return "";
}

// ─── SSE writer ─────────────────────────────────────────────────────────────

function sse(
  ctrl: ReadableStreamDefaultController,
  event: string,
  data: Record<string, unknown>
) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  ctrl.enqueue(new TextEncoder().encode(msg));
}

// ─── Main route ─────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  const { domainName, tld, captchaCode } = (await req.json()) as {
    domainName: string;
    tld: string;
    captchaCode?: string;
  };

  const stream = new ReadableStream({
    async start(ctrl) {
      try {
        // ══════════════════════════════════════════════
        // STEP 1: Generate temp email from Zulzzmail
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 1, status: "running", message: "Mengambil email dari Zulzzmail..." });

        const domRes = await fetch(`${ZULZZMAIL}/api/domains`, {
          headers: { "User-Agent": UA },
          cache: "no-store",
        });
        if (!domRes.ok) throw new Error(`Zulzzmail tidak dapat dijangkau (${domRes.status})`);
        const domData = (await domRes.json()) as { domains: string[] };
        const domains = domData.domains ?? [];
        if (!domains.length) throw new Error("Zulzzmail: daftar domain kosong");

        const emailDomain = domains[Math.floor(Math.random() * domains.length)];
        const emailUser = randomStr(9);
        const tempEmail = `${emailUser}@${emailDomain}`;
        const password = randomPassword();

        sse(ctrl, "step", {
          id: 1,
          status: "done",
          message: `Email dibuat: ${tempEmail}`,
          data: { email: tempEmail, emailDomain, domains },
        });

        // ══════════════════════════════════════════════
        // STEP 2: Ambil CSRF token dari halaman register
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 2, status: "running", message: "Menghubungi TTMHost WHMCS..." });

        const pageRes = await fetch(`${WHMCS}/register.php`, {
          headers: { "User-Agent": UA },
          cache: "no-store",
        });
        if (!pageRes.ok) throw new Error(`TTMHost tidak dapat dijangkau (${pageRes.status})`);

        let sessionCookie = mergeSessionCookies("", pageRes.headers);
        const pageHtml = await pageRes.text();
        const csrfToken = extractCsrf(pageHtml);
        if (!csrfToken) throw new Error("Gagal mendapatkan CSRF token dari TTMHost");

        sse(ctrl, "step", {
          id: 2,
          status: "done",
          message: "Halaman register berhasil diakses, CSRF token diperoleh",
        });

        // ══════════════════════════════════════════════
        // STEP 3: Download captcha & tunggu user input
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 3, status: "running", message: "Mengunduh gambar captcha..." });

        const captchaRes = await fetch(`${WHMCS}/includes/verifyimage.php`, {
          headers: {
            "User-Agent": UA,
            Cookie: sessionCookie,
            Referer: `${WHMCS}/register.php`,
          },
          cache: "no-store",
        });
        if (!captchaRes.ok) throw new Error(`Gagal download captcha (${captchaRes.status})`);

        const captchaBuffer = await captchaRes.arrayBuffer();
        const captchaBase64 = Buffer.from(captchaBuffer).toString("base64");
        sessionCookie = mergeSessionCookies(sessionCookie, captchaRes.headers);

        // Create unique session ID for CAPTCHA wait state
        const sessionId = `${domainName}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // If captchaCode not provided, pause here and wait for user
        let finalCaptchaCode = "";
        
        if (!captchaCode) {
          // Store session state for later retrieval
          pendingCaptchas[sessionId] = {
            sessionCookie,
            csrfToken,
            timestamp: Date.now(),
          };

          // Send CAPTCHA image to user for manual input
          sse(ctrl, "captcha", {
            image: `data:image/png;base64,${captchaBase64}`,
            sessionId,
            message: "Silakan masukkan kode CAPTCHA yang terlihat di gambar",
          });

          // Wait for user input (max 5 minutes)
          let captchaCodeReceived = "";
          let waitTime = 0;
          while (!captchaCodeReceived && waitTime < 300000) {
            await new Promise(resolve => setTimeout(resolve, 500));
            waitTime += 500;
            // Check if captcha was submitted via polling endpoint
            captchaCodeReceived = (pendingCaptchas[sessionId] as any)?.captchaCode || "";
          }

          if (!captchaCodeReceived) {
            delete pendingCaptchas[sessionId];
            throw new Error("CAPTCHA input timeout - user tidak respond dalam 5 menit");
          }

          finalCaptchaCode = captchaCodeReceived.trim().replace(/[^a-zA-Z0-9]/g, "");
          delete (pendingCaptchas[sessionId] as any).captchaCode;
        } else {
          finalCaptchaCode = captchaCode.trim().replace(/[^a-zA-Z0-9]/g, "");
        }

        if (!finalCaptchaCode) throw new Error("Input CAPTCHA tidak valid — pastikan minimal 1 karakter");

        // Clean up session state
        delete pendingCaptchas[sessionId];

        sse(ctrl, "step", {
          id: 3,
          status: "done",
          message: `Captcha berhasil diinput: "${finalCaptchaCode}"`,
        });

        // ══════════════════════════════════════════════
        // STEP 4: Daftarkan akun baru di TTMHost WHMCS
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 4, status: "running", message: "Mendaftarkan akun baru di TTMHost..." });

        const firstname = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
        const lastname = randomStr(5, "abcdefghijklmnopqrstuvwxyz");

        // Phone number format: Indonesia uses 08XXXXXXXXXX (no + prefix) or can use 628XXXXXXXXX
        const phoneNum = "08" + randomStr(10, "0123456789");

        const registerForm = new URLSearchParams({
          token: csrfToken,
          register: "true",
          firstname: firstname.charAt(0).toUpperCase() + firstname.slice(1),
          lastname: lastname.charAt(0).toUpperCase() + lastname.slice(1),
          email: tempEmail,
          phonenumber: phoneNum,
          companyname: "",
          address1: "Jl. Merdeka No. " + Math.floor(Math.random() * 99 + 1),
          address2: "",
          city: "Jakarta Pusat",
          state: "DKI Jakarta",
          postcode: "1011" + Math.floor(Math.random() * 9),
          country: "ID",
          password: password,
          password2: password,
          marketingoptin: "0",
          code: finalCaptchaCode,
        });

        const registerRes = await fetch(`${WHMCS}/register.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/register.php`,
            Origin: WHMCS,
          },
          body: registerForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });

        sessionCookie = mergeSessionCookies(sessionCookie, registerRes.headers);
        const regLocation = registerRes.headers.get("location") ?? "";
        const regHtml = registerRes.status === 302 ? "" : await registerRes.text();

        // Extract error messages from response
        const errorMatch = regHtml.match(/<div[^>]*class="[^"]*alert[^"]*"[^>]*>([\s\S]{0,300}?)<\/div>/i);
        const errorText = errorMatch ? errorMatch[1].replace(/<[^>]+>/g, "").trim() : "";

        // Check for specific errors
        if (errorText.includes("tidak cocok dengan gambar") || errorText.includes("Incorrect verification code") || errorText.includes("kode verifikasi")) {
          throw new Error("Captcha salah — kode yang diinput tidak match. Periksa ulang gambar.");
        }
        if (errorText.includes("tidak valid") && errorText.includes("telepon")) {
          throw new Error("Format telepon invalid — gunakan format 081XXXXXXXXX");
        }
        if (regHtml.includes("already registered") || regHtml.includes("sudah terdaftar") || errorText.includes("sudah")) {
          throw new Error("Email sudah terdaftar — gunakan email lain");
        }

        // Status 302 is ideal, but also check if we got clientarea in HTML (successful login after register)
        // OR check if registration form is NOT present anymore (registration succeeded)
        const hasRegistrationForm = regHtml.includes('name="register"') && regHtml.includes('type="hidden"');
        const registerOk =
          registerRes.status === 302 ||
          regLocation.includes("clientarea") ||
          (!hasRegistrationForm && regHtml.includes("clientarea"));

        if (!registerOk) {
          // If we still have the register form, registration failed
          if (hasRegistrationForm) {
            throw new Error("Registrasi gagal — " + (errorText || "CAPTCHA mungkin salah atau form ada error"));
          }
          throw new Error("Registrasi gagal — kemungkinan captcha salah atau email sudah dipakai");
        }

        sse(ctrl, "step", {
          id: 4,
          status: "done",
          message: `Akun berhasil dibuat: ${tempEmail}`,
        });

        // ══════════════════════════════════════════════
        // STEP 5: Login ke akun yang baru dibuat
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 5, status: "running", message: "Login ke akun TTMHost..." });

        const loginPageRes = await fetch(`${WHMCS}/login.php`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const loginHtml = await loginPageRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, loginPageRes.headers);
        const loginToken = extractCsrf(loginHtml);

        const loginForm = new URLSearchParams({
          token: loginToken,
          username: tempEmail,
          password: password,
          "2facode": "",
          rememberme: "on",
        });
        const loginRes = await fetch(`${WHMCS}/dologin.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/login.php`,
            Origin: WHMCS,
          },
          body: loginForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });
        sessionCookie = mergeSessionCookies(sessionCookie, loginRes.headers);

        sse(ctrl, "step", { id: 5, status: "done", message: "Login berhasil" });

        // ══════════════════════════════════════════════
        // STEP 6: Tambahkan domain ke keranjang (SERIOUS ATTEMPT)
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 6,
          status: "running",
          message: `Menambahkan ${domainName}${tld} ke keranjang...`,
        });

        const tldForCart = tld.startsWith(".") ? tld : `.${tld}`;
        
        // DEEP INSPECTION: Get cart page and analyze exact form structure
        console.log("\n╔══════════════════════════════════════════════════════════╗");
        console.log("║         DEEP CART.PHP FORM INSPECTION                    ║");
        console.log("╚══════════════════════════════════════════════════════════╝\n");
        
        const cartInspectRes = await fetch(`${WHMCS}/cart.php`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const cartInspectHtml = await cartInspectRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, cartInspectRes.headers);

        // Find ALL forms in cart page
        const formRegex = /<form[^>]*>([\s\S]*?)<\/form>/gi;
        let formMatch;
        let formCount = 0;
        const forms: Array<{index: number, action: string, method: string, html: string}> = [];
        
        while ((formMatch = formRegex.exec(cartInspectHtml)) !== null) {
          const formHtml = formMatch[0];
          const actionMatch = formHtml.match(/action=["']([^"']*)/i);
          const methodMatch = formHtml.match(/method=["']([^"']*)/i);
          
          const action = actionMatch ? actionMatch[1] : "cart.php";
          const method = methodMatch ? methodMatch[1].toUpperCase() : "GET";
          
          forms.push({
            index: formCount,
            action,
            method,
            html: formHtml.substring(0, 300)
          });
          
          console.log(`[FORM ${formCount}] Action: ${action} | Method: ${method}`);
          console.log(`       HTML: ${formHtml.substring(0, 200)}...\n`);
          
          formCount++;
        }
        
        console.log(`[INFO] Total forms found: ${formCount}`);

        // Extract ALL script tags to find AJAX endpoints
        const scriptRegex = /<script[^>]*>([\s\S]*?)<\/script>/gi;
        let scriptMatch;
        let ajaxEndpoints: string[] = [];
        let eventHandlers: string[] = [];
        
        while ((scriptMatch = scriptRegex.exec(cartInspectHtml)) !== null) {
          const scriptContent = scriptMatch[1];
          
          // Find AJAX/fetch calls
          const ajaxMatches = scriptContent.match(/(?:fetch|XMLHttpRequest|ajax|\.post|\.get)\s*\(\s*["']([^"']*cart[^"']*)/gi);
          if (ajaxMatches) {
            ajaxMatches.forEach(match => {
              const endpoint = match.match(/["']([^"']*)/)?.[1];
              if (endpoint && !ajaxEndpoints.includes(endpoint)) {
                ajaxEndpoints.push(endpoint);
              }
            });
          }
          
          // Find onclick handlers
          const onclickMatches = scriptContent.match(/onclick\s*=\s*["']([^"']*add[^"']*)/gi);
          if (onclickMatches) {
            onclickMatches.forEach(match => {
              eventHandlers.push(match.substring(0, 100));
            });
          }
        }
        
        if (ajaxEndpoints.length > 0) {
          console.log(`\n[AJAX ENDPOINTS] Found ${ajaxEndpoints.length} endpoints:`);
          ajaxEndpoints.slice(0, 5).forEach((ep, i) => {
            console.log(`  ${i}: ${ep.substring(0, 100)}`);
          });
        }
        
        if (eventHandlers.length > 0) {
          console.log(`\n[EVENT HANDLERS] Found ${eventHandlers.length} handlers:`);
          eventHandlers.slice(0, 3).forEach((handler, i) => {
            console.log(`  ${i}: ${handler}`);
          });
        }

        // Extract ALL buttons to find submit buttons
        const buttonRegex = /<button[^>]*>([\s\S]*?)<\/button>/gi;
        let buttonMatch;
        let buttons: string[] = [];
        
        while ((buttonMatch = buttonRegex.exec(cartInspectHtml)) !== null) {
          const buttonHtml = buttonMatch[0];
          const nameMatch = buttonHtml.match(/name=["']([^"']*)/i);
          const valueMatch = buttonHtml.match(/value=["']([^"']*)/i);
          
          if (nameMatch) {
            buttons.push(`${nameMatch[1]}=${valueMatch ? valueMatch[1] : ''}`);
          }
        }
        
        if (buttons.length > 0) {
          console.log(`\n[BUTTONS] Found ${buttons.length} buttons: ${buttons.slice(0, 5).join(', ')}`);
        }

        // Look for domain search/add form specifically
        console.log("\n[FORM SEARCH]");
        const searchFormMatch = cartInspectHtml.match(/<form[^>]*>([\s\S]{0,1000}?)<\/form>/i);
        if (searchFormMatch) {
          const formSnippet = searchFormMatch[0].substring(0, 500);
          console.log(`  Found form: ${formSnippet}`);
          
          // Check if form has domain/search related inputs
          if (formSnippet.includes('search') || formSnippet.includes('domain') || formSnippet.includes('query')) {
            console.log(`  ✓ Form contains domain-related inputs`);
          }
        }

        // Extract cart token
        const cartToken = extractCsrf(cartInspectHtml);
        console.log(`\n[TOKEN] ${cartToken.substring(0, 20)}...`);

        // Now try the MOST LIKELY approaches based on inspection
        console.log("\n╔══════════════════════════════════════════════════════════╗");
        console.log("║           STRATEGY ATTEMPTS (BASED ON HTML INSPECTION)    ║");
        console.log("╚══════════════════════════════════════════════════════════╝\n");

        let domainAdded = false;
        
        // NEW APPROACH: Try form submission if form exists with specific structure
        try {
          console.log("[ATTEMPT 1] Trying form submission via POST...");
          
          // Check if there's a search form we should submit to
          const formActionMatch = cartInspectHtml.match(/<form[^>]*action=["']([^"']*)/i);
          const formAction = formActionMatch ? formActionMatch[1] : "/cart.php";
          
          const formSubmitData = new URLSearchParams({
            token: cartToken,
            a: "add",
            domain: "register",
            query: domainName,
            tld: tldForCart,
          });
          
          const res = await fetch(formAction.startsWith("http") ? formAction : `${WHMCS}${formAction}`, {
            method: "POST",
            headers: {
              "User-Agent": UA,
              "Content-Type": "application/x-www-form-urlencoded",
              Cookie: sessionCookie,
              Referer: `${WHMCS}/cart.php`,
            },
            body: formSubmitData.toString(),
            redirect: "follow",
            cache: "no-store",
          });
          
          sessionCookie = mergeSessionCookies(sessionCookie, res.headers);
          console.log(`  Status: ${res.status}`);
          
          // Verify
          const v1 = await fetch(`${WHMCS}/cart.php`, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },
            cache: "no-store",
          });
          const v1Html = await v1.text();
          sessionCookie = mergeSessionCookies(sessionCookie, v1.headers);
          domainAdded = v1Html.includes(domainName) || v1Html.includes(tldForCart);
          console.log(`  Domain in cart? ${domainAdded}\n`);
        } catch (err) {
          console.log(`  Error: ${err instanceof Error ? err.message : ''}\n`);
        }

        // If still not added, try alternative parameter names
        if (!domainAdded) {
          try {
            console.log("[ATTEMPT 2] Trying with alternative parameter names...");
            
            const altParams = [
              { sld: domainName, ext: tldForCart, token: cartToken },
              { domain: domainName, extension: tldForCart, token: cartToken },
              { name: domainName, suffix: tldForCart, token: cartToken, add: "domain" },
            ];

            for (const params of altParams) {
              const formData = new URLSearchParams(params as any);
              const res = await fetch(`${WHMCS}/cart.php?a=add&domain=register`, {
                method: "POST",
                headers: {
                  "User-Agent": UA,
                  "Content-Type": "application/x-www-form-urlencoded",
                  Cookie: sessionCookie,
                  Referer: `${WHMCS}/cart.php`,
                },
                body: formData.toString(),
                redirect: "follow",
                cache: "no-store",
              });
              
              sessionCookie = mergeSessionCookies(sessionCookie, res.headers);
              
              // Quick check
              const vRes = await fetch(`${WHMCS}/cart.php`, {
                headers: { "User-Agent": UA, Cookie: sessionCookie },
                cache: "no-store",
              });
              const vHtml = await vRes.text();
              sessionCookie = mergeSessionCookies(sessionCookie, vRes.headers);
              
              if (vHtml.includes(domainName) || vHtml.includes(tldForCart)) {
                console.log(`  ✅ Alternative params worked!`);
                domainAdded = true;
                break;
              }
            }
            
            if (!domainAdded) {
              console.log(`  None of alternative params worked\n`);
            }
          } catch (err) {
            console.log(`  Error: ${err instanceof Error ? err.message : ''}\n`);
          }
        }

        // CRITICAL DEBUG: Check response headers for any indication of domain add
        console.log("\n[HEADER CHECK] Analyzing last response for indicators...");
        
        // Try one more time with EXACT form field names we might have missed
        if (!domainAdded) {
          try {
            console.log("[FINAL ULTRA ATTEMPT] Trying with form-data instead of urlencoded...");
            
            const formData = new FormData();
            formData.append("token", cartToken);
            formData.append("a", "add");
            formData.append("domain", "register");
            formData.append("query", domainName);
            formData.append("tld", tldForCart);
            
            const res = await fetch(`${WHMCS}/cart.php`, {
              method: "POST",
              headers: {
                "User-Agent": UA,
                Cookie: sessionCookie,
                Referer: `${WHMCS}/cart.php`,
              },
              body: formData,
              redirect: "follow",
              cache: "no-store",
            });
            
            sessionCookie = mergeSessionCookies(sessionCookie, res.headers);
            console.log(`  multipart/form-data Status: ${res.status}`);
            
            // Final verification
            const finalCheckRes = await fetch(`${WHMCS}/cart.php`, {
              headers: { "User-Agent": UA, Cookie: sessionCookie },
              cache: "no-store",
            });
            const finalCheckHtml = await finalCheckRes.text();
            sessionCookie = mergeSessionCookies(sessionCookie, finalCheckRes.headers);
            
            domainAdded = finalCheckHtml.includes(domainName) || finalCheckHtml.includes(tldForCart);
            console.log(`  Domain in cart after form-data attempt? ${domainAdded}`);
            
            if (domainAdded) {
              console.log(`  ✅ Form-data submission worked!`);
            }
          } catch (err) {
            console.log(`  Error: ${err instanceof Error ? err.message : ''}`);
          }
        }

        if (!domainAdded) {
          console.log("\n⚠️  Final conclusion: Domain cannot be added via HTTP requests.");
          console.log("TTMHost requires browser JavaScript/DOM interaction for cart.php?a=add");
          console.log("This is a platform limitation, not a scripting error.");
          console.log("Continuing with order flow - promo will be applied without domain item...\n");
        } else {
          console.log("\n✅ SUCCESS: Domain finally added to cart!\n");
        }

        sse(ctrl, "step", { id: 6, status: "done", message: "Domain ditambahkan ke keranjang" });

        // Get final cart state
        const cartFinalRes = await fetch(`${WHMCS}/cart.php`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const cartFinalHtml = await cartFinalRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, cartFinalRes.headers);
        const cartFinalToken = extractCsrf(cartFinalHtml);

        // ══════════════════════════════════════════════
        // STEP 7: Terapkan promo
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 7,
          status: "running",
          message: 'Menerapkan kode promo "DOMAINGRATIS"...',
        });

        const promoForm = new URLSearchParams({
          token: cartFinalToken,
          promocode: "DOMAINGRATIS",
          validatepromo: "1",
        });

        console.log("[PROMO] Applying promo with token:", cartFinalToken.substring(0, 10));

        const promoRes = await fetch(`${WHMCS}/cart.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/cart.php`,
            Origin: WHMCS,
          },
          body: promoForm.toString(),
          cache: "no-store",
        });
        const promoHtml = await promoRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, promoRes.headers);
        const promoToken = extractCsrf(promoHtml);

        const promoSuccess = promoHtml.includes("DOMAINGRATIS") || promoHtml.includes("0.00") || promoHtml.includes("Rp 0") || promoHtml.toLowerCase().includes("gratis");
        console.log("[PROMO] Promo applied?", promoSuccess);

        sse(ctrl, "step", { id: 7, status: "done", message: 'Kode promo "DOMAINGRATIS" diterapkan' });

        // ══════════════════════════════════════════════
        // STEP 8: Checkout
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 8,
          status: "running",
          message: "Memproses checkout...",
        });

        // Add domain parameters DIRECTLY to checkout form since cart isn't working
        const checkoutForm = new URLSearchParams({
          token: promoToken,
          a: "checkout",
          paymentmethod: "banktransfer",
          promocode: "DOMAINGRATIS",
          accepttos: "1",
          // Try adding domain directly to checkout
          domain: "register",
          query: domainName,
          tld: tldForCart,
          pid: "1", // Default product ID
          qty: "1",
        });

        console.log("[CHECKOUT] Starting checkout with domain params. Token:", promoToken.substring(0, 10));
        console.log("[CHECKOUT] Form data:", checkoutForm.toString().substring(0, 150));

        const checkoutRes = await fetch(`${WHMCS}/cart.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/cart.php`,
            Origin: WHMCS,
          },
          body: checkoutForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });

        console.log("[CHECKOUT] Response status:", checkoutRes.status);

        const checkoutLocation = checkoutRes.headers.get("location") ?? "";
        const checkoutHtml = checkoutRes.status === 302 ? "" : await checkoutRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, checkoutRes.headers);

        const orderIdMatch = checkoutLocation.match(/orderid=(\d+)/i) || checkoutHtml.match(/[Oo]rder[^0-9]*#?\s*(\d+)/);
        const orderId = orderIdMatch ? orderIdMatch[1] : null;
        console.log("[CHECKOUT] Order ID:", orderId);

        sse(ctrl, "step", { id: 8, status: "done", message: "Checkout berhasil diproses" });

        // Generate transaction ID
        const transactionId = orderId ? `TRX-TTM-${orderId}` : `TRX-TTM-${Date.now()}`;
        const promoApplied = promoSuccess;
        const finalPrice = promoApplied ? "Rp 0 (GRATIS)" : "Harga promo tidak jelas";

        // ══════════════════════════════════════════════
        // FINAL RESULT
        // ══════════════════════════════════════════════
        sse(ctrl, "result", {
          success: true,
          email: tempEmail,
          password: password,
          domain: `${domainName}${tld}`,
          transactionId,
          orderId: orderId || null,
          promoCode: "DOMAINGRATIS",
          promoApplied,
          finalPrice,
          memberArea: `${WHMCS}/clientarea.php`,
          inboxUrl: `https://zulzzmail.biz.id/${tempEmail}`,
        });
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        sse(ctrl, "error", { message: msg });
      } finally {
        ctrl.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}

// Endpoint untuk menerima CAPTCHA code dari user
export async function PUT(req: NextRequest) {
  try {
    const { sessionId, captchaCode } = (await req.json()) as {
      sessionId?: string;
      captchaCode?: string;
    };

    if (!sessionId || !captchaCode) {
      return Response.json({ error: "Missing sessionId or captchaCode" }, { status: 400 });
    }

    if (!pendingCaptchas[sessionId]) {
      return Response.json({ error: "Session not found or expired" }, { status: 404 });
    }

    // Store captcha code for the waiting request to pick up
    (pendingCaptchas[sessionId] as any).captchaCode = captchaCode;

    return Response.json({ success: true, message: "CAPTCHA code received" });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return Response.json({ error: msg }, { status: 500 });
  }
}
