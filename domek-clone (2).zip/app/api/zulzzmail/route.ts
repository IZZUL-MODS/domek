import { NextResponse } from "next/server";

const ZULZZMAIL_BASE = "https://www.zulzzmail.biz.id";

function randomUsername(length = 9): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// GET: generate a fresh temp email from live zulzzmail domain list
export async function GET() {
  try {
    const res = await fetch(`${ZULZZMAIL_BASE}/api/domains`, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      },
      cache: "no-store",
    });

    if (!res.ok) throw new Error(`zulzzmail domains error: ${res.status}`);

    const data = (await res.json()) as { domains: string[] };
    const domains: string[] = data.domains ?? [];
    if (domains.length === 0) throw new Error("Empty domain list from zulzzmail");

    const domain = domains[Math.floor(Math.random() * domains.length)];
    const username = randomUsername(9);
    const email = `${username}@${domain}`;

    return NextResponse.json({ email, username, domain, inboxUrl: `${ZULZZMAIL_BASE}/${email}` });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// POST: check inbox for a given email
export async function POST(req: Request) {
  try {
    const { email } = (await req.json()) as { email: string };
    if (!email?.includes("@")) return NextResponse.json({ error: "Invalid email" }, { status: 400 });
    const [username, domain] = email.split("@");

    const res = await fetch(
      `${ZULZZMAIL_BASE}/api/inbox?user=${encodeURIComponent(username)}&domain=${encodeURIComponent(domain)}`,
      {
        headers: { "User-Agent": "Mozilla/5.0" },
        cache: "no-store",
      }
    );

    if (!res.ok) throw new Error(`Inbox check failed: ${res.status}`);
    const data = await res.json();
    return NextResponse.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
