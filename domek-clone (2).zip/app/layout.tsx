import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Beli Domain Gratis - .my.id | .biz.id | .web.id',
  description: 'Registrasi domain Indonesia gratis dengan sistem otomatis. Beli domain .my.id, .biz.id, atau .web.id dengan kode promo DOMAINGRATIS. Email ter-register dari Zulzzmail.',
  keywords: ['domain', 'domain gratis', 'my.id', 'biz.id', 'web.id', 'TTM Host', 'Zulzzmail'],
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'Domain Gratis Indonesia',
    description: 'Registrasi domain .my.id, .biz.id, web.id GRATIS dengan sistem otomatis',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#000000' },
  ],
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="id">
      <body className="antialiased bg-zinc-950">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
