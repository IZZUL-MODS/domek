# 🧪 Test Cases - Domain Gratis Indonesia

Dokumentasi lengkap test cases untuk testing fitur aplikasi.

## 1. Form Input & Validation

### Test Case 1.1: Valid Domain Registration
**Steps:**
1. Masukkan "mybusiness" di field Nama Domain
2. Pilih ekstensi ".my.id"
3. Klik "🚀 Daftar Domain Gratis"

**Expected Result:**
- Form submit berhasil
- Loading indicator muncul
- Success card tampil dengan:
  - Transaction ID
  - Domain: mybusiness.my.id
  - Email ter-register
  - Harga: 0 (gratis)

### Test Case 1.2: Empty Domain Name
**Steps:**
1. Biarkan field Nama Domain kosong
2. Klik "🚀 Daftar Domain Gratis"

**Expected Result:**
- Button tetap disabled
- Error message: "Nama domain tidak boleh kosong"

### Test Case 1.3: Invalid Domain Characters
**Steps:**
1. Masukkan "my@business#123" di field Nama Domain
2. Klik submit

**Expected Result:**
- Submit berhasil (sistem lowercase & trim)
- Domain di-register: my@business#123.my.id

### Test Case 1.4: Very Long Domain Name
**Steps:**
1. Masukkan nama domain > 50 karakter
2. Submit

**Expected Result:**
- Submit berhasil
- Domain ter-register dengan full nama

### Test Case 1.5: Domain Name dengan Spasi
**Steps:**
1. Masukkan "my business" (dengan spasi)
2. Submit

**Expected Result:**
- Sistem auto-remove spasi
- Domain: mybusiness.my.id

## 2. Extension Selection

### Test Case 2.1: Select .my.id
**Steps:**
1. Masukkan "test"
2. Klik button ".my.id"
3. Preview muncul

**Expected Result:**
- Button ".my.id" highlighted dengan border
- Preview: [nama-domain].my.id
- Button submit enabled

### Test Case 2.2: Switch Extension
**Steps:**
1. Pilih ".my.id"
2. Ubah ke ".biz.id"
3. Submit

**Expected Result:**
- Extension berubah ke .biz.id
- Domain registered: test.biz.id

### Test Case 2.3: All Extensions Work
**Steps:**
1. Test registrasi dengan ketiga extension:
   - test1.my.id
   - test2.biz.id
   - test3.web.id

**Expected Result:**
- Semua registrasi berhasil
- Masing-masing dapat email unik
- Transaction ID berbeda untuk setiap registrasi

## 3. Promo Code Testing

### Test Case 3.1: DOMAINGRATIS Applied
**Steps:**
1. Register domain dengan promo DOMAINGRATIS
2. Check hasil

**Expected Result:**
- Harga Asli: Rp 189,000
- Harga Bayar: Rp 0
- promoApplied: true
- Green success message: "✓ Promo DOMAINGRATIS berhasil diterapkan!"

### Test Case 3.2: Promo Discount 100%
**Steps:**
1. Check harga sebelum & sesudah promo
2. Verify discount

**Expected Result:**
- Discount: Rp 189,000 (100%)
- Final price: Rp 0

## 4. Email Generation

### Test Case 4.1: Email Generated
**Steps:**
1. Register domain
2. Check email di hasil

**Expected Result:**
- Email ter-generate dari pool
- Format: [username]@[domain]
- Email valid dan ter-claim

### Test Case 4.2: Multiple Registration - Different Emails
**Steps:**
1. Register domain 1 → dapatkan email1
2. Register domain 2 → dapatkan email2
3. Register domain 3 → dapatkan email3

**Expected Result:**
- Setiap registrasi dapat email berbeda
- Emails dari pool yang tersedia di Zulzzmail

### Test Case 4.3: Email Domains
**Steps:**
1. Register multiple domains
2. Collect semua email domains

**Expected Result:**
- Email domains berasal dari:
  - thueotp.net
  - tempmail.org
  - maildrop.cc
  - Dan domains lainnya di list

## 5. Transaction ID & Tracking

### Test Case 5.1: Transaction ID Generated
**Steps:**
1. Register domain
2. Check Transaction ID

**Expected Result:**
- Format: TRX-[timestamp]
- Unique untuk setiap transaksi
- Dapat di-copy

### Test Case 5.2: Copy Transaction ID
**Steps:**
1. Register domain
2. Klik button "Salin Domain" atau "Salin Email"
3. Paste ke notepad

**Expected Result:**
- Text ter-copy ke clipboard
- Dapat di-paste dengan benar

## 6. UI/UX Testing

### Test Case 6.1: Responsive Mobile
**Steps:**
1. Open di mobile (375px)
2. Test semua fitur

**Expected Result:**
- Layout responsive
- Button tidak overlap
- Form inputs readable
- Success card tampil sempurna

### Test Case 6.2: Responsive Tablet
**Steps:**
1. Open di tablet (768px)
2. Test layout

**Expected Result:**
- Grid layout adjust
- Components centered properly
- All clickable elements accessible

### Test Case 6.3: Responsive Desktop
**Steps:**
1. Open di desktop (1920px)
2. Test layout

**Expected Result:**
- Full width optimal
- Maximum width constraint applied
- White space balanced

### Test Case 6.4: Dark Mode
**Steps:**
1. Enable dark mode di browser/OS
2. Test visibility

**Expected Result:**
- Colors contrast properly
- Text readable
- No white text on white background

### Test Case 6.5: Light Mode
**Steps:**
1. Disable dark mode
2. Test visibility

**Expected Result:**
- Colors contrast properly
- Shadows visible
- Green success box visible

## 7. Loading & Performance

### Test Case 7.1: Loading Indicator
**Steps:**
1. Register domain
2. Observe loading state

**Expected Result:**
- Loading spinner muncul
- Button text berubah: "Memproses..."
- Button disabled selama loading

### Test Case 7.2: Quick Response
**Steps:**
1. Register domain
2. Measure response time

**Expected Result:**
- Response < 5 detik (sesuai deskripsi)
- Tidak ada timeout
- Success tampil dengan cepat

### Test Case 7.3: Multiple Registrations
**Steps:**
1. Register 5+ domains quickly
2. Monitor performance

**Expected Result:**
- Semua registrasi berhasil
- No slowdown
- No memory leaks
- Each has unique email

## 8. Error Handling

### Test Case 8.1: Network Error
**Steps:**
1. Disable internet
2. Try submit domain
3. Re-enable internet

**Expected Result:**
- Error message tampil
- Tidak ada hanging/frozen state
- Can retry setelah internet kembali

### Test Case 8.2: Invalid Promo
**Steps:**
1. Use different promo code
2. Check result

**Expected Result:**
- Promo tidak applied
- Harga normal tetap
- finalPrice = 189000

## 9. Copy Button Testing

### Test Case 9.1: Copy Domain
**Steps:**
1. Register domain
2. Klik "Salin Domain"
3. Paste di text editor

**Expected Result:**
- Domain ter-copy
- Format: [name].[extension]
- Paste successful

### Test Case 9.2: Copy Email
**Steps:**
1. Register domain
2. Klik "Salin Email"
3. Paste di email field

**Expected Result:**
- Email ter-copy
- Format: [username]@[domain]
- Paste successful

## 10. API Testing

### Test Case 10.1: Register Domain Endpoint
```bash
curl -X POST http://localhost:3000/api/register-domain \
  -H "Content-Type: application/json" \
  -d '{
    "domainName": "testdomain",
    "extension": "my.id",
    "promoCode": "DOMAINGRATIS"
  }'
```

**Expected Response:**
- Status: 200
- success: true
- transactionId: present
- domain: testdomain.my.id
- finalPrice: 0

### Test Case 10.2: Get Available Emails
```bash
curl http://localhost:3000/api/available-emails
```

**Expected Response:**
- Status: 200
- success: true
- data: array of emails
- total: 15

### Test Case 10.3: Get Zulzzmail Email
```bash
curl http://localhost:3000/api/zulzzmail
```

**Expected Response:**
- Status: 200
- email: valid email
- domain: email domain
- availableEmails: array

## 11. Browser Compatibility

### Supported Browsers:
- ✅ Chrome/Chromium 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile Safari (iOS 14+)
- ✅ Chrome Mobile

### Test Case 11.1: Chrome
- Test form submission
- Test loading state
- Test copy buttons

### Test Case 11.2: Firefox
- Test responsive layout
- Test form inputs
- Test dark mode

### Test Case 11.3: Safari
- Test iOS compatibility
- Test form submission
- Test touch interactions

## Test Data

### Valid Domain Names to Test:
```
mybusiness
mystore
webdesign
ecommerce
portfolio
blog
news
shop
platform
services
```

### Valid Extensions:
```
my.id    (Domain Personal)
biz.id   (Domain Bisnis)
web.id   (Domain Web)
```

### Expected Email Domains:
```
thueotp.net
tempmail.org
maildrop.cc
tempmail.dev
fakeinbox.net
guerrillamail.info
mailinator.com
10minutemail.com
trashmail.com
throwaway.email
mailnesia.com
tempmail.pro
yopmail.com
dispostable.com
sharklasers.com
```

## Automated Testing (Jest)

```bash
# Run tests
pnpm test

# Run with coverage
pnpm test --coverage

# Watch mode
pnpm test --watch
```

## Performance Benchmarks

Target metrics:
- LCP: < 2.5s
- FID: < 100ms
- CLS: < 0.1
- First Paint: < 1s
- Time to Interactive: < 3s

Test dengan: `lighthouse` atau `web-vitals`

---

**Last Updated:** July 2026
**Version:** 1.0
