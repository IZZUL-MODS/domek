# 🏗️ Architecture - Domain Gratis Indonesia

Dokumentasi teknis arsitektur sistem Domain Gratis Indonesia.

## System Overview

```
┌─────────────────┐
│   Client (UI)   │
│ React + Tailwind│
└────────┬────────┘
         │
    HTTP │ REST API
         │
┌────────▼────────┐
│ Next.js Server  │
│  (App Router)   │
└─┬───────────┬───┘
  │           │
  │           └─────────────────┐
  │                             │
  │ Simulasi (Real: API Call)   │
  │                             │
┌─▼──────────────┐    ┌────────▼──────┐
│  TTM Host API  │    │ Zulzzmail API │
│  (Domain Reg)  │    │ (Email Gen)   │
└────────────────┘    └────────────────┘

┌──────────────────────────┐
│    Database/Storage      │
│  (Optional: Neon/Supa)   │
└──────────────────────────┘
```

## Layered Architecture

### 1. Presentation Layer (Frontend)

**Components:**
- `DomainForm.tsx` - Input form dengan validation
- `InfoSection.tsx` - Display info cards
- `page.tsx` - Main landing page

**Features:**
- Client-side form validation
- Real-time preview
- Loading states
- Success/Error handling
- Copy to clipboard

**Tech Stack:**
- React 19.2
- Tailwind CSS v4
- shadcn/ui Components
- Lucide React Icons

### 2. API Layer (Backend)

**Endpoints:**

#### POST /api/register-domain
```typescript
Input: {
  domainName: string
  extension: "my.id" | "biz.id" | "web.id"
  promoCode?: string
}

Output: {
  success: boolean
  data: {
    transactionId: string
    domain: string
    registeredEmail: string
    price: number
    finalPrice: number
    promoApplied: boolean
  }
}
```

**Flow:**
1. Validate input with Zod
2. Check promo code validity
3. Fetch email dari `/api/zulzzmail`
4. Simulasi registrasi ke TTM Host
5. Return transaction details

#### GET /api/zulzzmail
```typescript
Output: {
  success: boolean
  email: string
  domain: string
  availableEmails: string[]
}
```

**Flow:**
1. Select random email from pool
2. Return email + available list

#### GET /api/available-emails
```typescript
Output: {
  success: boolean
  data: Array<{
    email: string
    domain: string
  }>
  total: number
}
```

#### POST /api/check-domain
```typescript
Input: {
  domainName: string
  extension: "my.id" | "biz.id" | "web.id"
}

Output: {
  success: boolean
  domain: string
  available: boolean
  message: string
  price: number
}
```

#### GET /api/transactions
```typescript
Output: {
  success: boolean
  data: Transaction[]
  total: number
}
```

### 3. Business Logic Layer

**Services & Utils:**

#### Domain Registration Logic
```typescript
// app/api/register-domain/route.ts

1. Input Validation
   - Domain name min 3 char
   - Valid extension check
   - Promo code verification

2. Promo Calculation
   - DOMAINGRATIS = 100% discount
   - Default price: 189,000 IDR
   - Final price calculation

3. Email Selection
   - Random selection dari pool
   - Duplicate prevention
   - Auto-claim simulation

4. Transaction Recording
   - Generate unique ID
   - Store transaction data
   - Return to client
```

#### Email Pool Management
```typescript
// app/api/zulzzmail/route.ts

AVAILABLE_EMAILS: string[] = [
  "swift7317@thueotp.net",
  "admin2024@tempmail.org",
  // ... more emails
]

1. On each request:
   - Select random email
   - Return with metadata
   - Can be extended dengan API call
```

## Data Flow

### Registration Flow

```
User Input
  ↓
Form Validation (Client)
  ↓
POST /api/register-domain
  ↓
[Server Side]
  ├─ Zod Validation
  ├─ Promo Check
  ├─ Email Fetch (GET /api/zulzzmail)
  ├─ TTM Host Simulation
  ├─ Transaction Generate
  └─ Response
  ↓
[Client Side]
  ├─ Success State
  ├─ Display Results
  └─ Copy Functions
```

### Email Generation Flow

```
User registers domain
  ↓
POST /api/register-domain
  ├─ Call GET /api/zulzzmail
  │  ├─ Get available emails
  │  ├─ Select random
  │  └─ Return selected email
  ├─ Continue registration
  └─ Return email in response
```

## Component Architecture

### Client Components

```
app/
├── page.tsx (Server Component)
│   ├── DomainForm (Client)
│   │   ├── Input field
│   │   ├── Extension buttons
│   │   ├── Preview display
│   │   ├── Submit button
│   │   └── Success card
│   └── InfoSection (Server)
│       ├── TTM Host info
│       ├── Zulzzmail info
│       └── System info
└── layout.tsx (Root Layout)
    ├── Metadata
    ├── Viewport
    └── Analytics
```

### UI Components

```
components/
├── ui/
│   ├── button.tsx
│   ├── card.tsx
│   ├── input.tsx
│   └── [more shadcn components]
├── domain-form.tsx
└── info-section.tsx
```

## State Management

### Client State (DomainForm)

```typescript
const [domainName, setDomainName] = useState("");
const [selectedExtension, setSelectedExtension] = useState("my.id");
const [loading, setLoading] = useState(false);
const [result, setResult] = useState(null);
const [error, setError] = useState("");
```

**State Flow:**
1. User input → domainName
2. Extension selection → selectedExtension
3. Form submit → loading = true
4. API response → loading = false, result/error set
5. Display success/error card

## API Response Examples

### Success Response

```json
{
  "success": true,
  "message": "Domain berhasil dibeli dan email ter-claim!",
  "data": {
    "transactionId": "TRX-1718372699167",
    "domain": "myawesomebusiness.biz.id",
    "registeredEmail": "user@sharklasers.com",
    "price": 189000,
    "discount": 189000,
    "finalPrice": 0,
    "promoApplied": true,
    "status": "registered",
    "claimedAt": "2026-07-18T11:04:30.000Z"
  }
}
```

### Error Response

```json
{
  "success": false,
  "error": "Validasi input gagal",
  "details": [
    {
      "code": "too_small",
      "minimum": 3,
      "type": "string",
      "path": ["domainName"],
      "message": "String must contain at least 3 character(s)"
    }
  ]
}
```

## Error Handling

### Client-Side Errors
- Empty input validation
- Form state management
- User-friendly error messages

### Server-Side Errors
- Zod validation errors
- Invalid promo codes
- API failures
- Email fetch failures

### Error Recovery
```typescript
// User can retry without refreshing
- Clear form on retry
- Reset error state
- Maintain input values (optional)
```

## Validation Schema

### Domain Registration Validation

```typescript
const RegisterSchema = z.object({
  domainName: z.string()
    .min(3, "Nama domain minimal 3 karakter")
    .max(50, "Nama domain maksimal 50 karakter"),
  
  extension: z.enum(["my.id", "biz.id", "web.id"]),
  
  promoCode: z.string().optional()
});
```

## Styling Architecture

### Design Tokens (Tailwind v4)

```css
/* globals.css */
@theme {
  --color-primary: #3b82f6;
  --color-background: #ffffff;
  --color-foreground: #000000;
  --color-muted: #6b7280;
  --color-success: #22c55e;
  --color-destructive: #ef4444;
}
```

### Component Classes

```typescript
// Semantic color system
- bg-background  // Main background
- text-foreground // Main text
- border-primary  // Primary borders
- bg-muted       // Secondary backgrounds
- text-muted-foreground  // Secondary text
```

### Responsive Design

```typescript
// Mobile-first breakpoints
- base       // Mobile (< 640px)
- sm:       // Small (≥ 640px)
- md:       // Medium (≥ 768px)
- lg:       // Large (≥ 1024px)
- xl:       // Extra Large (≥ 1280px)
```

## Performance Optimization

### Frontend
- Image lazy loading
- Code splitting (Next.js automatic)
- CSS purging (Tailwind automatic)
- Minification (Production build)

### Backend
- API response caching (optional)
- Database query optimization (future)
- Rate limiting (recommended)
- Error logging

### Metrics

Target Web Vitals:
- **LCP**: < 2.5s (Largest Contentful Paint)
- **FID**: < 100ms (First Input Delay)
- **CLS**: < 0.1 (Cumulative Layout Shift)

## Security Considerations

### Input Validation
- Zod validation on server
- Sanitize domain names
- Promo code verification

### API Security
- Request validation
- Error message safety (no sensitive info)
- CORS configuration

### Production Recommendations
- Rate limiting
- API key management
- Secure environment variables
- HTTPS enforcement
- CSRF protection
- XSS prevention

## Scalability Considerations

### Current Implementation (Simulasi)
- Stateless API
- No database required
- Horizontal scaling ready

### Future Database Integration

```typescript
// Example with Neon + Drizzle
export const transactions = pgTable('transactions', {
  id: serial('id').primaryKey(),
  transactionId: text('transaction_id').unique(),
  domain: text('domain').notNull(),
  email: text('email').notNull(),
  price: integer('price'),
  status: text('status'),
  createdAt: timestamp('created_at').defaultNow(),
});
```

### Caching Strategy

```typescript
// Response caching
- Email list: Cache 1 hour
- Domain availability: Cache 5 minutes
- Transaction: No cache (immediate)
```

## Deployment Considerations

### Environment Variables
```env
NEXT_PUBLIC_BASE_URL=https://domain.com
NODE_ENV=production
TTM_HOST_API_KEY=xxx (optional)
ZULZZMAIL_API_KEY=xxx (optional)
```

### Build Optimization
```bash
# Next.js build
pnpm build

# Outputs
- .next/standalone (optimized)
- .next/static (assets)
- public/ (static files)
```

### Database Migrations (Future)

```bash
# Drizzle ORM migrations
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

## Monitoring & Logging

### Recommended Tools
- **Errors**: Sentry
- **Analytics**: Vercel Analytics, Posthog
- **Uptime**: Uptime Robot
- **Performance**: Web Vitals

## Testing Strategy

### Unit Tests
- Input validation
- Promo code logic
- Email selection

### Integration Tests
- Form submission
- API endpoint responses
- Error handling

### E2E Tests
- Complete registration flow
- Copy functionality
- Responsive design

## Future Enhancements

1. **Database Integration**
   - Neon for transaction storage
   - User authentication
   - Order history

2. **Real API Integration**
   - TTM Host API
   - Zulzzmail API
   - Payment gateway

3. **Advanced Features**
   - Domain renewal
   - Bulk registration
   - Admin dashboard
   - User accounts

4. **Analytics**
   - Registration metrics
   - Popular domains
   - Conversion tracking

5. **Performance**
   - Image optimization
   - Lazy loading
   - Service worker
   - PWA support

---

**Architecture Version:** 1.0
**Last Updated:** July 2026
