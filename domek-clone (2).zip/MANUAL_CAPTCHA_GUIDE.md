# Manual CAPTCHA Input - Panduan Penggunaan

## Apa yang Berubah?

Sebelumnya, sistem menggunakan **GPT-4o Vision** dari OpenAI untuk secara otomatis membaca dan menyelesaikan CAPTCHA. Sekarang, **user akan diminta untuk manual menginput kode CAPTCHA** yang muncul di gambar.

## Alur Proses (Step by Step)

### 1️⃣ Masukkan Nama Domain
```
Input: namadomain
Pilih TLD: .my.id / .biz.id / .web.id
```

### 2️⃣ Klik "Daftarkan Domain Gratis"
- Sistem akan mulai proses otomatis
- Progress steps ditampilkan di "Log Proses Otomatis"

### 3️⃣ Step 1-2 Berjalan Otomatis
```
✅ Step 1: Generate Email - Email sementara dibuat dari Zulzzmail
✅ Step 2: Ambil CSRF & CAPTCHA - Token dan gambar CAPTCHA diunduh
```

### 4️⃣ ⏸️ CAPTCHA Modal Muncul
Saat gambar CAPTCHA diunduh, sebuah modal akan muncul dengan:

```
┌─────────────────────────────────┐
│   Verifikasi CAPTCHA Manual     │
│   Silakan masukkan kode yang    │
│   terlihat di gambar            │
│                                 │
│   [Gambar CAPTCHA]              │
│                                 │
│   Input: [____ABC123____]       │
│   [Kirim CAPTCHA]               │
└─────────────────────────────────┘
```

### 5️⃣ Baca dan Masukkan Kode CAPTCHA
```
📝 Aturan Input:
   - Baca karakter di gambar dengan hati-hati
   - Tidak perlu ada spasi
   - Case-insensitive (auto-convert ke uppercase)
   - Max 20 karakter
   - Contoh: "ABC123" atau "XYZ789"
```

### 6️⃣ Klik "Kirim CAPTCHA"
- Modal akan hilang
- Proses melanjutkan ke step berikutnya

### 7️⃣ Step 4-7 Berjalan Otomatis
```
✅ Step 4: Daftar Akun WHMCS - Akun baru dibuat
✅ Step 5: Login & Keranjang - Domain ditambahkan ke cart
✅ Step 6: Promo DOMAINGRATIS - Kode promo diterapkan
✅ Step 7: Checkout & Konfirmasi - Order diproses
```

### 8️⃣ Selesai! Hasil Ditampilkan
```
Email: xxxxx@zulzzmail.co.id
Password: [password yang dihasilkan]
Domain: namadomain.my.id
Status: ✅ Order Berhasil
ID Transaksi: TRX-TTM-[order-id]
```

## Troubleshooting

### ❌ Masalah: "Incorrect verification code"
**Solusi:**
- Baca CAPTCHA dengan lebih teliti
- Pastikan tidak ada karakter yang terlewat
- Jika masih salah, proses akan restart otomatis

### ❌ Masalah: Modal tidak muncul
**Solusi:**
- Refresh halaman
- Cek console browser untuk error messages
- Pastikan network connection stabil

### ❌ Masalah: Input field tidak bisa diketik
**Solusi:**
- Klik di dalam input field terlebih dahulu
- Pastikan modal tidak tertutup dengan key Escape

### ❌ Masalah: "Email already registered"
**Solusi:**
- Sistem memilih email random dari Zulzzmail
- Error ini jarang terjadi, coba submit ulang
- Jika terus muncul, tunggu beberapa menit lalu coba lagi

### ❌ Masalah: Process di Step 1 atau 2 gagal
**Solusi:**
- Cek status TTMHost atau Zulzzmail (mungkin sedang down)
- Coba beberapa saat kemudian
- Lihat pesan error lengkap di log untuk detail

## Fitur UI

### 📊 Live Process Log
Setiap step ditampilkan real-time dengan status:
- 🟡 **Running** - Sedang berjalan
- ✅ **Done** - Selesai
- ❌ **Error** - Gagal

### 🔄 Reset Button
Jika terjadi error, klik "Reset" untuk:
- Membatalkan proses saat ini
- Menghapus log semua steps
- Kembali ke form awal

### 💚 Promo Badge
Menampilkan informasi promo "DOMAINGRATIS" yang otomatis diterapkan:
```
💚 DOMAINGRATIS — diterapkan otomatis, harga Rp 0
```

## Catatan Penting

⚠️ **Manual CAPTCHA lebih aman!**
- Tidak ada AI yang membaca data pribadi
- User 100% kontrol input
- Lebih privacy-friendly

⚠️ **Jangan meninggalkan modal terbuka**
- Modal blocking (proses pause)
- Input CAPTCHA dan submit segera

⚠️ **Durasi modal terbuka**
- Modal akan tetap terbuka sampai user submit
- Tidak ada timeout
- User bebas membaca dengan teliti

## Perbedaan dengan Sebelumnya

| Fitur | Sebelumnya (AI Vision) | Sekarang (Manual) |
|-------|----------------------|-----------------|
| CAPTCHA Solving | Otomatis oleh GPT-4o | Manual user input |
| API Key Diperlukan | ✅ Ya (AI Gateway) | ❌ Tidak perlu |
| Biaya | 💰 Per request (AI) | 💰 Gratis |
| Akurasi | ~95% | 100% (user input) |
| Privacy | Medium (AI reads) | Tinggi (no AI) |
| User Interaction | 0 | 1x (manual input) |

## Tips & Trick

💡 **Tip 1: Baca Perlahan**
- Jangan terburu-buru membaca CAPTCHA
- Ambil screenshot jika perlu

💡 **Tip 2: Zoom In**
- Jika CAPTCHA sulit dibaca
- Gunakan zoom browser untuk perbesar modal

💡 **Tip 3: Auto-Uppercase**
- Input akan auto-convert ke uppercase
- Jadi tidak perlu khawatir dengan case

💡 **Tip 4: Periksa Typo**
- Sebelum submit, pastikan tidak ada typo
- Satu karakter salah = error

## Support

Jika mengalami masalah:
1. Lihat Live Process Log untuk detail error
2. Baca troubleshooting section di atas
3. Cek status website TTMHost dan Zulzzmail
4. Coba reset dan submit ulang
