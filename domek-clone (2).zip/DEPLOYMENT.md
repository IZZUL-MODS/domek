# 🚀 Deployment Guide - Domain Gratis Indonesia

Panduan lengkap untuk deploy aplikasi Domain Gratis Indonesia ke berbagai platform.

## 1. Deploy ke Vercel (Recommended)

Vercel adalah platform terbaik untuk Next.js applications.

### Step 1: Push ke GitHub

```bash
git init
git add .
git commit -m "Initial commit: Domain Gratis Indonesia"
git remote add origin https://github.com/username/domain-gratis-indonesia.git
git push -u origin main
```

### Step 2: Connect to Vercel

1. Kunjungi [vercel.com](https://vercel.com)
2. Sign up atau login dengan GitHub
3. Click "Add New..." → "Project"
4. Select repository `domain-gratis-indonesia`
5. Vercel akan auto-detect Next.js
6. Click "Deploy"

### Step 3: Environment Variables (Optional)

Jika ingin production environment:

1. Buka project di Vercel dashboard
2. Settings → Environment Variables
3. Tambahkan:
   ```
   NEXT_PUBLIC_BASE_URL=https://your-domain.vercel.app
   TTM_HOST_API_KEY=your_key_here (jika ada)
   ```

**Deployment done!** Site sudah live di Vercel.

---

## 2. Deploy ke Netlify

### Step 1: Build untuk Production

```bash
pnpm build
```

### Step 2: Configure netlify.toml

```toml
[build]
  command = "pnpm build"
  publish = ".next"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[functions]
  directory = "netlify/functions"
```

### Step 3: Deploy

```bash
npm install -g netlify-cli
netlify deploy --prod
```

---

## 3. Deploy ke AWS Amplify

### Step 1: Install AWS CLI

```bash
npm install -g @aws-amplify/cli
amplify configure
```

### Step 2: Initialize Amplify

```bash
amplify init
# Follow prompts
```

### Step 3: Deploy

```bash
amplify publish
```

---

## 4. Deploy ke Railway

### Step 1: Create Account

Kunjungi [railway.app](https://railway.app)

### Step 2: Connect GitHub

1. Click "New Project"
2. Select "Deploy from GitHub"
3. Connect repository
4. Railway akan detect Next.js
5. Click "Deploy"

---

## 5. Deploy ke Heroku

### Step 1: Install Heroku CLI

```bash
npm install -g heroku
heroku login
```

### Step 2: Create Heroku App

```bash
heroku create domain-gratis-indonesia
```

### Step 3: Deploy

```bash
git push heroku main
```

---

## 6. Self-Hosted (VPS / Dedicated Server)

### Prerequisites

- Server dengan Node.js 18+ terinstall
- nginx atau Apache (reverse proxy)
- PM2 atau similar (process manager)

### Step 1: SSH to Server

```bash
ssh user@your-server.com
cd /var/www
```

### Step 2: Clone & Setup

```bash
git clone https://github.com/username/domain-gratis-indonesia.git
cd domain-gratis-indonesia
pnpm install
pnpm build
```

### Step 3: Start with PM2

```bash
npm install -g pm2
pm2 start "pnpm start" --name "domain-gratis"
pm2 save
pm2 startup
```

### Step 4: Setup Nginx

Create `/etc/nginx/sites-available/domain-gratis`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/domain-gratis /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Step 5: SSL Certificate (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

---

## 7. Deploy ke Docker

### Step 1: Create Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install

COPY . .

RUN pnpm build

EXPOSE 3000

CMD ["pnpm", "start"]
```

### Step 2: Build Image

```bash
docker build -t domain-gratis:latest .
```

### Step 3: Run Container

```bash
docker run -p 3000:3000 domain-gratis:latest
```

### Step 4: Push to Docker Hub

```bash
docker tag domain-gratis:latest username/domain-gratis:latest
docker push username/domain-gratis:latest
```

---

## 8. Deploy ke Kubernetes

### Create deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: domain-gratis
spec:
  replicas: 2
  selector:
    matchLabels:
      app: domain-gratis
  template:
    metadata:
      labels:
        app: domain-gratis
    spec:
      containers:
      - name: domain-gratis
        image: username/domain-gratis:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: production
```

### Deploy

```bash
kubectl apply -f deployment.yaml
kubectl expose deployment domain-gratis --type=LoadBalancer --port=80 --target-port=3000
```

---

## Production Checklist

- [ ] Environment variables diset di platform hosting
- [ ] Database terkoneksi (jika ada)
- [ ] CORS diconfig dengan benar
- [ ] Rate limiting diterapkan untuk API
- [ ] Error handling dan logging setup
- [ ] Monitoring dan uptime checks aktif
- [ ] SSL/TLS certificate configured
- [ ] Backup strategy diterapkan
- [ ] CDN setup untuk static assets
- [ ] Performance monitoring active

## Performance Tips

1. **Enable compression** di nginx/server
2. **Use CDN** untuk static assets
3. **Optimize images** sebelum deploy
4. **Setup caching headers** untuk static content
5. **Monitor Core Web Vitals** dengan monitoring tools
6. **Setup alerting** untuk downtime

## Rollback Strategy

### Vercel
1. Go to Deployments tab
2. Click on previous deployment
3. Click "Promote to Production"

### Git-based
```bash
git revert HEAD
git push origin main
```

### Manual Backup
```bash
# Sebelum deploy
tar -czf backup-$(date +%Y%m%d).tar.gz .
```

---

## Support & Troubleshooting

**Domain gratis tidak register di production?**
- Check TTM Host API credentials
- Verify environment variables
- Check server logs: `pm2 logs domain-gratis`

**Email tidak tergenerate?**
- Check Zulzzmail integration
- Verify API key dan URL
- Check rate limiting

**High latency?**
- Upgrade server specs
- Implement caching
- Use CDN untuk static assets
- Check database query performance

---

**Questions?** Contact support atau buka issue di GitHub.
