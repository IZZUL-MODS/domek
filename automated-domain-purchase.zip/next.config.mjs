/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Exclude server-only packages from the client bundle
  serverExternalPackages: ['playwright', 'playwright-core'],
  webpack: (config, { isServer }) => {
    if (!isServer) {
      config.resolve.fallback = {
        ...config.resolve.fallback,
        fs: false,
        path: false,
        os: false,
        crypto: false,
        stream: false,
        util: false,
        http: false,
        https: false,
        zlib: false,
        tls: false,
        net: false,
        dns: false,
        events: false,
        worker_threads: false,
        readline: false,
        child_process: false,
      };
    }

    return config;
  },
}

export default nextConfig
