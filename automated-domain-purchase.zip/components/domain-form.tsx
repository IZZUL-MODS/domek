'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import axios from 'axios';

interface RegistrationResponse {
  success: boolean;
  registration: {
    id: string;
    domainName: string;
    extension: string;
    fullDomain: string;
    tempEmail: string;
    inboxLink: string;
    status: string;
  };
  jobId: string;
}

export function DomainForm() {
  const [domainName, setDomainName] = useState('');
  const [extension, setExtension] = useState<'my.id' | 'biz.id' | 'web.id'>('my.id');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RegistrationResponse['registration'] | null>(null);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (!domainName.trim()) {
        throw new Error('Nama domain tidak boleh kosong');
      }

      // Validate domain name (alphanumeric and hyphens only)
      if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(domainName.toLowerCase())) {
        throw new Error('Nama domain tidak valid. Gunakan huruf, angka, dan tanda hubung (-) saja');
      }

      console.log('[v0] Submitting domain registration:', {
        domainName,
        extension,
      });

      const response = await axios.post<RegistrationResponse>('/api/domain/register', {
        domainName: domainName.toLowerCase(),
        extension,
      });

      if (response.data.success) {
        setResult(response.data.registration);
        setDomainName('');
        console.log('[v0] Registration submitted successfully');
      }
    } catch (err) {
      const errorMsg =
        axios.isAxiosError(err) && err.response?.data?.error
          ? err.response.data.error
          : err instanceof Error
            ? err.message
            : 'Terjadi kesalahan';

      setError(errorMsg);
      console.error('[v0] Form submission error:', errorMsg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {!result ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Domain Name Input */}
          <div>
            <label className="block text-sm font-semibold mb-2">Nama Domain</label>
            <input
              type="text"
              value={domainName}
              onChange={(e) => setDomainName(e.target.value)}
              placeholder="Contoh: websiteku, bisnisku, etc"
              className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 transition"
              disabled={loading}
            />
            <p className="text-xs text-slate-400 mt-1">
              Gunakan huruf kecil, angka, dan tanda hubung (-) saja
            </p>
          </div>

          {/* Extension Select */}
          <div>
            <label className="block text-sm font-semibold mb-2">Ekstensi Domain</label>
            <select
              value={extension}
              onChange={(e) => setExtension(e.target.value as 'my.id' | 'biz.id' | 'web.id')}
              className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 transition cursor-pointer"
              disabled={loading}
            >
              <option value="my.id">.my.id - Personal</option>
              <option value="biz.id">.biz.id - Bisnis</option>
              <option value="web.id">.web.id - Website</option>
            </select>
          </div>

          {/* Preview */}
          <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-600">
            <p className="text-sm text-slate-400">Domain Anda:</p>
            <p className="text-2xl font-bold text-blue-400">
              {domainName || 'nama'}.{extension}
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-900/30 border border-red-700 rounded-lg">
              <p className="text-sm text-red-300">{error}</p>
            </div>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white font-semibold py-3 rounded-lg transition disabled:opacity-50"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Memproses...
              </span>
            ) : (
              'Daftar Domain Gratis'
            )}
          </Button>
        </form>
      ) : (
        <div className="space-y-4">
          {/* Success Message */}
          <div className="p-6 bg-green-900/30 border border-green-700 rounded-lg">
            <div className="flex items-start gap-3">
              <div className="text-2xl">✓</div>
              <div>
                <p className="font-bold text-green-300 text-lg">
                  Registrasi Berhasil Diajukan!
                </p>
                <p className="text-green-200 text-sm mt-1">
                  Domain Anda sedang diproses secara otomatis
                </p>
              </div>
            </div>
          </div>

          {/* Result Details */}
          <div className="space-y-3 bg-slate-700/50 p-4 rounded-lg border border-slate-600">
            <div>
              <p className="text-sm text-slate-400">Domain</p>
              <p className="font-bold text-white">{result.fullDomain}</p>
            </div>

            <div>
              <p className="text-sm text-slate-400">Email Pendaftaran</p>
              <p className="font-mono text-white break-all">{result.tempEmail}</p>
            </div>

            <div>
              <p className="text-sm text-slate-400 mb-2">Email Inbox</p>
              <a
                href={result.inboxLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-semibold transition"
              >
                Buka Inbox →
              </a>
            </div>

            <div>
              <p className="text-sm text-slate-400">ID Registrasi</p>
              <p className="font-mono text-slate-300 text-xs break-all">{result.id}</p>
            </div>

            <div>
              <p className="text-sm text-slate-400">Status</p>
              <div className="mt-1 inline-block px-3 py-1 bg-blue-900/50 border border-blue-700 rounded-full text-blue-300 text-sm font-semibold">
                {result.status === 'pending'
                  ? '⏳ Menunggu'
                  : result.status === 'in_progress'
                    ? '⚙️ Sedang Diproses'
                    : result.status === 'completed'
                      ? '✓ Selesai'
                      : '❌ Gagal'}
              </div>
            </div>
          </div>

          {/* Info */}
          <div className="p-4 bg-yellow-900/30 border border-yellow-700 rounded-lg text-sm text-yellow-200">
            <p className="font-semibold mb-2">💡 Tips:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Cek email inbox untuk konfirmasi registrasi</li>
              <li>Proses otomatis memerlukan beberapa menit</li>
              <li>Gunakan tab "Riwayat Registrasi" untuk melihat status update</li>
            </ul>
          </div>

          {/* New Registration Button */}
          <button
            onClick={() => setResult(null)}
            className="w-full px-4 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold transition"
          >
            Daftar Domain Lagi
          </button>
        </div>
      )}
    </div>
  );
}
