'use client';

import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';

interface Registration {
  id: string;
  domainName: string;
  extension: string;
  fullDomain: string;
  tempEmail: string;
  inboxLink: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  createdAt: string;
  completedAt?: string;
  idwebhostOrderId?: string;
  directOrderUrl?: string;
  accountPassword?: string;
  error?: string;
  logs?: string[];
}

const STATUS_CONFIG = {
  completed: { label: 'Selesai', dot: 'bg-green-500', badge: 'bg-green-900/40 border-green-700 text-green-300' },
  in_progress: { label: 'Diproses', dot: 'bg-blue-400 animate-pulse', badge: 'bg-blue-900/40 border-blue-700 text-blue-300' },
  pending: { label: 'Menunggu', dot: 'bg-yellow-400 animate-pulse', badge: 'bg-yellow-900/40 border-yellow-700 text-yellow-300' },
  failed: { label: 'Gagal', dot: 'bg-red-500', badge: 'bg-red-900/40 border-red-700 text-red-300' },
};

function copyToClipboard(text: string): Promise<void> {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text);
  }
  // Fallback for iframe / non-secure context
  return new Promise((resolve, reject) => {
    const el = document.createElement('textarea');
    el.value = text;
    el.style.position = 'fixed';
    el.style.left = '-9999px';
    el.style.top = '-9999px';
    document.body.appendChild(el);
    el.focus();
    el.select();
    try {
      document.execCommand('copy');
      resolve();
    } catch (err) {
      reject(err);
    } finally {
      document.body.removeChild(el);
    }
  });
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    copyToClipboard(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button
      onClick={handleCopy}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 border border-slate-600 hover:border-slate-500 rounded-md text-xs font-medium text-slate-300 transition-all"
    >
      {copied ? (
        <>
          <svg className="w-3 h-3 text-green-400" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <polyline points="20 6 9 17 4 12" />
          </svg>
          <span className="text-green-400">Tersalin!</span>
        </>
      ) : (
        <>
          <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
          </svg>
          {label}
        </>
      )}
    </button>
  );
}

function RegistrationCard({ reg }: { reg: Registration }) {
  const [logsOpen, setLogsOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const cfg = STATUS_CONFIG[reg.status];

  return (
    <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 hover:border-slate-600 transition-colors">
      {/* Top row: domain + status */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <h3 className="font-bold text-white text-base break-all flex-1">
          {reg.fullDomain}
        </h3>
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 border rounded-full text-xs font-semibold ${cfg.badge}`}>
          <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
          {cfg.label}
        </span>
      </div>

      {/* Email row */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <span className="font-mono text-xs text-slate-300 break-all flex-1">{reg.tempEmail}</span>
        <div className="flex gap-2 flex-shrink-0">
          <CopyButton text={reg.tempEmail} label="Salin Email" />
          <a
            href={reg.inboxLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-700 hover:bg-indigo-600 border border-indigo-600 rounded-md text-xs font-medium text-white transition-all"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,12 2,6"/>
            </svg>
            Buka Inbox
          </a>
        </div>
      </div>

      {/* Meta info */}
      <div className="text-xs text-slate-500 mb-3">
        Daftar: {new Date(reg.createdAt).toLocaleString('id-ID')}
        {reg.completedAt && (
          <> &middot; Selesai: {new Date(reg.completedAt).toLocaleString('id-ID')}</>
        )}
      </div>

      {/* Success: order ID + account credentials */}
      {reg.status === 'completed' && reg.idwebhostOrderId && (
        <div className="flex items-center gap-2 p-2 bg-green-900/20 border border-green-800/50 rounded-lg mb-3">
          <svg className="w-4 h-4 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 15 9 12"/>
          </svg>
          <div className="flex-1 min-w-0">
            <span className="text-xs text-green-400 font-medium">Order ID: </span>
            <span className="font-mono text-xs text-green-300 break-all">{reg.idwebhostOrderId}</span>
          </div>
          <CopyButton text={reg.idwebhostOrderId} label="Salin" />
        </div>
      )}

      {/* Account credentials block */}
      {reg.status === 'completed' && (reg.accountPassword || reg.tempEmail) && (
        <div className="mb-3 border border-indigo-800/60 rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-3 py-2 bg-indigo-900/30 border-b border-indigo-800/40">
            <svg className="w-3.5 h-3.5 text-indigo-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wider">Kredensial Akun IDWebhost</span>
          </div>
          <div className="p-3 bg-slate-900/50 space-y-2">
            {/* Email */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 w-16 flex-shrink-0">Email</span>
              <span className="font-mono text-xs text-slate-200 flex-1 break-all">{reg.tempEmail}</span>
              <CopyButton text={reg.tempEmail} label="Salin" />
            </div>
            {/* Password */}
            {reg.accountPassword && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 w-16 flex-shrink-0">Password</span>
                <span className="font-mono text-xs text-slate-200 flex-1 break-all">
                  {showPassword ? reg.accountPassword : '•'.repeat(reg.accountPassword.length)}
                </span>
                <button
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1.5 bg-slate-700 hover:bg-slate-600 border border-slate-600 rounded-md text-slate-400 hover:text-slate-200 transition-all flex-shrink-0"
                  title={showPassword ? 'Sembunyikan' : 'Tampilkan'}
                >
                  {showPassword ? (
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>
                    </svg>
                  ) : (
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
                    </svg>
                  )}
                </button>
                <CopyButton text={reg.accountPassword} label="Salin" />
              </div>
            )}
          </div>
          <div className="px-3 py-1.5 bg-amber-900/20 border-t border-amber-800/30">
            <p className="text-xs text-amber-400/80">Simpan kredensial ini sebelum halaman ditutup</p>
          </div>
        </div>
      )}

      {/* Failed: error + manual order link */}
      {reg.status === 'failed' && (
        <div className="p-3 bg-red-900/20 border border-red-800/50 rounded-lg mb-3 space-y-2">
          {reg.error && (
            <p className="text-xs text-red-300">{reg.error}</p>
          )}
          {reg.directOrderUrl && (
            <a
              href={reg.directOrderUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-orange-700 hover:bg-orange-600 border border-orange-600 rounded-md text-xs font-semibold text-white transition-all"
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
              </svg>
              Lanjutkan Order Manual di IDWebhost
            </a>
          )}
        </div>
      )}

      {/* Logs */}
      {reg.logs && reg.logs.length > 0 && (
        <div>
          <button
            onClick={() => setLogsOpen(!logsOpen)}
            className="inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-400 transition-colors"
          >
            <svg
              className={`w-3 h-3 transition-transform ${logsOpen ? 'rotate-90' : ''}`}
              fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"
            >
              <polyline points="9 18 15 12 9 6"/>
            </svg>
            Log proses ({reg.logs.length} langkah)
          </button>
          {logsOpen && (
            <div className="mt-2 p-2.5 bg-slate-900/70 border border-slate-700 rounded-lg space-y-1 max-h-40 overflow-y-auto">
              {reg.logs.map((log, i) => (
                <p key={i} className="text-xs font-mono text-slate-400 leading-relaxed">
                  <span className="text-slate-600 mr-1">{i + 1}.</span>{log}
                </p>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export function RegistrationHistory() {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState('');
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  const fetchRegistrations = useCallback(async () => {
    try {
      const res = await axios.get('/api/domain/list');
      if (res.data.success) {
        setRegistrations(res.data.registrations);
        setLastRefresh(new Date());
        setFetchError('');
      }
    } catch {
      setFetchError('Gagal memuat riwayat registrasi');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRegistrations();
    const iv = setInterval(fetchRegistrations, 4000);
    return () => clearInterval(iv);
  }, [fetchRegistrations]);

  const hasActive = registrations.some(
    (r) => r.status === 'pending' || r.status === 'in_progress'
  );

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-base font-semibold text-white">Riwayat Registrasi</h2>
          {lastRefresh && (
            <p className="text-xs text-slate-500 mt-0.5">
              Diperbarui {lastRefresh.toLocaleTimeString('id-ID')}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {hasActive && (
            <span className="inline-flex items-center gap-1.5 text-xs text-blue-400">
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              Ada proses berjalan
            </span>
          )}
          <button
            onClick={fetchRegistrations}
            className="p-2 bg-slate-700 hover:bg-slate-600 border border-slate-600 rounded-lg transition-colors"
            title="Refresh"
          >
            <svg className="w-4 h-4 text-slate-300" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3">
          <div className="w-6 h-6 border-2 border-slate-600 border-t-indigo-400 rounded-full animate-spin" />
          <p className="text-sm text-slate-500">Memuat riwayat...</p>
        </div>
      ) : fetchError ? (
        <div className="p-4 bg-red-900/30 border border-red-800 rounded-xl text-red-300 text-sm">
          {fetchError}
        </div>
      ) : registrations.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-14 gap-3 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-700/60 flex items-center justify-center">
            <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/>
            </svg>
          </div>
          <p className="text-slate-400 text-sm">Belum ada registrasi domain</p>
          <p className="text-slate-600 text-xs">Daftarkan domain pertama Anda di tab Registrasi</p>
        </div>
      ) : (
        <div className="space-y-3">
          {registrations.map((reg) => (
            <RegistrationCard key={reg.id} reg={reg} />
          ))}
        </div>
      )}

      {/* Footer note */}
      {registrations.length > 0 && (
        <p className="text-xs text-slate-600 text-center mt-5">
          Auto-refresh setiap 4 detik &middot; {registrations.length} total registrasi
        </p>
      )}
    </div>
  );
}
