import NodeCache from 'node-cache';

export interface Job {
  id: string;
  type: string;
  data: any;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  result?: any;
  error?: string;
  retries: number;
  maxRetries: number;
}

type JobHandler = (data: any) => Promise<any>;

class JobQueue {
  private cache: NodeCache;
  private handlers: Map<string, JobHandler>;

  constructor() {
    this.cache = new NodeCache({ stdTTL: 86400 });
    this.handlers = new Map();
  }

  registerHandler(type: string, handler: JobHandler): void {
    this.handlers.set(type, handler);
  }

  /**
   * Enqueue a job and immediately kick off processing in the background.
   * This is "fire-and-forget" — the caller does not await the processing.
   */
  enqueue(type: string, data: any): string {
    const id = `job-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const job: Job = {
      id,
      type,
      data,
      status: 'pending',
      createdAt: new Date(),
      retries: 0,
      maxRetries: 2,
    };

    this.cache.set(`job:${id}`, job);

    // Fire-and-forget: process immediately without blocking the response
    setImmediate(() => this.processJob(id));

    return id;
  }

  getJob(id: string): Job | null {
    return this.cache.get<Job>(`job:${id}`) || null;
  }

  private async processJob(jobId: string): Promise<void> {
    const job = this.getJob(jobId);
    if (!job) return;

    const handler = this.handlers.get(job.type);
    if (!handler) {
      job.status = 'failed';
      job.error = `No handler registered for job type: ${job.type}`;
      job.completedAt = new Date();
      this.cache.set(`job:${jobId}`, job);
      return;
    }

    job.status = 'processing';
    job.startedAt = new Date();
    this.cache.set(`job:${jobId}`, job);

    try {
      const result = await handler(job.data);
      job.status = 'completed';
      job.completedAt = new Date();
      job.result = result;
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);

      if (job.retries < job.maxRetries) {
        job.retries++;
        job.status = 'pending';
        this.cache.set(`job:${jobId}`, job);
        // Retry after short delay
        setTimeout(() => this.processJob(jobId), 3000 * job.retries);
        return;
      }

      job.status = 'failed';
      job.error = msg;
      job.completedAt = new Date();
    }

    this.cache.set(`job:${jobId}`, job);
  }
}

export const jobQueue = new JobQueue();
