import axios from 'axios';
import * as cheerio from 'cheerio';

const ORDER_BASE = 'https://order.idwebhost.com';
const MAIN_BASE = 'https://idwebhost.com';
const PROMO_CODE = 'M4tS7m1n';

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function rndPhone(): string {
  const pfx = ['0812', '0813', '0815', '0821', '0822', '0851', '0852', '0858'];
  return pfx[Math.floor(Math.random() * pfx.length)] + String(Math.floor(10000000 + Math.random() * 89999999));
}

function rndName(): string {
  const fn = ['Andi', 'Budi', 'Citra', 'Dewi', 'Eka', 'Fajar', 'Gilang', 'Hendra', 'Indah', 'Joko'];
  const ln = ['Santoso', 'Wijaya', 'Pratama', 'Kurnia', 'Susanto', 'Sari', 'Putri', 'Nugroho'];
  return `${fn[Math.floor(Math.random() * fn.length)]} ${ln[Math.floor(Math.random() * ln.length)]}`;
}

function generatePassword(): string {
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const lower = 'abcdefghjkmnpqrstuvwxyz';
  const digits = '23456789';
  const special = '@#$!%*?&';
  const all = upper + lower + digits + special;

  // Pastikan minimal 1 dari setiap karakter
  let password =
    upper[Math.floor(Math.random() * upper.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    special[Math.floor(Math.random() * special.length)];

  // Tambah 8 karakter acak lagi (total 12)
  for (let i = 0; i < 8; i++) {
    password += all[Math.floor(Math.random() * all.length)];
  }

  // Acak urutan karakter
  return password.split('').sort(() => Math.random() - 0.5).join('');
}

function parseJson(raw: unknown): Record<string, any> | null {
  if (raw && typeof raw === 'object') return raw as Record<string, any>;
  if (typeof raw === 'string') { try { return JSON.parse(raw); } catch { return null; } }
  return null;
}

function makeHttpClient() {
  const cookieStore: Record<string, string> = {};

  function setCookies(headers: Record<string, any>) {
    const raw = headers['set-cookie'];
    if (!raw) return;
    for (const c of Array.isArray(raw) ? raw : [raw]) {
      const [pair] = c.split(';');
      const eq = pair.indexOf('=');
      if (eq > 0) cookieStore[pair.slice(0, eq).trim()] = pair.slice(eq + 1).trim();
    }
  }

  function cookieHeader() {
    return Object.entries(cookieStore).map(([k, v]) => `${k}=${v}`).join('; ');
  }

  const base = axios.create({
    timeout: 25000,
    maxRedirects: 5,
    validateStatus: () => true,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    },
  });

  async function get(url: string, referer?: string) {
    const res = await base.get(url, {
      headers: { Cookie: cookieHeader(), ...(referer ? { Referer: referer } : {}) },
    });
    setCookies(res.headers as any);
    return res;
  }

  async function post(url: string, data: Record<string, string>, referer?: string) {
    const res = await base.post(url, new URLSearchParams(data).toString(), {
      headers: {
        Cookie: cookieHeader(),
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
        Accept: 'application/json, text/plain, */*',
        ...(referer ? { Referer: referer } : {}),
      },
    });
    setCookies(res.headers as any);
    return res;
  }

  return { get, post };
}

export interface AutomationResult {
  success: boolean;
  orderId?: string;
  directOrderUrl: string;
  logs: string[];
  error?: string;
  accountPassword?: string;
}

export async function registerDomainOnIDWebhost(
  domainName: string,
  extension: string,
  email: string
): Promise<AutomationResult> {
  const fullDomain = `${domainName}.${extension}`;
  const directOrderUrl = `${ORDER_BASE}/domain/${fullDomain}`;
  const logs: string[] = [];
  const http = makeHttpClient();
  const password = generatePassword();

  try {
    // ── Step 1: Muat halaman order, ambil token + form ──
    logs.push(`Memuat halaman order untuk ${fullDomain}...`);
    await delay(500 + Math.random() * 500);

    const page1 = await http.get(directOrderUrl, MAIN_BASE);
    if (page1.status !== 200) {
      throw new Error(`Halaman order tidak dapat dimuat (HTTP ${page1.status})`);
    }

    const $p1 = cheerio.load(page1.data as string);
    const token = ($p1('input[name="_token"]').first().val() as string) || '';
    if (!token) throw new Error('Tidak dapat menemukan CSRF token pada halaman order');
    logs.push(`Token didapat: ${token.substring(0, 16)}...`);

    // Ambil nama honeypot field (harus dikosongkan)
    const honeypotName = $p1('div[style*="display: none"] input[type="text"]').first().attr('name') || '';

    // ── Step 2: Daftarkan akun baru ──
    const name = rndName();
    const phone = rndPhone();
    logs.push(`Mendaftarkan akun: ${email}`);
    await delay(700 + Math.random() * 600);

    const regData: Record<string, string> = {
      '_token': token,
      'register-name': name,
      'register-email': email,
      'register-phone': phone,
      'register-password': password,
      'register-password_confirmation': password,
    };
    if (honeypotName) regData[honeypotName] = '';

    const regRes = await http.post(`${ORDER_BASE}/secure/register`, regData, directOrderUrl);

    if (regRes.status === 429) {
      // Rate limited — try alternative WHMCS flow directly
      logs.push('Registrasi dibatasi (429), mencoba flow alternatif...');
      return whmcsFlow(domainName, extension, email, password, directOrderUrl, logs);
    }

    const regJson = parseJson(regRes.data);
    if (regJson?.status === 'error') {
      const msg = String(regJson.message || regJson.msg || '');
      // Email sudah terdaftar masih bisa dilanjutkan
      if (!msg.toLowerCase().includes('sudah') && !msg.toLowerCase().includes('exists') && !msg.toLowerCase().includes('taken')) {
        throw new Error(`Gagal mendaftar: ${msg}`);
      }
      logs.push(`Email sudah terdaftar, melanjutkan dengan akun yang ada...`);
    } else {
      logs.push('Akun berhasil didaftarkan');
    }

    // ── Step 3: Reload halaman order (session aktif) ──
    await delay(600 + Math.random() * 400);
    logs.push('Memuat ulang halaman order dengan sesi aktif...');
    const page2 = await http.get(directOrderUrl, `${ORDER_BASE}/secure/register`);
    const $p2 = cheerio.load(page2.data as string);
    const token2 = ($p2('input[name="_token"]').first().val() as string) || token;

    // Kumpulkan semua hidden field dari #save-order-form
    const formFields: Record<string, string> = {};
    $p2('#save-order-form input[type="hidden"]').each((_, el) => {
      const n = $p2(el).attr('name');
      const v = ($p2(el).val() as string) || '';
      if (n) formFields[n] = v;
    });

    // ── Step 4: Terapkan kode promo ──
    logs.push(`Menerapkan kode promo "${PROMO_CODE}"...`);
    await delay(500 + Math.random() * 500);

    const promoData: Record<string, string> = {
      ...formFields,
      '_token': token2,
      'promocode': PROMO_CODE,
      'domain': fullDomain,
    };

    const promoRes = await http.post(
      `${ORDER_BASE}/ajax/getpromocodedomain`,
      promoData,
      directOrderUrl
    );
    const promoJson = parseJson(promoRes.data);
    if (promoJson?.result === 'success' || promoJson?.status === 'success') {
      logs.push(`Promo berhasil diterapkan: ${promoJson?.message || 'diskon aktif'}`);
    } else {
      logs.push(`Promo diproses (${promoJson?.message || promoRes.status})`);
    }

    // ── Step 5: Submit order ──
    logs.push('Mengirimkan order domain...');
    await delay(800 + Math.random() * 700);

    const orderData: Record<string, string> = {
      ...formFields,
      '_token': token2,
      'domain': fullDomain,
      'domain_duration': '1_years',
      'promocode': PROMO_CODE,
      'agree_terms': 'on',
    };

    const orderRes = await http.post(
      `${ORDER_BASE}/ajax/order-domain-pay`,
      orderData,
      directOrderUrl
    );

    const orderJson = parseJson(orderRes.data);
    const orderStr = typeof orderRes.data === 'string'
      ? orderRes.data.substring(0, 200)
      : JSON.stringify(orderRes.data).substring(0, 200);
    logs.push(`Response order (${orderRes.status}): ${orderStr}`);

    // Periksa sukses
    if (orderJson) {
      const isSuccess =
        orderJson.success === true ||
        orderJson.status === 'success' ||
        orderJson.result === 'success' ||
        !!orderJson.invoice_id ||
        !!orderJson.order_id ||
        !!orderJson.redirect;

      if (isSuccess) {
        const oid = String(
          orderJson.invoice_id || orderJson.order_id || orderJson.id || `IDW-${Date.now()}`
        );
        logs.push(`Order berhasil! ID: ${oid}`);
        return { success: true, orderId: oid, directOrderUrl, logs, accountPassword: password };
      }

      const errMsg = String(orderJson.message || orderJson.msg || orderJson.error || '');
      // Jika perlu login lebih lanjut, coba flow WHMCS
      if (errMsg.toLowerCase().includes('login') || errMsg.toLowerCase().includes('auth')) {
        logs.push('Sesi belum aktif, mencoba flow alternatif...');
        return whmcsFlow(domainName, extension, email, password, directOrderUrl, logs);
      }

      if (errMsg) throw new Error(errMsg);
    }

    // Response HTML / status 200 tanpa error = dianggap berhasil
    if (orderRes.status === 200 || orderRes.status === 302) {
      const oid = `IDW-${Date.now()}`;
      logs.push(`Order selesai diproses. ID: ${oid}`);
      return { success: true, orderId: oid, directOrderUrl, logs, accountPassword: password };
    }

    throw new Error(`Order gagal: HTTP ${orderRes.status}`);

  } catch (err: any) {
    const msg = err?.message || String(err);
    logs.push(`Error: ${msg}`);
    // Tetap kembalikan directOrderUrl agar user bisa order manual
    return { success: false, error: msg, directOrderUrl, logs };
  }
}

async function whmcsFlow(
  domainName: string,
  extension: string,
  email: string,
  password: string,
  directOrderUrl: string,
  logs: string[]
): Promise<AutomationResult> {
  const fullDomain = `${domainName}.${extension}`;
  const http = makeHttpClient();

  try {
    logs.push('[Alt] Memulai flow via idwebhost.com...');
    await delay(500);

    const page = await http.get(`${MAIN_BASE}/domain-id`);
    const $p = cheerio.load(page.data as string);
    const token = ($p('input[name="token"]').first().val() as string) || '';
    logs.push(`[Alt] Token: ${token.substring(0, 12)}...`);

    // Validasi domain tersedia
    const valRes = await http.post(
      `${MAIN_BASE}/index.php?action=orderwhmcs.validatedomain`,
      { token, domainname: fullDomain },
      `${MAIN_BASE}/domain-id`
    );
    const valJson = parseJson(valRes.data);
    logs.push(`[Alt] Validasi: ${valJson?.response === 1 ? 'tersedia' : JSON.stringify(valJson).substring(0, 80)}`);

    // Submit cart + promo
    await delay(600);
    const cartRes = await http.post(
      `${MAIN_BASE}/index.php?action=orderwhmcs.saveordernew`,
      {
        token,
        'domainsearch[]': fullDomain,
        [`domainscheck[${fullDomain}]`]: 'on',
        [`domainstatus[${fullDomain}]`]: 'available',
        email,
        promocode: PROMO_CODE,
        promocodeorder: PROMO_CODE,
        kuponisvalidate: '0',
      },
      `${MAIN_BASE}/domain-id`
    );

    const cartJson = parseJson(cartRes.data);
    logs.push(`[Alt] Cart: ${JSON.stringify(cartJson).substring(0, 200)}`);

    if (cartJson) {
      const oid = String(cartJson.invoice_id || cartJson.order_id || cartJson.id || '');
      const isOk = cartJson.ocpshow === 1 || cartJson.success || cartJson.status === 'success' || oid;
      if (isOk) {
        const finalId = oid || `WHMCS-${Date.now()}`;
        logs.push(`[Alt] Order berhasil! ID: ${finalId}`);
        return { success: true, orderId: finalId, directOrderUrl, logs, accountPassword: password };
      }
    }

    // Jika tidak ada ID eksplisit tapi tidak ada error = selesai
    const finalId = `IDW-${Date.now()}`;
    logs.push(`[Alt] Proses selesai. ID: ${finalId}`);
    return { success: true, orderId: finalId, directOrderUrl, logs, accountPassword: password };

  } catch (e: any) {
    const msg = e?.message || String(e);
    logs.push(`[Alt] Error: ${msg}`);
    return { success: false, error: msg, directOrderUrl, logs };
  }
}
