import { jobQueue } from './job-queue';
import { storage } from './storage';
import { registerDomainOnIDWebhost } from './idwebhost-automation';

let initialized = false;

export function initializeJobHandlers() {
  if (initialized) return;
  initialized = true;

  jobQueue.registerHandler('register_domain', async (data: any) => {
    const { registrationId, domainName, extension, tempEmail } = data;

    // Update status to in_progress
    storage.updateRegistration(registrationId, { status: 'in_progress' });

    const result = await registerDomainOnIDWebhost(
      domainName,
      extension,
      tempEmail
    );

    if (result.success) {
      storage.updateRegistration(registrationId, {
        status: 'completed',
        completedAt: new Date(),
        idwebhostOrderId: result.orderId,
        directOrderUrl: result.directOrderUrl,
        accountPassword: result.accountPassword,
        logs: result.logs,
      });
      console.log('[v0] Job completed:', registrationId, result.orderId);
    } else {
      storage.updateRegistration(registrationId, {
        status: 'failed',
        completedAt: new Date(),
        error: result.error,
        directOrderUrl: result.directOrderUrl,
        logs: result.logs,
      });
      console.log('[v0] Job failed:', registrationId, result.error);
    }
    return result;
  });
}
