import NodeCache from 'node-cache';
import { v4 as uuidv4 } from 'uuid';

export interface DomainRegistration {
  id: string;
  domainName: string;
  extension: 'my.id' | 'biz.id' | 'web.id';
  fullDomain: string;
  tempEmail: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  createdAt: Date;
  completedAt?: Date;
  error?: string;
  idwebhostOrderId?: string;
  directOrderUrl?: string;
  accountPassword?: string;
  logs?: string[];
}

class StorageManager {
  private cache: NodeCache;

  constructor() {
    this.cache = new NodeCache({ stdTTL: 86400 }); // 24 hour TTL
  }

  createRegistration(
    domainName: string,
    extension: 'my.id' | 'biz.id' | 'web.id',
    tempEmail: string
  ): DomainRegistration {
    const id = uuidv4();
    const registration: DomainRegistration = {
      id,
      domainName: domainName.toLowerCase(),
      extension,
      fullDomain: `${domainName.toLowerCase()}.${extension}`,
      tempEmail,
      status: 'pending',
      createdAt: new Date(),
    };

    this.cache.set(`registration:${id}`, registration);
    this.addToList('registrations', id);

    return registration;
  }

  getRegistration(id: string): DomainRegistration | null {
    return this.cache.get(`registration:${id}`) || null;
  }

  updateRegistration(
    id: string,
    updates: Partial<DomainRegistration>
  ): DomainRegistration | null {
    const current = this.getRegistration(id);
    if (!current) return null;

    const updated = { ...current, ...updates };
    this.cache.set(`registration:${id}`, updated);
    return updated;
  }

  getAllRegistrations(): DomainRegistration[] {
    const ids: string[] = this.cache.get('registrations') || [];
    return ids
      .map((id) => this.getRegistration(id))
      .filter((r): r is DomainRegistration => r !== null)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  private addToList(listKey: string, item: string): void {
    const list: string[] = this.cache.get(listKey) || [];
    if (!list.includes(item)) {
      list.push(item);
      this.cache.set(listKey, list);
    }
  }
}

export const storage = new StorageManager();
