// Domain list dari https://zulzzmail.biz.id (diambil langsung dari source)
const ZULZZMAIL_DOMAINS = [
  'refk.site',
  'muareview.com',
  'dailynutria.com',
  'xazymarcie.space',
  '5xu.vn',
  'cuahangvppn.shop',
  'wintersmail.site',
  'mailphu.com',
  'huyvillafb.online',
  'mtnewtoy.us',
  'flews.app',
  'gmaill.click',
  'neatdaynote.com',
  'samaltour.site',
  'ai100999.com',
];

export class ZulzzmailService {
  private static randomString(length: number): string {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  /**
   * Generate email address menggunakan domain nyata dari Zulzzmail.
   * Format: {username}@{domain} — domain dipilih acak dari daftar resmi Zulzzmail.
   */
  static async generateTempEmail(): Promise<string> {
    const username = this.randomString(8);
    const domain = ZULZZMAIL_DOMAINS[Math.floor(Math.random() * ZULZZMAIL_DOMAINS.length)];
    const email = `${username}@${domain}`;
    return email;
  }

  /**
   * URL permanen inbox Zulzzmail — bisa diakses kapanpun dengan format:
   * https://zulzzmail.biz.id/{email-lengkap}
   */
  static async getInboxLink(email: string): Promise<string> {
    return `https://zulzzmail.biz.id/${email}`;
  }
}
