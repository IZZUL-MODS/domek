import { NextRequest, NextResponse } from 'next/server';
import { storage } from '@/lib/storage';
import { ZulzzmailService } from '@/lib/zulzzmail';
import { jobQueue } from '@/lib/job-queue';
import { initializeJobHandlers } from '@/lib/job-handler-server';

export async function POST(request: NextRequest) {
  try {
    // Initialize handlers on first request
    initializeJobHandlers();

    const { domainName, extension } = await request.json();

    // Validate input
    if (
      !domainName ||
      !extension ||
      !['my.id', 'biz.id', 'web.id'].includes(extension)
    ) {
      return NextResponse.json(
        { error: 'Invalid domain name or extension' },
        { status: 400 }
      );
    }

    // Generate temp email
    const tempEmail = await ZulzzmailService.generateTempEmail();
    const inboxLink = await ZulzzmailService.getInboxLink(tempEmail);

    // Create registration record
    const registration = storage.createRegistration(
      domainName,
      extension as 'my.id' | 'biz.id' | 'web.id',
      tempEmail
    );

    console.log('[v0] Registration created:', registration.id);

    // Enqueue the job
    const jobId = jobQueue.enqueue('register_domain', {
      registrationId: registration.id,
      domainName,
      extension,
      tempEmail,
    });

    console.log('[v0] Job enqueued:', jobId);

    return NextResponse.json({
      success: true,
      registration: {
        id: registration.id,
        domainName: registration.domainName,
        extension: registration.extension,
        fullDomain: registration.fullDomain,
        tempEmail: registration.tempEmail,
        inboxLink,
        status: registration.status,
      },
      jobId,
    });
  } catch (error) {
    console.error('[v0] API error:', error);
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Internal server error',
      },
      { status: 500 }
    );
  }
}
