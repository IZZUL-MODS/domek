import { NextRequest, NextResponse } from 'next/server';
import { storage } from '@/lib/storage';
import { ZulzzmailService } from '@/lib/zulzzmail';

export async function GET(request: NextRequest) {
  try {
    const registrations = storage.getAllRegistrations();

    const result = await Promise.all(
      registrations.map(async (registration) => {
        const inboxLink = await ZulzzmailService.getInboxLink(
          registration.tempEmail
        );
        return {
          id: registration.id,
          domainName: registration.domainName,
          extension: registration.extension,
          fullDomain: registration.fullDomain,
          tempEmail: registration.tempEmail,
          inboxLink,
          status: registration.status,
          createdAt: registration.createdAt,
          completedAt: registration.completedAt,
          idwebhostOrderId: registration.idwebhostOrderId,
          directOrderUrl: registration.directOrderUrl,
          accountPassword: registration.accountPassword,
          error: registration.error,
          logs: registration.logs,
        };
      })
    );

    return NextResponse.json({
      success: true,
      registrations: result,
      total: result.length,
    });
  } catch (error) {
    console.error('[v0] API error:', error);
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Internal server error',
      },
      { status: 500 }
    );
  }
}
