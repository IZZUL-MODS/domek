import { NextRequest, NextResponse } from 'next/server';
import { storage } from '@/lib/storage';
import { ZulzzmailService } from '@/lib/zulzzmail';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const registrationId = searchParams.get('id');

    if (!registrationId) {
      return NextResponse.json(
        { error: 'Registration ID required' },
        { status: 400 }
      );
    }

    const registration = storage.getRegistration(registrationId);

    if (!registration) {
      return NextResponse.json(
        { error: 'Registration not found' },
        { status: 404 }
      );
    }

    const inboxLink = await ZulzzmailService.getInboxLink(
      registration.tempEmail
    );

    return NextResponse.json({
      success: true,
      registration: {
        id: registration.id,
        domainName: registration.domainName,
        extension: registration.extension,
        fullDomain: registration.fullDomain,
        tempEmail: registration.tempEmail,
        inboxLink,
        status: registration.status,
        createdAt: registration.createdAt,
        completedAt: registration.completedAt,
        idwebhostOrderId: registration.idwebhostOrderId,
        error: registration.error,
      },
    });
  } catch (error) {
    console.error('[v0] API error:', error);
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : 'Internal server error',
      },
      { status: 500 }
    );
  }
}
