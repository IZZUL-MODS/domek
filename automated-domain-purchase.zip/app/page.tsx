'use client';

import { useState } from 'react';
import { DomainForm } from '@/components/domain-form';
import { RegistrationHistory } from '@/components/registration-history';

export default function Page() {
  const [activeTab, setActiveTab] = useState<'register' | 'history'>('register');

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Header */}
      <header className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Domain Buyer Otomatis</h1>
              <p className="text-slate-400 mt-1">
                Beli domain gratis dengan kode promo M4tS7m1n
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-400">GRATIS</div>
              <p className="text-slate-400 text-sm">dengan kode promo</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8">
          <button
            onClick={() => setActiveTab('register')}
            className={`px-6 py-3 rounded-lg font-semibold transition ${
              activeTab === 'register'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            Daftar Domain Baru
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-6 py-3 rounded-lg font-semibold transition ${
              activeTab === 'history'
                ? 'bg-blue-600 text-white'
                : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
            }`}
          >
            Riwayat Registrasi
          </button>
        </div>

        {/* Tab Content */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-8 shadow-xl">
          {activeTab === 'register' && <DomainForm />}
          {activeTab === 'history' && <RegistrationHistory />}
        </div>

        {/* Info Box */}
        <div className="mt-8 bg-blue-900/30 border border-blue-700 rounded-lg p-6">
          <h3 className="font-bold text-blue-300 mb-3">Informasi Penting:</h3>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>✓ Proses otomatis & cepat</li>
            <li>✓ Email sementara dari Zulzzmail</li>
            <li>✓ Kode promo: <span className="font-bold text-green-400">M4tS7m1n</span></li>
            <li>✓ Tersedia: my.id, biz.id, web.id</li>
            <li>✓ Link inbox untuk akses email</li>
          </ul>
        </div>
      </div>
    </main>
  );
}
