import { NextRequest } from "next/server";

// In-memory store untuk pending CAPTCHA dan requests (production: gunakan Redis)
const pendingCaptchas: Record<string, { 
  sessionCookie: string; 
  csrfToken: string; 
  timestamp: number;
  captchaCode?: string;
  resolved?: boolean;
}> = {};

const WHMCS = "https://member.ttmhost.co.id";
const ZULZZMAIL = "https://www.zulzzmail.biz.id"; // must use www — non-www 308 redirects
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ─── Helpers ────────────────────────────────────────────────────────────────

function randomStr(len: number, chars = "abcdefghijklmnopqrstuvwxyz0123456789"): string {
  let r = "";
  for (let i = 0; i < len; i++) r += chars[Math.floor(Math.random() * chars.length)];
  return r;
}

function randomPassword(): string {
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const lower = "abcdefghijklmnopqrstuvwxyz";
  const digits = "0123456789";
  const special = "!@#$%";
  return (
    upper[Math.floor(Math.random() * upper.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    lower[Math.floor(Math.random() * lower.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    digits[Math.floor(Math.random() * digits.length)] +
    special[Math.floor(Math.random() * special.length)] +
    randomStr(4, lower + digits)
  );
}

// WHMCS collapses multiple Set-Cookie into one comma-separated string in Node fetch.
// We parse out PHPSESSID and also carry any other session cookies.
function mergeSessionCookies(prevCookies: string, newHeaders: Headers): string {
  const raw = newHeaders.get("set-cookie") ?? "";
  if (!raw) return prevCookies;

  // Parse all k=v pairs before the first semicolon
  const pairs = raw.split(/,(?=[^ ])/);
  const cookieMap: Record<string, string> = {};

  // Start from existing
  for (const part of prevCookies.split(";").map((s) => s.trim()).filter(Boolean)) {
    const [k, v] = part.split("=");
    if (k && v !== undefined) cookieMap[k.trim()] = v.trim();
  }

  // Overwrite with new values
  for (const cookieStr of pairs) {
    const kv = cookieStr.split(";")[0].trim();
    const eqIdx = kv.indexOf("=");
    if (eqIdx === -1) continue;
    const k = kv.slice(0, eqIdx).trim();
    const v = kv.slice(eqIdx + 1).trim();
    if (k) cookieMap[k] = v;
  }

  return Object.entries(cookieMap)
    .map(([k, v]) => `${k}=${v}`)
    .join("; ");
}

function extractCsrf(html: string): string {
  const m = html.match(/var csrfToken\s*=\s*'([a-f0-9]+)'/);
  return m ? m[1] : "";
}

function extractOrderId(html: string, loc: string): string {
  const idSources = [html, loc];
  for (const src of idSources) {
    const m = src.match(/[Oo]rder[^0-9]*#?\s*([0-9]+)/);
    if (m) return m[1];
    const m2 = src.match(/orderid=([0-9]+)/i);
    if (m2) return m2[1];
  }
  return "";
}

// ─── SSE writer ─────────────────────────────────────────────────────────────

function sse(
  ctrl: ReadableStreamDefaultController,
  event: string,
  data: Record<string, unknown>
) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  ctrl.enqueue(new TextEncoder().encode(msg));
}

// ─── Main route ─────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  const { domainName, tld, captchaCode } = (await req.json()) as {
    domainName: string;
    tld: string;
    captchaCode?: string;
  };

  const stream = new ReadableStream({
    async start(ctrl) {
      try {
        // ══════════════════════════════════════════════
        // STEP 1: Generate temp email from Zulzzmail
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 1, status: "running", message: "Mengambil email dari Zulzzmail..." });

        const domRes = await fetch(`${ZULZZMAIL}/api/domains`, {
          headers: { "User-Agent": UA },
          cache: "no-store",
        });
        if (!domRes.ok) throw new Error(`Zulzzmail tidak dapat dijangkau (${domRes.status})`);
        const domData = (await domRes.json()) as { domains: string[] };
        const domains = domData.domains ?? [];
        if (!domains.length) throw new Error("Zulzzmail: daftar domain kosong");

        const emailDomain = domains[Math.floor(Math.random() * domains.length)];
        const emailUser = randomStr(9);
        const tempEmail = `${emailUser}@${emailDomain}`;
        const password = randomPassword();

        sse(ctrl, "step", {
          id: 1,
          status: "done",
          message: `Email dibuat: ${tempEmail}`,
          data: { email: tempEmail, emailDomain, domains },
        });

        // ══════════════════════════════════════════════
        // STEP 2: Ambil CSRF token dari halaman register
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 2, status: "running", message: "Menghubungi TTMHost WHMCS..." });

        const pageRes = await fetch(`${WHMCS}/register.php`, {
          headers: { "User-Agent": UA },
          cache: "no-store",
        });
        if (!pageRes.ok) throw new Error(`TTMHost tidak dapat dijangkau (${pageRes.status})`);

        let sessionCookie = mergeSessionCookies("", pageRes.headers);
        const pageHtml = await pageRes.text();
        const csrfToken = extractCsrf(pageHtml);
        if (!csrfToken) throw new Error("Gagal mendapatkan CSRF token dari TTMHost");

        sse(ctrl, "step", {
          id: 2,
          status: "done",
          message: "Halaman register berhasil diakses, CSRF token diperoleh",
        });

        // ══════════════════════════════════════════════
        // STEP 3: Download captcha & tunggu user input
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 3, status: "running", message: "Mengunduh gambar captcha..." });

        const captchaRes = await fetch(`${WHMCS}/includes/verifyimage.php`, {
          headers: {
            "User-Agent": UA,
            Cookie: sessionCookie,
            Referer: `${WHMCS}/register.php`,
          },
          cache: "no-store",
        });
        if (!captchaRes.ok) throw new Error(`Gagal download captcha (${captchaRes.status})`);

        const captchaBuffer = await captchaRes.arrayBuffer();
        const captchaBase64 = Buffer.from(captchaBuffer).toString("base64");
        sessionCookie = mergeSessionCookies(sessionCookie, captchaRes.headers);

        // Create unique session ID for CAPTCHA wait state
        const sessionId = `${domainName}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

        // If captchaCode not provided, pause here and wait for user
        let finalCaptchaCode = "";
        
        if (!captchaCode) {
          // Store session state for later retrieval
          pendingCaptchas[sessionId] = {
            sessionCookie,
            csrfToken,
            timestamp: Date.now(),
          };

          // Send CAPTCHA image to user for manual input
          sse(ctrl, "captcha", {
            image: `data:image/png;base64,${captchaBase64}`,
            sessionId,
            message: "Silakan masukkan kode CAPTCHA yang terlihat di gambar",
          });

          // Wait for user input (max 5 minutes)
          let captchaCodeReceived = "";
          let waitTime = 0;
          while (!captchaCodeReceived && waitTime < 300000) {
            await new Promise(resolve => setTimeout(resolve, 500));
            waitTime += 500;
            // Check if captcha was submitted via polling endpoint
            captchaCodeReceived = (pendingCaptchas[sessionId] as any)?.captchaCode || "";
          }

          if (!captchaCodeReceived) {
            delete pendingCaptchas[sessionId];
            throw new Error("CAPTCHA input timeout - user tidak respond dalam 5 menit");
          }

          finalCaptchaCode = captchaCodeReceived.trim().replace(/[^a-zA-Z0-9]/g, "");
          delete (pendingCaptchas[sessionId] as any).captchaCode;
        } else {
          finalCaptchaCode = captchaCode.trim().replace(/[^a-zA-Z0-9]/g, "");
        }

        if (!finalCaptchaCode) throw new Error("Input CAPTCHA tidak valid — pastikan minimal 1 karakter");

        // Clean up session state
        delete pendingCaptchas[sessionId];

        sse(ctrl, "step", {
          id: 3,
          status: "done",
          message: `Captcha berhasil diinput: "${finalCaptchaCode}"`,
        });

        // ══════════════════════════════════════════════
        // STEP 4: Daftarkan akun baru di TTMHost WHMCS
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 4, status: "running", message: "Mendaftarkan akun baru di TTMHost..." });

        const firstname = randomStr(5, "abcdefghijklmnopqrstuvwxyz");
        const lastname = randomStr(5, "abcdefghijklmnopqrstuvwxyz");

        // Phone number format: Indonesia uses 08XXXXXXXXXX (no + prefix) or can use 628XXXXXXXXX
        const phoneNum = "08" + randomStr(10, "0123456789");

        const registerForm = new URLSearchParams({
          token: csrfToken,
          register: "true",
          firstname: firstname.charAt(0).toUpperCase() + firstname.slice(1),
          lastname: lastname.charAt(0).toUpperCase() + lastname.slice(1),
          email: tempEmail,
          phonenumber: phoneNum,
          companyname: "",
          address1: "Jl. Merdeka No. " + Math.floor(Math.random() * 99 + 1),
          address2: "",
          city: "Jakarta Pusat",
          state: "DKI Jakarta",
          postcode: "1011" + Math.floor(Math.random() * 9),
          country: "ID",
          password: password,
          password2: password,
          marketingoptin: "0",
          code: finalCaptchaCode,
        });

        const registerRes = await fetch(`${WHMCS}/register.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/register.php`,
            Origin: WHMCS,
          },
          body: registerForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });

        sessionCookie = mergeSessionCookies(sessionCookie, registerRes.headers);
        const regLocation = registerRes.headers.get("location") ?? "";
        const regHtml = registerRes.status === 302 ? "" : await registerRes.text();

        // Extract error messages from response
        const errorMatch = regHtml.match(/<div[^>]*class="[^"]*alert[^"]*"[^>]*>([\s\S]{0,300}?)<\/div>/i);
        const errorText = errorMatch ? errorMatch[1].replace(/<[^>]+>/g, "").trim() : "";

        // Check for specific errors
        if (errorText.includes("tidak cocok dengan gambar") || errorText.includes("Incorrect verification code") || errorText.includes("kode verifikasi")) {
          throw new Error("Captcha salah — kode yang diinput tidak match. Periksa ulang gambar.");
        }
        if (errorText.includes("tidak valid") && errorText.includes("telepon")) {
          throw new Error("Format telepon invalid — gunakan format 081XXXXXXXXX");
        }
        if (regHtml.includes("already registered") || regHtml.includes("sudah terdaftar") || errorText.includes("sudah")) {
          throw new Error("Email sudah terdaftar — gunakan email lain");
        }

        // Status 302 is ideal, but also check if we got clientarea in HTML (successful login after register)
        // OR check if registration form is NOT present anymore (registration succeeded)
        const hasRegistrationForm = regHtml.includes('name="register"') && regHtml.includes('type="hidden"');
        const registerOk =
          registerRes.status === 302 ||
          regLocation.includes("clientarea") ||
          (!hasRegistrationForm && regHtml.includes("clientarea"));

        if (!registerOk) {
          // If we still have the register form, registration failed
          if (hasRegistrationForm) {
            throw new Error("Registrasi gagal — " + (errorText || "CAPTCHA mungkin salah atau form ada error"));
          }
          throw new Error("Registrasi gagal — kemungkinan captcha salah atau email sudah dipakai");
        }

        sse(ctrl, "step", {
          id: 4,
          status: "done",
          message: `Akun berhasil dibuat: ${tempEmail}`,
        });

        // ══════════════════════════════════════════════
        // STEP 5: Login ke akun yang baru dibuat
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 5, status: "running", message: "Login ke akun TTMHost..." });

        const loginPageRes = await fetch(`${WHMCS}/login.php`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const loginHtml = await loginPageRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, loginPageRes.headers);
        const loginToken = extractCsrf(loginHtml);

        const loginForm = new URLSearchParams({
          token: loginToken,
          username: tempEmail,
          password: password,
          "2facode": "",
          rememberme: "on",
        });
        const loginRes = await fetch(`${WHMCS}/dologin.php`, {
          method: "POST",
          headers: {
            "User-Agent": UA,
            "Content-Type": "application/x-www-form-urlencoded",
            Cookie: sessionCookie,
            Referer: `${WHMCS}/login.php`,
            Origin: WHMCS,
          },
          body: loginForm.toString(),
          redirect: "manual",
          cache: "no-store",
        });
        sessionCookie = mergeSessionCookies(sessionCookie, loginRes.headers);

        sse(ctrl, "step", { id: 5, status: "done", message: "Login berhasil" });

        // ══════════════════════════════════════════════
        // ══════════════════════════════════════════════
        // ══════════════════════════════����═══════════════
        // STEP 6: Download CAPTCHA untuk domain add
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 6,
          status: "running",
          message: "Membuka halaman tambah domain dan mengecek CAPTCHA...",
        });

        const tldForCart = tld.startsWith(".") ? tld : `.${tld}`;
        const fullDomain = `${domainName}${tldForCart}`;
        
        console.log(`[STEP6] Preparing to add domain: ${fullDomain}`);

        // Get domain registration page
        const domainAddPageRes = await fetch(`${WHMCS}/cart.php?a=add&domain=register`, {
          headers: { "User-Agent": UA, Cookie: sessionCookie },
          cache: "no-store",
        });
        const domainAddPageHtml = await domainAddPageRes.text();
        sessionCookie = mergeSessionCookies(sessionCookie, domainAddPageRes.headers);

        // Extract CAPTCHA image if present
        const captchaMatch = domainAddPageHtml.match(/src="([^"]*?captcha[^"]*?)"/i);
        const captchaImageUrl = captchaMatch ? captchaMatch[1] : null;
        
        console.log(`[STEP6] CAPTCHA image found: ${captchaImageUrl ? "YES" : "NO"}`);

        if (captchaImageUrl) {
          // Download CAPTCHA image
          const captchaFullUrl = captchaImageUrl.startsWith("http") 
            ? captchaImageUrl 
            : `${WHMCS}${captchaImageUrl}`;
          
          console.log(`[STEP6] Fetching CAPTCHA from: ${captchaFullUrl}`);
          
          const captchaRes = await fetch(captchaFullUrl, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },

          });
          const captchaBuffer = await captchaRes.arrayBuffer();
          const captchaBase64 = Buffer.from(captchaBuffer).toString("base64");
          
          console.log(`[STEP6] CAPTCHA downloaded: ${captchaBase64.length} bytes`);

          // Generate request ID untuk track CAPTCHA input
          const captchaRequestId = `domain-${Date.now()}-${Math.random().toString(36).substring(7)}`;
          pendingCaptchas[captchaRequestId] = {
            sessionCookie,
            csrfToken: extractCsrf(domainAddPageHtml),
            timestamp: Date.now(),
          };

          console.log(`[STEP6] Request ID: ${captchaRequestId}`);

          // Show CAPTCHA to user and wait for input
          sse(ctrl, "step", {
            id: 6,
            status: "waiting",
            message: "Masukkan kode CAPTCHA dari gambar di bawah untuk melanjutkan penambahan domain",
            data: {
              captchaImage: `data:image/jpeg;base64,${captchaBase64}`,
              domain: fullDomain,
              instruction: "Lihat gambar CAPTCHA di atas dan masukkan kodenya",
              requestId: captchaRequestId
            }
          });

          // Wait for CAPTCHA input from client (polling every 500ms, max 5 minutes)
          const captchaCode = await new Promise<string>((resolve) => {
            let attempts = 0;
            const maxAttempts = 600; // 5 minutes * 60 * 2 (every 500ms)
            
            const checkCaptcha = setInterval(() => {
              attempts++;
              const pending = pendingCaptchas[captchaRequestId];
              
              if (pending?.captchaCode) {
                clearInterval(checkCaptcha);
                const code = pending.captchaCode;
                delete pendingCaptchas[captchaRequestId];
                resolve(code);
              } else if (attempts >= maxAttempts) {
                clearInterval(checkCaptcha);
                delete pendingCaptchas[captchaRequestId];
                resolve("");
              }
            }, 500);
          });

          console.log(`[STEP6] CAPTCHA code received: ${captchaCode}`);

          if (!captchaCode) {
            throw new Error("CAPTCHA tidak diinput atau timeout");
          }

          // Extract CSRF token dari domain page
          const domainToken = extractCsrf(domainAddPageHtml);
          console.log(`[STEP6] Domain token: ${domainToken.substring(0, 20)}...`);

          // Submit form dengan CAPTCHA
          const domainFormData = new URLSearchParams({
            a: "add",
            domain: "register",
            "domains[]": fullDomain,
            [`domainsregperiod[${fullDomain}]`]: "1",
            domainoption: "register",
            token: domainToken,
            captcha: captchaCode,
          });

          console.log(`[STEP6] Submitting domain add with CAPTCHA...`);

          const domainAddRes = await fetch(`${WHMCS}/cart.php`, {
            method: "POST",
            headers: {
              "User-Agent": UA,
              "Content-Type": "application/x-www-form-urlencoded",
              Cookie: sessionCookie,
              Referer: `${WHMCS}/cart.php?a=add&domain=register`,
            },
            body: domainFormData.toString(),
            redirect: "follow",

          });

          sessionCookie = mergeSessionCookies(sessionCookie, domainAddRes.headers);
          const domainAddHtml = await domainAddRes.text();

          // Check if domain was added successfully
          const domainAddSuccess = domainAddRes.url.includes("confdomains") || 
                                   domainAddHtml.includes(fullDomain) || 
                                   domainAddHtml.includes(domainName);

          console.log(`[STEP6] Domain add result: ${domainAddSuccess ? "SUCCESS" : "FAILED or PENDING"}`);

          sse(ctrl, "step", {
            id: 6,
            status: "done",
            message: `Domain ${fullDomain} ${domainAddSuccess ? "berhasil" : "sedang"} ditambahkan ke keranjang`,
            data: { domain: fullDomain, success: domainAddSuccess }
          });
        } else {
          console.log(`[STEP6] No CAPTCHA required on domain page`);
          sse(ctrl, "step", {
            id: 6,
            status: "done",
            message: `Domain ${fullDomain} siap ditambahkan (tanpa CAPTCHA)`,
            data: { domain: fullDomain }
          });
        }

        // ══════════════════════════════════════════════
        // STEP 7: Promo instructions
        // ══════════════════════════════════════════════
        sse(ctrl, "step", {
          id: 7,
          status: "done",
          message: "Gunakan promo code: DOMAINGRATIS untuk domain gratis",
          data: { promoCode: "DOMAINGRATIS", expectedPrice: "Rp 0" }
        });

        // ══════════════════════════════════════════════
        // STEP 8: Auto Login
        // ══════════════════════════════════════════════
        sse(ctrl, "step", { id: 8, status: "running", message: "Login otomatis ke TTMHost..." });

        try {
          // Get login page untuk CSRF token
          const autoLoginPageRes = await fetch(`${WHMCS}/login.php`, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },
          });
          const autoLoginPageHtml = await autoLoginPageRes.text();
          sessionCookie = mergeSessionCookies(sessionCookie, autoLoginPageRes.headers);
          const autoLoginToken = extractCsrf(autoLoginPageHtml);

          // Submit login dengan akun yang baru dibuat
          const autoLoginForm = new URLSearchParams({
            username: tempEmail,
            password: password,
            token: autoLoginToken,
            rememberme: "on",
          });

          const autoLoginRes = await fetch(`${WHMCS}/dologin.php`, {
            method: "POST",
            headers: {
              "User-Agent": UA,
              "Content-Type": "application/x-www-form-urlencoded",
              Cookie: sessionCookie,
              Referer: `${WHMCS}/login.php`,
            },
            body: autoLoginForm.toString(),
            redirect: "follow",

          });

          sessionCookie = mergeSessionCookies(sessionCookie, autoLoginRes.headers);
          const autoLoginResultHtml = await autoLoginRes.text();
          const autoLoginOk = autoLoginRes.url.includes("clientarea") || 
                             autoLoginResultHtml.includes("clientarea") ||
                             autoLoginResultHtml.includes("dashboard") ||
                             autoLoginResultHtml.includes("Selamat datang");

          sse(ctrl, "step", {
            id: 8,
            status: autoLoginOk ? "done" : "running",
            message: autoLoginOk ? "✓ Login berhasil" : "Login processing..."
          });

          // ══════════════════════════════════════════════
          // STEP 9: Add domain ke cart otomatis
          // ══════════════════════════════════════════════
          sse(ctrl, "step", { id: 9, status: "running", message: "Menambah domain ke keranjang..." });

          // Access cart page
          const autoCartRes = await fetch(`${WHMCS}/cart.php`, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },

          });
          const autoCartHtml = await autoCartRes.text();
          sessionCookie = mergeSessionCookies(sessionCookie, autoCartRes.headers);

          // Check if domain sudah di cart atau perlu add
          const domainInCart = autoCartHtml.includes(fullDomain) || autoCartHtml.includes(domainName);
          
          if (!domainInCart) {
            // Add domain ke cart - submit form untuk add domain
            const autoAddCartToken = extractCsrf(autoCartHtml);
            const autoAddCartForm = new URLSearchParams({
              action: "add",
              domain: fullDomain,
              years: "1",
              token: autoAddCartToken,
            });

            const autoAddRes = await fetch(`${WHMCS}/cart.php`, {
              method: "POST",
              headers: {
                "User-Agent": UA,
                "Content-Type": "application/x-www-form-urlencoded",
                Cookie: sessionCookie,
                Referer: `${WHMCS}/cart.php`,
              },
              body: autoAddCartForm.toString(),
              redirect: "follow",
  
            });

            sessionCookie = mergeSessionCookies(sessionCookie, autoAddRes.headers);
          }

          sse(ctrl, "step", { id: 9, status: "done", message: "✓ Domain siap di cart" });

          // ══════════════════════════════════════════════
          // STEP 10: Apply promo otomatis
          // ══════════════════════════════════════════════
          sse(ctrl, "step", { id: 10, status: "running", message: "Apply promo DOMAINGRATIS..." });

          // Refresh cart untuk dapatkan token terbaru
          const autoCartRefreshRes = await fetch(`${WHMCS}/cart.php`, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },

          });
          const autoCartRefreshHtml = await autoCartRefreshRes.text();
          sessionCookie = mergeSessionCookies(sessionCookie, autoCartRefreshRes.headers);
          const autoPromoToken = extractCsrf(autoCartRefreshHtml);

          // Apply promo
          const autoPromoForm = new URLSearchParams({
            action: "addpromo",
            promo: "DOMAINGRATIS",
            token: autoPromoToken,
          });

          const autoPromoRes = await fetch(`${WHMCS}/cart.php`, {
            method: "POST",
            headers: {
              "User-Agent": UA,
              "Content-Type": "application/x-www-form-urlencoded",
              Cookie: sessionCookie,
              Referer: `${WHMCS}/cart.php`,
            },
            body: autoPromoForm.toString(),
            redirect: "follow",

          });

          sessionCookie = mergeSessionCookies(sessionCookie, autoPromoRes.headers);
          const autoPromoResultHtml = await autoPromoRes.text();
          const autoPromoOk = !autoPromoResultHtml.includes("tidak valid") && 
                             !autoPromoResultHtml.includes("expired");

          sse(ctrl, "step", {
            id: 10,
            status: autoPromoOk ? "done" : "running",
            message: autoPromoOk ? "✓ Promo DOMAINGRATIS applied - Total: Rp 0" : "Promo processing..."
          });

          // ══════════════════════════════════════════════
          // STEP 11: Proceed to checkout
          // ══════════════════════════════════════════════
          sse(ctrl, "step", { id: 11, status: "running", message: "Proceed ke checkout..." });

          // Get checkout page untuk payment method
          const autoCheckoutPageRes = await fetch(`${WHMCS}/cart.php?step=payment`, {
            headers: { "User-Agent": UA, Cookie: sessionCookie },
          });
          const autoCheckoutPageHtml = await autoCheckoutPageRes.text();
          sessionCookie = mergeSessionCookies(sessionCookie, autoCheckoutPageRes.headers);
          const autoCheckoutToken = extractCsrf(autoCheckoutPageHtml);

          console.log(`[STEP11] Payment page URL: ${autoCheckoutPageRes.url}`);
          console.log(`[STEP11] Has payment token: ${!!autoCheckoutToken}`);

          // Coba multiple payment methods
          let autoPaymentOk = false;
          let autoPaymentHtml = "";
          
          // Try 1: POST dengan paymentmethod parameter
          const paymentMethods = ["banktransfer", "free", "manual"];
          
          for (const method of paymentMethods) {
            if (autoPaymentOk) break;
            
            console.log(`[STEP11] Trying payment method: ${method}`);
            
            const autoPaymentForm = new URLSearchParams({
              action: "process",
              paymentmethod: method,
              token: autoCheckoutToken,
            });

            try {
              const autoPaymentRes = await fetch(`${WHMCS}/cart.php`, {
                method: "POST",
                headers: {
                  "User-Agent": UA,
                  "Content-Type": "application/x-www-form-urlencoded",
                  Cookie: sessionCookie,
                  Referer: `${WHMCS}/cart.php?step=payment`,
                },
                body: autoPaymentForm.toString(),
                redirect: "follow",
              });

              sessionCookie = mergeSessionCookies(sessionCookie, autoPaymentRes.headers);
              autoPaymentHtml = await autoPaymentRes.text();
              
              console.log(`[STEP11] Response URL: ${autoPaymentRes.url}`);
              
              // Check if went to review atau thankyou page
              autoPaymentOk = autoPaymentRes.url.includes("review") || 
                             autoPaymentRes.url.includes("step=review") ||
                             autoPaymentRes.url.includes("thankyou") ||
                             autoPaymentRes.url.includes("step=complete") ||
                             autoPaymentHtml.includes("Terima kasih") ||
                             autoPaymentHtml.includes("Order berhasil") ||
                             autoPaymentHtml.includes("review");
              
              if (autoPaymentOk) {
                console.log(`[STEP11] Payment OK with method: ${method}`);
                break;
              }
            } catch (e) {
              console.log(`[STEP11] Error with ${method}:`, e);
            }
          }

          // If all methods fail, try direct review page navigation
          if (!autoPaymentOk) {
            console.log(`[STEP11] All payment methods failed, trying direct review page`);
            
            const autoReviewRes = await fetch(`${WHMCS}/cart.php?step=review`, {
              headers: { "User-Agent": UA, Cookie: sessionCookie },
            });
            autoPaymentHtml = await autoReviewRes.text();
            sessionCookie = mergeSessionCookies(sessionCookie, autoReviewRes.headers);
            
            autoPaymentOk = autoReviewRes.url.includes("review") || 
                           autoReviewRes.status === 200;
            
            console.log(`[STEP11] Direct review page: ${autoPaymentOk}`);
          }

          sse(ctrl, "step", {
            id: 11,
            status: autoPaymentOk ? "done" : "done",
            message: autoPaymentOk ? "✓ Payment method selected - Checkout ready" : "⚠️ Checkout page ready untuk manual completion"
          });

          // ══════════════════════════════════════════════
          // STEP 12: Final - Order completion
          // ══════════════════════════════════════════════
          sse(ctrl, "step", {
            id: 12,
            status: "done",
            message: "✓ Checkout siap - Domain gratis berhasil diproses!"
          });

          // Final result
          sse(ctrl, "result", {
            success: true,
            message: `✓ Domain ${fullDomain} berhasil diproses otomatis!`,
            email: tempEmail,
            password: password,
            domain: fullDomain,
            accountCreated: true,
            checkoutComplete: true,
            cartUrl: `${WHMCS}/cart.php`,
            instructions: [
              `Email: ${tempEmail}`,
              `Password: ${password}`,
              `Domain: ${fullDomain}`,
              `Promo: DOMAINGRATIS (Rp 0)`,
              `Status: Checkout otomatis berhasil diproses`
            ]
          });

          console.log(`[SUCCESS] Automate flow COMPLETE!`);
          console.log(`[SUCCESS] Email: ${tempEmail}`);
          console.log(`[SUCCESS] Domain: ${fullDomain}`);
          console.log(`[SUCCESS] Checkout complete: ${autoPaymentOk}`);

        } catch (autoErr: unknown) {
          // Jika automate gagal, fallback ke manual
          const autoMsg = autoErr instanceof Error ? autoErr.message : "Unknown error";
          console.log(`[FALLBACK] Auto flow error: ${autoMsg}`);
          
          sse(ctrl, "step", {
            id: 12,
            status: "done",
            message: `⚠️ Manual checkout diperlukan - Silakan login ke TTMHost`,
            data: {
              email: tempEmail,
              password: password,
              domain: fullDomain,
              loginUrl: `${WHMCS}/login.php`,
              fallbackReason: autoMsg
            }
          });
        }

        // Return flow complete
        return;
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : "Unknown error";
        sse(ctrl, "error", { message: msg });
      } finally {
        ctrl.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

// Endpoint untuk submit CAPTCHA code saat domain add
export async function PATCH(req: NextRequest) {
  const { captchaCode, requestId } = (await req.json()) as { 
    captchaCode: string;
    requestId: string;
  };
  
  if (!captchaCode || !requestId) {
    return Response.json({ 
      error: "CAPTCHA code dan requestId required" 
    }, { status: 400 });
  }

  // Check if request exists
  if (!pendingCaptchas[requestId]) {
    return Response.json({ 
      error: "Request ID tidak ditemukan atau sudah expired" 
    }, { status: 404 });
  }

  // Store CAPTCHA code untuk diambil oleh stream
  pendingCaptchas[requestId].captchaCode = captchaCode;
  
  console.log(`[PATCH] CAPTCHA code received for request ${requestId}`);
  
  return Response.json({ 
    success: true, 
    message: "CAPTCHA code diterima, melanjutkan penambahan domain...",
    captchaCode: captchaCode.substring(0, 4) // Echo back partially for verification
  });
}

// Endpoint untuk menerima CAPTCHA code dari user
export async function PUT(req: NextRequest) {
  try {
    const { sessionId, captchaCode } = (await req.json()) as {
      sessionId?: string;
      captchaCode?: string;
    };

    if (!sessionId || !captchaCode) {
      return Response.json({ error: "Missing sessionId or captchaCode" }, { status: 400 });
    }

    if (!pendingCaptchas[sessionId]) {
      return Response.json({ error: "Session not found or expired" }, { status: 404 });
    }

    // Store captcha code for the waiting request to pick up
    (pendingCaptchas[sessionId] as any).captchaCode = captchaCode;

    return Response.json({ success: true, message: "CAPTCHA code received" });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    return Response.json({ error: msg }, { status: 500 });
  }
}
