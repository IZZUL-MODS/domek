"use client";

import { cn } from "@/lib/utils";

export type StepStatus = "idle" | "running" | "done" | "error";

export interface Step {
  id: number;
  label: string;
  message: string;
  status: StepStatus;
}

const STEP_DEFINITIONS = [
  { id: 1, label: "Generate Email" },
  { id: 2, label: "Akses TTMHost" },
  { id: 3, label: "Solve Captcha" },
  { id: 4, label: "Daftar Akun" },
  { id: 5, label: "Login" },
  { id: 6, label: "Tambah Domain" },
  { id: 7, label: "Terapkan Promo" },
  { id: 8, label: "Login Otomatis" },
  { id: 9, label: "Apply Promo" },
  { id: 10, label: "Payment Method" },
  { id: 11, label: "Complete Checkout" },
  { id: 12, label: "Verification" },
];

interface Props {
  steps: Step[];
}

function StatusIcon({ status }: { status: StepStatus }) {
  if (status === "running") {
    return (
      <span className="relative flex size-5 shrink-0 items-center justify-center">
        <span className="absolute inline-flex size-full animate-ping rounded-full bg-yellow-400 opacity-50" />
        <span className="relative inline-flex size-3 rounded-full bg-yellow-400" />
      </span>
    );
  }
  if (status === "done") {
    return (
      <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-green-500">
        <svg className="size-3 text-black" fill="none" stroke="currentColor" strokeWidth={3} viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
        </svg>
      </span>
    );
  }
  if (status === "error") {
    return (
      <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-red-500">
        <svg className="size-3 text-white" fill="none" stroke="currentColor" strokeWidth={3} viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
        </svg>
      </span>
    );
  }
  return (
    <span className="flex size-5 shrink-0 items-center justify-center rounded-full border border-zinc-600 bg-zinc-800">
      <span className="size-1.5 rounded-full bg-zinc-600" />
    </span>
  );
}

export function StepTracker({ steps }: Props) {
  const stepsWithDef = STEP_DEFINITIONS.map((def) => {
    const live = steps.find((s) => s.id === def.id);
    return {
      ...def,
      status: (live?.status ?? "idle") as StepStatus,
      message: live?.message ?? "",
    };
  });

  return (
    <div className="flex flex-col gap-0">
      {stepsWithDef.map((step, i) => (
        <div key={step.id} className="flex gap-3">
          {/* Left: icon + connector line */}
          <div className="flex flex-col items-center">
            <StatusIcon status={step.status} />
            {i < stepsWithDef.length - 1 && (
              <div
                className={cn(
                  "mt-1 w-px flex-1 transition-colors duration-500",
                  step.status === "done" ? "bg-green-500/40" : "bg-zinc-700"
                )}
                style={{ minHeight: 24 }}
              />
            )}
          </div>

          {/* Right: label + message */}
          <div className="pb-5 pt-0.5 min-w-0">
            <p
              className={cn(
                "text-sm font-semibold leading-5 transition-colors",
                step.status === "done"
                  ? "text-green-400"
                  : step.status === "running"
                  ? "text-yellow-300"
                  : step.status === "error"
                  ? "text-red-400"
                  : "text-zinc-500"
              )}
            >
              {step.label}
            </p>
            {step.message && (
              <p
                className={cn(
                  "mt-0.5 font-mono text-xs leading-relaxed break-all",
                  step.status === "running" ? "text-yellow-200/80" : "text-zinc-400"
                )}
              >
                {step.message}
              </p>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
