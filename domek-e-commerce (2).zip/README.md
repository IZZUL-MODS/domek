# 🌐 Domain Gratis Indonesia - Sistem Otomatis + Manual Hybrid

Website untuk membeli domain Indonesia (.my.id, .biz.id, .web.id) **GRATIS** dengan kode promo `DOMAINGRATIS`. Sistem terintegrasi dengan TTM Host dan Zulzzmail menggunakan pendekatan **Hybrid Automatic + Manual** untuk reliabilitas maksimal.

## 🚀 Fitur Utama

✅ **Registrasi Domain Gratis (Hybrid)**
- Daftar domain .my.id, .biz.id, atau .web.id GRATIS
- Kode promo `DOMAINGRATIS` membuat domain gratis 100%
- Backend otomatis + manual browser action untuk reliabilitas
- Tidak ada biaya tersembunyi

✅ **Email Auto-Generated**
- Email unik dari Zulzzmail otomatis dipilih dan di-claim
- Email tersimpan dalam hasil transaksi
- Support multiple email domains

✅ **Sistem Hybrid (Otomatis + Manual)**
- **Otomatis:** Email generation, CAPTCHA, account creation
- **Manual:** User add domain ke cart via browser (natural flow)
- **Otomatis:** Promo apply, price extraction, checkout
- Transaction ID untuk tracking setiap pembelian

✅ **Integrasi TTM Host**
- Langsung terhubung dengan TTM Host untuk registrasi
- Domain teregistrasi di server TTM Host terpercaya
- Support untuk ketiga ekstensi domain Indonesia
- Real-time price extraction dengan 6 regex patterns

## 📋 Alur Kerja Baru (v2.0 - Pragmatic)

### Fase 1: Otomatis (Backend Serverless)
1. **Input Domain** - Masukkan nama domain dan pilih ekstensi
2. **Generate Email** - Email unik dari Zulzzmail dipilih
3. **Daftar Akun** - Akun WHMCS dibuat otomatis dengan CAPTCHA manual
4. **Login** - Backend login ke akun TTMHost

### Fase 2: Manual (User Browser Action)
5. **Add Domain ke Cart** - User buka checkout link di browser dan add domain manual
   - Mengapa manual? TTMHost menggunakan JavaScript, backend serverless tidak bisa jalankan
   - Step-by-step instructions diberikan untuk memandu user
   - Reliable karena natural browser flow

### Fase 3: Otomatis (Backend Serverless)
6. **Apply Promo** - Backend apply promo code DOMAINGRATIS
7. **Extract Harga** - Harga diekstrak dengan 6 regex patterns (Rp 0 / GRATIS)
8. **Checkout** - Backend proceed ke checkout otomatis
9. **Selesai!** - Domain gratis berhasil, hasil dengan ID transaksi

### Why This Approach?
- ✅ **Reliable:** Tidak bertumpu pada fragile HTTP attempts
- ✅ **Natural:** Mengikuti alur yang user familiar (browser action)
- ✅ **Maintainable:** Tidak perlu reverse-engineer JavaScript
- ✅ **Future-proof:** Robust terhadap TTMHost UI changes

## 🛠️ Tech Stack

- **Framework**: Next.js 16 (App Router)
- **UI Components**: shadcn/ui
- **Styling**: Tailwind CSS v4
- **Icons**: Lucide React
- **Database**: Simulasi (dapat diintegrasikan dengan Neon, Supabase, dll)
- **Validation**: Zod

## 📦 API Endpoints

### POST /api/register-domain
Mendaftarkan domain baru dengan promo otomatis.

**Request:**
```json
{
  "domainName": "mybusiness",
  "extension": "biz.id",
  "promoCode": "DOMAINGRATIS"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "transactionId": "TRX-1718372699167",
    "domain": "mybusiness.biz.id",
    "registeredEmail": "user@sharklasers.com",
    "price": 189000,
    "finalPrice": 0,
    "promoApplied": true
  }
}
```

### GET /api/zulzzmail
Mengambil email random dari pool Zulzzmail yang tersedia.

**Response:**
```json
{
  "success": true,
  "email": "swift7317@thueotp.net",
  "domain": "thueotp.net",
  "availableEmails": [...]
}
```

### GET /api/available-emails
Mendapatkan list email yang tersedia dari Zulzzmail.

### POST /api/check-domain
Mengecek ketersediaan domain sebelum pembelian.

### GET /api/transactions
Mendapatkan history transaksi yang berhasil.

## 🎯 Fitur Unggulan

| Fitur | Deskripsi |
|-------|-----------|
| ⚡ Instan | Proses registrasi selesai dalam hitungan detik |
| 🔐 Aman | Integrasi langsung dengan TTM Host terpercaya |
| 💰 100% GRATIS | Dengan kode promo DOMAINGRATIS tidak ada biaya |
| 📧 Email Auto | Email dari Zulzzmail ter-claim otomatis ke domain |
| 🤖 Otomatis 100% | Tidak perlu input manual, semua proses otomatis |
| 📊 Transaction ID | Setiap transaksi punya ID unik untuk tracking |

## 🏃 Quickstart

### Prerequisites
- Node.js 18+
- pnpm (atau npm/yarn)

### Installation

```bash
# Clone repository atau download project
cd domain-gratis-indonesia

# Install dependencies
pnpm install

# Jalankan dev server
pnpm dev
```

Server akan running di `http://localhost:3000`

## 📱 Usage

1. Buka http://localhost:3000
2. Masukkan nama domain di field "Nama Domain" (contoh: "mybusiness")
3. Pilih ekstensi domain (.my.id, .biz.id, atau .web.id)
4. Klik tombol "🚀 Daftar Domain Gratis"
5. Tunggu proses selesai (< 5 detik)
6. Hasil akan tampil dengan:
   - Transaction ID
   - Domain lengkap yang ter-register
   - Email yang ter-claim dari Zulzzmail
   - Harga (0 = gratis dengan promo)

## 📧 Email Sources

Sistem menggunakan email dari Zulzzmail dengan domain berikut:
- thueotp.net
- tempmail.org
- maildrop.cc
- tempmail.dev
- fakeinbox.net
- guerrillamail.info
- mailinator.com
- 10minutemail.com
- trashmail.com
- throwaway.email
- mailnesia.com
- tempmail.pro
- yopmail.com
- dispostable.com
- sharklasers.com

## 🔧 Konfigurasi

### Environment Variables

Tidak ada environment variables yang diperlukan untuk development. Untuk production:

```env
NEXT_PUBLIC_BASE_URL=https://yourdomain.com
```

### Customization

**Mengubah Promo Code:**
Edit file `/app/api/register-domain/route.ts` dan ubah nilai `promoCode`:

```typescript
const isValidPromo = promoCode === "DOMAINGRATIS"; // Ubah di sini
```

**Mengubah Harga Domain:**
Edit file `/app/api/register-domain/route.ts`:

```typescript
const price = isValidPromo ? 0 : 189000; // Ubah harga di sini
```

**Menambah Email Source:**
Edit file `/app/api/zulzzmail/route.ts` dan tambahkan email ke `AVAILABLE_EMAILS`.

## 🗂️ Project Structure

```
├── app/
│   ├── api/
│   │   ├── register-domain/       # API untuk registrasi domain
│   │   ├── zulzzmail/             # API untuk ambil email
│   │   ├── available-emails/      # API untuk list email
│   │   ├── check-domain/          # API untuk cek domain
│   │   └── transactions/          # API untuk history transaksi
│   ├── layout.tsx                 # Root layout
│   ├── page.tsx                   # Homepage
│   └── globals.css                # Global styles
├── components/
│   ├── domain-form.tsx            # Form input domain
│   ├── info-section.tsx           # Info cards
│   └── ui/                        # shadcn/ui components
├── lib/
│   └── utils.ts                   # Utility functions
└── public/                        # Static assets
```

## 🎨 Design System

**Colors:**
- Primary: Blue (#3b82f6)
- Background: White/Black (light/dark mode)
- Success: Green (#22c55e)
- Border: Gray

**Typography:**
- Headings: Bold, 1.5rem - 2rem
- Body: Regular, 1rem
- Mono: For Transaction ID, email

**Spacing:**
- Gap: 4px - 32px using Tailwind gap scale
- Padding: 4px - 32px
- Mobile-first responsive design

## 🚀 Deployment

### Deploy ke Vercel

```bash
# Connect to Vercel
vercel

# Deploy
vercel --prod
```

### Deploy ke platform lain

Project ini adalah Next.js standard dan dapat di-deploy ke:
- Vercel (recommended)
- Netlify
- AWS Amplify
- Railway
- Heroku
- atau platform Node.js lainnya

## 📝 API Integration Guide

### Integrasi TTM Host

Untuk integrasi real dengan TTM Host API:

1. Daftar di TTM Host dan dapatkan API credentials
2. Update `/app/api/register-domain/route.ts`:

```typescript
// Ganti simulasi dengan API call real
const ttmResponse = await fetch('https://member.ttmhost.co.id/api/register', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${process.env.TTM_HOST_API_KEY}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    domain: fullDomain,
    registrationPeriod: 1,
    promoCode: promoCode,
    // ... other required fields
  })
});
```

3. Set environment variable:
```env
TTM_HOST_API_KEY=your_api_key_here
```

### Integrasi Zulzzmail

Untuk integrasi real dengan Zulzzmail:

1. Dokumentasi: https://zulzzmail.biz.id
2. Update `/app/api/zulzzmail/route.ts` untuk fetch dari API Zulzzmail
3. Implementasikan email claiming mechanism

## 🐛 Troubleshooting

**Q: Domain tidak ter-register?**
A: Pastikan kode promo adalah "DOMAINGRATIS" (case-sensitive). Cek console untuk error messages.

**Q: Email tidak ter-claim?**
A: System sedang fetch email dari Zulzzmail. Tunggu beberapa detik atau cek koneksi internet.

**Q: Transaction ID tidak muncul?**
A: Refresh halaman atau buka konsol browser untuk melihat error details.

## 📞 Support

Untuk support atau pertanyaan:
- TTM Host: https://ttmhost.co.id
- Zulzzmail: https://zulzzmail.biz.id
- Contact: [support email]

## 📄 License

MIT License - Bebas digunakan untuk keperluan apapun

## 🤝 Contributing

Contributions welcome! Silakan fork dan submit pull requests.

---

**Made with ❤️ by Domain Gratis Indonesia Team**

Built with Next.js, shadcn/ui, Tailwind CSS

Last Updated: July 2026
