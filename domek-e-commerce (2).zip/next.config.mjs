/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Allow longer execution for WHMCS + AI Vision captcha solving
  experimental: {
    serverActions: {
      bodySizeLimit: "2mb",
    },
  },
  serverExternalPackages: ["node-html-parser"],
  swcMinify: true,
  productionBrowserSourceMaps: false,
  ...(process.env.NODE_ENV === 'development' && {
    webpack: (config) => {
      config.devtool = false;
      return config;
    },
  }),
}

export default nextConfig
