# TTMHost Domain Add to Cart - Real Browser Debugging Findings

## Discovery Process

Saya melakukan debugging menyeluruh dengan membuka website TTMHost langsung dan mengikuti flow domain registration sesuai dengan yang user lakukan.

## Key Findings

### 1. Domain Search Flow (ACTUAL)

**URL**: `https://member.ttmhost.co.id/index.php?rp=/store/hosting/personal-2`

**Step 1: Domain Registration Page**
- User mengisi domain name di textbox
- User klik "Cari" button
- Page mencari domain availability via AJAX (muncul "Searching...")
- Jika available, muncul button "Masukan Ke Keranjang" dengan data attributes:
  ```html
  <button class="btn btn-primary btn-add-to-cart" data-whois="0" data-domain="debuggingdomain2024.com">
    Masukan Ke Keranjang
  </button>
  ```

### 2. Domain Add to Cart (CRITICAL FINDING)

**Button**: "Masukan Ke Keranjang" (Add to Cart)
- Button ini **BUKAN form submission**
- Button ini adalah **JavaScript click handler** yang trigger AJAX request
- Ketika di-click, button berubah menjadi "Selesaikan" (Finish/Complete)
- URL berubah ke: `/cart.php?a=add&domain=register`
- Data dikirim via **AJAX, bukan HTTP POST**

**Problem dengan HTTP Request Approach**:
```
curl "https://member.ttmhost.co.id/cart.php?a=add&domain=register&query=debuggingdomain2024&tld=.com"
```
- Returns HTTP 200
- Tetapi **TIDAK menambahkan domain ke cart**
- Domain hanya ditambahkan jika JavaScript button di-click dan trigger AJAX request internal

### 3. Form Structure yang Sesungguhnya

HTML button di halaman domain registration:
```html
<button 
  class="btn btn-primary btn-add-to-cart" 
  data-whois="0" 
  data-domain="debuggingdomain2024.com">
  <span class="to-add">Masukan Ke Keranjang</span>
  <span class="loading" style="display: none;">
    <i class="fas fa-spinner fa-spin"></i> Sedang Dimuat...
  </span>
  <span class="added" style="display: none;">
    <i class="far fa-shopping-cart"></i> Selesaikan
  </span>
</button>
```

Button di-handle oleh JavaScript code di `/templates/orderforms/standard_cart/js/scripts.min.js`

### 4. Why Simple HTTP Doesn't Work

TTMHost menggunakan **SPA (Single Page Application) approach**:
- Domain addition tidak via traditional form submission
- Menggunakan AJAX untuk update cart
- JavaScript code handle state changes (button text, UI updates)
- Backend `/cart.php` respond dengan updated HTML/JSON, bukan redirect

## Solution for v0 Application

Karena backend API (`automate/route.ts`) tidak bisa drive browser atau trigger JavaScript:

### Option 1: Use Playwright/Puppeteer (Not available in serverless)
- Perlu browser instance - tidak feasible di serverless environment

### Option 2: Reverse Engineer AJAX Request (RECOMMENDED)
- Analyze network request yang dikirim saat button di-click
- Replicate AJAX payload
- Send HTTP request ke correct endpoint dengan correct payload

### Option 3: Direct Checkout URL Generation
- Skip cart addition  
- Generate checkout URL dengan domain as parameter
- Redirect user ke TTMHost checkout dengan domain pre-selected
- User complete order di TTMHost

### Option 4: Acknowledge Limitation
- Document bahwa domain adding via backend tidak feasible
- Provide browser link untuk user manually add domain
- Focus pada promo code application dan payment

## Recommendation

Untuk implementasi yang bekerja **100% guaranteed**:

1. **Gunakan Option 2 + Option 3 Hybrid**:
   - Attempt AJAX request dengan exact payload yang dikirim browser
   - If fails, generate checkout URL untuk user
   - Both approaches documented untuk user

2. **Debug AJAX Payload**:
   - Buka browser DevTools → Network tab
   - Click "Masukan Ke Keranjang" button
   - Inspect exact request: method, headers, body
   - Replicate payload di v0 API

## Evidence from Testing

- Domain "debuggingdomain2024.com" successfully added to cart via browser click
- Same domain NOT added when using curl HTTP request
- Confirms: **JavaScript execution required for domain addition**

## Next Step

Analyze network tab melalui browser untuk mendapatkan exact AJAX endpoint dan payload.
