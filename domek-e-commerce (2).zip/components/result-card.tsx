"use client";

import { useState } from "react";

export interface OrderResult {
  success: boolean;
  email: string;
  password: string;
  domain: string;
  transactionId: string;
  orderId: string | null;
  promoCode: string;
  promoApplied: boolean;
  finalPrice: string;
  memberArea: string;
  inboxUrl: string;
  instructions?: string[];
  checkoutUrl?: string;
  memberAreaUrl?: string;
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Clipboard API blocked - silently fail (sandboxed environment)
      console.debug("Clipboard API not available");
    }
  };
  return (
    <button
      onClick={copy}
      className="ml-2 shrink-0 rounded px-2 py-0.5 text-xs font-medium transition-colors bg-zinc-700 hover:bg-zinc-600 text-zinc-300 hover:text-white"
    >
      {copied ? "Disalin!" : "Salin"}
    </button>
  );
}

function DataRow({ label, value, mono = true }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-zinc-700/50 py-3 last:border-0">
      <span className="shrink-0 text-xs font-medium text-zinc-400 pt-0.5">{label}</span>
      <div className="flex min-w-0 items-center">
        <span
          className={`break-all text-sm text-zinc-100 ${mono ? "font-mono" : "font-medium"}`}
        >
          {value}
        </span>
        <CopyButton value={value} />
      </div>
    </div>
  );
}

export function ResultCard({ result }: { result: OrderResult }) {
  return (
    <div className="rounded-2xl border border-green-500/30 bg-zinc-900 shadow-[0_0_40px_rgba(34,197,94,0.08)]">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-zinc-700/50 px-5 py-4">
        <span className="flex size-8 items-center justify-center rounded-full bg-green-500/15">
          <svg className="size-4 text-green-400" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </span>
        <div>
          <p className="text-sm font-bold text-green-400">Berhasil! Domain Ter-Register</p>
          <p className="text-xs text-zinc-500">Semua proses selesai secara otomatis</p>
        </div>
      </div>

      {/* Domain badge */}
      <div className="border-b border-zinc-700/50 px-5 py-4">
        <p className="mb-2 text-xs font-medium uppercase tracking-widest text-zinc-500">Domain</p>
        <div className="flex items-center gap-2 mb-3">
          <span className="rounded-lg bg-green-500/10 px-3 py-1.5 font-mono text-base font-bold text-green-400 border border-green-500/20">
            {result.domain}
          </span>
          <span className="rounded-full bg-green-500/15 px-2.5 py-1 text-xs font-semibold text-green-400">
            GRATIS
          </span>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-xs text-zinc-400">Harga:</span>
          <span className="font-mono font-bold text-lg text-green-400">{result.finalPrice}</span>
        </div>
      </div>

      {/* Instructions if provided */}
      {result.instructions && result.instructions.length > 0 && (
        <div className="border-b border-zinc-700/50 px-5 py-4 bg-blue-500/5 border-t border-blue-500/20">
          <p className="mb-3 text-xs font-medium uppercase tracking-widest text-blue-400">
            📋 Langkah-Langkah
          </p>
          <ul className="space-y-2">
            {result.instructions.map((instruction, idx) => (
              <li key={idx} className="text-sm text-zinc-300 flex gap-2">
                <span className="text-zinc-500 shrink-0 w-6">{instruction.substring(0, 1)}</span>
                <span>{instruction.substring(1).trim()}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Credentials */}
      <div className="px-5 py-2">
        <p className="mb-1 pt-2 text-xs font-medium uppercase tracking-widest text-zinc-500">
          Kredensial Akun TTMHost
        </p>
        <DataRow label="Email" value={result.email} />
        <DataRow label="Password" value={result.password} />
        <DataRow label="ID Transaksi" value={result.transactionId} />
        <DataRow label="Kode Promo" value={result.promoCode} mono={false} />
      </div>

      {/* Action links */}
      <div className="flex flex-col gap-2 border-t border-zinc-700/50 px-5 py-4 sm:flex-row">
        <a
          href={result.memberArea}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-zinc-800 py-2.5 text-sm font-semibold text-zinc-200 transition-colors hover:bg-zinc-700"
        >
          <svg className="size-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
          Area Member
        </a>
        <a
          href={result.inboxUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-green-600 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-green-500"
        >
          <svg className="size-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          Cek Inbox Email
        </a>
      </div>
    </div>
  );
}
